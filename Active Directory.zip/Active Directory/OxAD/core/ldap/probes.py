from __future__ import annotations

LDAP_PORT = 389
LDAPS_PORT = 636


def check_ldap_signing(
    host: str,
    domain: str,
    username: str,
    password: str = "",
    lmhash: str = "",
    nthash: str = "",
) -> dict:
    result: dict = {"required": None, "error": None}
    try:
        from impacket.ldap import ldap as ldap_impacket
    except ImportError as exc:
        result["error"] = str(exc)
        return result

    connection = None
    try:
        connection = ldap_impacket.LDAPConnection(f"ldap://{host}", dstIp=host)
        connection.login(username, password, domain, lmhash, nthash)
        result["required"] = False
    except ldap_impacket.LDAPSessionError as exc:
        if "strongerAuthRequired" in str(exc):
            result["required"] = True
        else:
            result["error"] = str(exc)
    except Exception as exc:
        result["error"] = str(exc)
    finally:
        if connection is not None:
            try:
                connection.close()
            except Exception:
                pass
    return result


def check_ldap_channel_binding(
    host: str,
    domain: str,
    username: str,
    password: str = "",
    lmhash: str = "",
    nthash: str = "",
) -> dict:
    result: dict = {"enforced": None, "error": None}
    try:
        from impacket.ldap import ldap as ldap_impacket
    except ImportError as exc:
        result["error"] = str(exc)
        return result

    connection = None
    try:
        connection = ldap_impacket.LDAPConnection(f"ldaps://{host}", dstIp=host)
        connection.login(username, password, domain, lmhash, nthash)
        result["enforced"] = False
    except ldap_impacket.LDAPSessionError as exc:
        if "data 80090346" in str(exc):
            result["enforced"] = True
        else:
            result["error"] = str(exc)
    except Exception as exc:
        result["error"] = str(exc)
    finally:
        if connection is not None:
            try:
                connection.close()
            except Exception:
                pass
    return result