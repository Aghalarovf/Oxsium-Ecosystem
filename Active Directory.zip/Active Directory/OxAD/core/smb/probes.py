from __future__ import annotations

from impacket.smbconnection import SMBConnection

SMB_PORT = 445


class SMBProbeError(Exception):
    pass


def _connect(host: str, timeout: float) -> SMBConnection:
    # manualNegotiate=False lets impacket negotiate the best dialect itself
    # (SMB1 -> SMB2/3 fallback), which is what every real SMB client does
    # and avoids the dialect/signing mismatches a hand-rolled client runs into.
    return SMBConnection(remoteName=host, remoteHost=host, sess_port=SMB_PORT, timeout=timeout)


def check_null_session(host: str, timeout: float = 5.0) -> dict:
    """Check whether the host accepts a null/anonymous SMB session.

    This mirrors what nxc/CrackMapExec actually does: a normal NTLM login
    with a blank username and password (impacket computes a real, if
    trivial, NTLMv2 response for the empty credentials) rather than the
    raw NTLMSSP_NEGOTIATE_ANONYMOUS wire trick, which modern Windows DCs
    typically bounce with STATUS_INVALID_PARAMETER instead of actually
    evaluating it against the RestrictAnonymous / null-session policy.
    """
    result: dict = {"allowed": None, "ipc_share_accessible": None, "error": None}
    debug: dict = {"dialect": None, "guest": None, "login_error": None, "tree_error": None}
    conn = None
    try:
        conn = _connect(host, timeout)
        debug["dialect"] = conn.getDialect()
        try:
            conn.login("", "", "")
            result["allowed"] = True
            debug["guest"] = conn.isGuestSession()
        except Exception as exc:
            debug["login_error"] = str(exc)
            result["allowed"] = False

        if result["allowed"]:
            try:
                tree_id = conn.connectTree("IPC$")
                result["ipc_share_accessible"] = True
                conn.disconnectTree(tree_id)
            except Exception as exc:
                debug["tree_error"] = str(exc)
                result["ipc_share_accessible"] = False
        else:
            result["ipc_share_accessible"] = False
    except Exception as exc:
        result["error"] = str(exc)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
    result["_debug"] = debug
    return result


def check_smb_signing(host: str, timeout: float = 5.0) -> dict:
    result: dict = {"signing_required": None, "error": None}
    conn = None
    try:
        conn = _connect(host, timeout)
        result["signing_required"] = bool(conn.isSigningRequired())
    except Exception as exc:
        result["error"] = str(exc)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
    return result


def get_os_info(host: str, timeout: float = 5.0) -> dict:
    result: dict = {"os": None, "error": None}
    conn = None
    try:
        conn = _connect(host, timeout)

        # OS/name/domain info only gets populated by impacket once the
        # SESSION_SETUP leg runs and it parses the NTLM challenge's Version
        # and AV_PAIRs (see smb3.py) -- plain negotiateSession() (done by
        # the constructor above) never triggers that. A blank-credential
        # login is enough to reach that point even if the DC then rejects
        # the actual logon, so its failure here is expected and ignored.
        try:
            conn.login("", "", "")
        except Exception:
            pass

        major = conn.getServerOSMajor()
        minor = conn.getServerOSMinor()
        build = conn.getServerOSBuild()
        if major is not None:
            result["os"] = f"Windows {major}.{minor} Build {build}"
        else:
            result["os"] = conn.getServerOS()

        netbios_name = conn.getServerName()
        domain = conn.getServerDomain()
        dns_hostname = conn.getServerDNSHostName()
        dns_domain = conn.getServerDNSDomainName()

        if netbios_name:
            result["netbios_name"] = netbios_name
        if domain:
            result["domain"] = domain
        if dns_hostname:
            result["dns_hostname"] = dns_hostname
        if dns_domain:
            result["dns_domain"] = dns_domain
    except Exception as exc:
        result["error"] = str(exc)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
    return result