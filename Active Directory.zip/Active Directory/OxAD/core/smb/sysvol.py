from __future__ import annotations

from impacket.smb3structs import FILE_READ_DATA
from impacket.smbconnection import SMBConnection

from core.session import AuthMethod, Credentials

SMB_PORT = 445
SYSVOL_SHARE = "SYSVOL"


def _connect_and_login(host: str, credentials: Credentials, timeout: float) -> SMBConnection:
    conn = SMBConnection(remoteName=host, remoteHost=host, sess_port=SMB_PORT, timeout=timeout)

    if credentials.auth_method == AuthMethod.KERBEROS_CCACHE:
        from core.kerberos.gssapi import prepare_ccache_env

        prepare_ccache_env(credentials.ccache_path)
        conn.kerberosLogin(
            credentials.username,
            "",
            credentials.domain,
            useCache=True,
        )
    elif credentials.auth_method == AuthMethod.NTLM_HASH:
        conn.login(
            credentials.username,
            "",
            credentials.domain,
            nthash=credentials.nt_hash,
        )
    else:
        conn.login(
            credentials.username,
            credentials.password or "",
            credentials.domain,
        )

    return conn


def read_sysvol_file(
    target: str,
    credentials: Credentials,
    relative_path: str,
    timeout: float = 10.0,
) -> tuple[bytes | None, str | None]:
    """Read a single file out of the target's SYSVOL share.

    relative_path is relative to the SYSVOL share root, e.g.
    'contoso.local\\Policies\\{GUID}\\MACHINE\\Microsoft\\Windows NT\\SecEdit\\GptTmpl.inf'.

    Returns (raw_bytes, None) on success, or (None, error_message) on failure.
    """
    conn = None
    try:
        conn = _connect_and_login(target, credentials, timeout)

        tree_id = conn.connectTree(SYSVOL_SHARE)
        try:
            file_id = conn.openFile(
                tree_id,
                relative_path,
                desiredAccess=FILE_READ_DATA,
            )
            try:
                data = conn.readFile(tree_id, file_id)
                return data, None
            finally:
                conn.closeFile(tree_id, file_id)
        finally:
            conn.disconnectTree(tree_id)
    except Exception as exc:
        return None, str(exc)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass