"""Engine entry point: raw_*.jsonl + domain_aces.jsonl -> domain_*.jsonl.

    python -m engine --output-dir output            # re-run without LDAP
    engine.pipeline.run(output_dir, ["users"])      # used by oxad.py
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

from engine.admin_rules import AdminContext
from engine.base import RawProcessor
from engine.computers_admins import ComputersAdmins
from engine.gpos_admins import GposAdmins
from engine.groups_admins import GroupsAdmins
from engine.object_rules import PRINCIPAL_SOURCES, ObjectContext, PrincipalIndex, domain_dn_from
from engine.ous_admins import OusAdmins
from engine.users_admins import UsersAdmins
from engine.certificates import CertificateProcessor

ACES_FILE = "domain_aces.jsonl"
PROCESSORS: dict[str, type[RawProcessor]] = {
    "users": UsersAdmins,
    "computers": ComputersAdmins,
    "groups": GroupsAdmins,
    "ous": OusAdmins,          # needs the classified users/computers/groups, so it runs after them
    "gpos": GposAdmins,        # same
    "cert": CertificateProcessor,
}
_PRINCIPAL_FILES = {"users": 0, "computers": 1, "groups": 2}   # index into PRINCIPAL_SOURCES

_default_logger = logging.getLogger(__name__)


def read_jsonl(path: Path) -> tuple[dict, list[dict]]:
    """Return (meta_line, records). A missing file gives an empty result."""
    if not path.exists():
        return {}, []
    with open(path, "r", encoding="utf-8") as f:
        lines = [json.loads(line) for line in f if line.strip()]
    return (lines[0], lines[1:]) if lines else ({}, [])


def write_jsonl(path: Path, meta: dict, records: list[dict]) -> None:
    lines = [json.dumps(meta, ensure_ascii=False, default=str)]
    lines.extend(json.dumps(r, ensure_ascii=False, default=str) for r in records)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def object_type_counts(records: list[dict]) -> dict:
    counts: dict[str, int] = {}
    for record in records:
        value = record.get("object_type")
        if value:
            counts[str(value)] = counts.get(str(value), 0) + 1
    return dict(sorted(counts.items(), key=lambda item: (-item[1], item[0])))


def user_summary(records: list[dict]) -> dict:
    def count(field: str) -> int:
        return sum(1 for record in records if bool(record.get(field)))

    total = len(records)
    disabled = count("disabled")
    enabled = total - disabled
    absolute_admin = count("absolute_admin")
    nested_admin = count("nested_admin")
    potential_admin = count("potential_admin")
    dcsync = count("dcsync")
    delegation = sum(
        1
        for record in records
        if bool(record.get("unconstrained_delegation") or record.get("constrained_delegation"))
    )

    summary = {
        "total_users": total,
        "enabled_users": enabled,
        "disabled_users": disabled,
        "absolute_admin_count": absolute_admin,
        "nested_admin_count": nested_admin,
        "potential_admin_count": potential_admin,
        "absolute_admin_counts": absolute_admin,
        "nested_admins_count": nested_admin,
        "potential_admins_count": potential_admin,
        "tier0_admin_count": absolute_admin + nested_admin,
        "dcsync_count": dcsync,
        "kerberoastable_count": count("kerberoastable"),
        "asrep_count": count("asrep"),
        "delegation_count": delegation,
        "pwd_never_expires_count": count("pwd_never_expires"),
        "pwd_not_required_count": count("pwd_not_required"),
        "locked_out_count": count("locked_out"),
        "smartcard_required_count": count("smartcard_required"),
        "account_never_expires_count": count("account_never_expires"),
        "must_change_pwd_count": count("must_change_pwd"),
        "admin_count_attribute_count": sum(
            1 for record in records if int(record.get("admin_count") or 0) > 0
        ),
    }
    return summary


def bool_count(records: list[dict], field: str) -> int:
    return sum(1 for record in records if bool(record.get(field)))


def list_count(records: list[dict], field: str) -> int:
    total = 0
    for record in records:
        value = record.get(field)
        if isinstance(value, (list, tuple, set, dict)):
            total += len(value)
    return total


def computer_summary(records: list[dict]) -> dict:
    return {
        "total_computers": len(records),
        "enabled_computers": bool_count(records, "enabled"),
        "disabled_computers": sum(1 for record in records if not bool(record.get("enabled"))),
        "server_count": bool_count(records, "is_server"),
        "workstation_count": bool_count(records, "is_workstation"),
        "domain_controller_count": bool_count(records, "is_domain_controller"),
        "stale_computer_count": bool_count(records, "is_stale"),
        "absolute_admin_count": bool_count(records, "absolute_admin"),
        "nested_admin_count": bool_count(records, "nested_admin"),
        "potential_admin_count": bool_count(records, "potential_admin"),
        "potential_privileged_count": bool_count(records, "potential_privileged"),
        "dcsync_count": bool_count(records, "dcsync"),
        "delegation_count": sum(
            1 for record in records
            if any(record.get(field) for field in (
                "unconstrained_delegation",
                "constrained_delegation",
                "protocol_transition_delegation",
                "trusted_for_delegation",
                "rbcd_enabled",
            ))
        ),
        "laps_count": bool_count(records, "has_laps"),
        "smb_signing_required_count": bool_count(records, "smb_signing_required"),
        "smb_port_open_count": bool_count(records, "smb_port_open"),
    }


def group_summary(records: list[dict]) -> dict:
    return {
        "total_groups": len(records),
        "privileged_group_count": bool_count(records, "is_privileged"),
        "empty_group_count": bool_count(records, "is_empty"),
        "nested_group_count": bool_count(records, "is_nested"),
        "protected_group_count": bool_count(records, "is_protected"),
        "absolute_admin_count": bool_count(records, "absolute_admin"),
        "nested_admin_count": bool_count(records, "nested_admin"),
        "potential_admin_count": bool_count(records, "potential_admin"),
        "admin_count_attribute_count": sum(
            1 for record in records if int(record.get("admin_count") or 0) > 0
        ),
        "member_count": sum(int(record.get("member_count") or 0) for record in records),
        "member_users_count": sum(int(record.get("member_users_count") or 0) for record in records),
    }


def ou_summary(records: list[dict]) -> dict:
    return {
        "total_ous": len(records),
        "gpo_linked_ou_count": bool_count(records, "has_gpo_links"),
        "protected_ou_count": bool_count(records, "is_protected"),
        "critical_ou_count": bool_count(records, "is_critical_system_object"),
        "highvalue_ou_count": bool_count(records, "highvalue"),
        "inheritance_blocked_ou_count": bool_count(records, "inheritance_blocked"),
        "controlled_by_non_admin_ou_count": bool_count(records, "controlled_by_non_admin"),
        "privileged_user_count": sum(int(record.get("privileged_users_count") or 0) for record in records),
        "privileged_computer_count": sum(int(record.get("privileged_computers_count") or 0) for record in records),
        "delegated_permission_count": sum(int(record.get("delegated_permissions") or 0) for record in records),
        "object_count": sum(int(record.get("object_count") or 0) for record in records),
    }


def gpo_summary(records: list[dict]) -> dict:
    return {
        "total_gpos": len(records),
        "linked_gpo_count": sum(1 for record in records if int(record.get("linked_count") or 0) > 0),
        "enforced_gpo_count": bool_count(records, "enforced"),
        "highvalue_gpo_count": bool_count(records, "highvalue"),
        "protected_gpo_count": bool_count(records, "isaclprotected"),
        "critical_gpo_count": bool_count(records, "is_critical_system_object"),
        "controlled_by_non_admin_gpo_count": bool_count(records, "controlled_by_non_admin"),
        "inheritance_blocked_gpo_count": bool_count(records, "inheritance_blocked"),
        "link_disabled_gpo_count": bool_count(records, "link_disabled"),
        "user_settings_disabled_count": bool_count(records, "user_settings_disabled"),
        "computer_settings_disabled_count": bool_count(records, "computer_settings_disabled"),
    }


def certificate_summary(records: list[dict]) -> dict:
    record_types = {
        "template": "certificate_template_count",
        "enrollment_service": "enrollment_service_count",
        "certification_authority": "certification_authority_count",
        "ntauth": "ntauth_certificate_count",
        "oid": "issuance_oid_count",
        "user_mapping": "weak_user_mapping_count",
    }
    summary = {
        "total_certificate_records": len(records),
        "esc_finding_count": sum(len(record.get("esc_findings") or []) for record in records),
        "vulnerable_template_count": sum(
            1 for record in records
            if record.get("record_type") == "template" and int(record.get("finding_count") or 0) > 0
        ),
        "hygiene_finding_count": sum(len(record.get("hygiene_findings") or []) for record in records),
        "high_risk_certificate_count": sum(
            1 for record in records
            if str(record.get("risk") or "").lower() in {"critical", "high"}
        ),
    }
    for record_type, key in record_types.items():
        summary[key] = sum(1 for record in records if record.get("record_type") == record_type)
    return summary


SUMMARY_BUILDERS = {
    "users": user_summary,
    "computers": computer_summary,
    "groups": group_summary,
    "ous": ou_summary,
    "gpos": gpo_summary,
    "cert": certificate_summary,
}


def run(output_dir, names: list[str] | None = None, logger: logging.Logger | None = None) -> dict[str, Path]:
    logger = logger or _default_logger
    output_dir = Path(output_dir)
    names = [n for n in PROCESSORS if names is None or n in names]

    _, aces = read_jsonl(output_dir / ACES_FILE)
    if not aces:
        logger.warning("%s missing or empty: ACE based admin rules (2, 4, 6) will not match", ACES_FILE)
    # Group graph is needed for every entity type (nested membership).
    _, groups = read_jsonl(output_dir / "raw_groups.jsonl")
    if not groups:
        logger.warning("raw_groups.jsonl missing or empty: nested admin rules (3, 4, 5) will not match")
    context = AdminContext(groups, aces)
    context.aces = aces

    written: dict[str, Path] = {}
    classified: dict[str, list[dict]] = {}     # principal records classified in this run
    for name in names:
        processor = PROCESSORS[name]()
        raw_path = output_dir / processor.raw_file
        if not raw_path.exists():
            logger.warning("[%s] %s not found, skipped", name, processor.raw_file)
            continue

        meta, records = read_jsonl(raw_path)
        if name in ("ous", "gpos") and context.objects is None:
            context.objects = _object_context(output_dir, classified, aces, records, logger)
        processed = processor.process(records, context)
        if name in _PRINCIPAL_FILES:
            classified[name] = processed

        meta = dict(meta)
        meta["generated_at"] = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        summary_builder = SUMMARY_BUILDERS.get(name)
        if summary_builder:
            summary = summary_builder(processed)
            meta.update(summary)
            meta["summary"] = {
                **(meta.get("summary") or {}),
                **summary,
            }
        object_types = object_type_counts(processed)
        if object_types:
            meta["object_types"] = object_types
            meta["summary"] = {**(meta.get("summary") or {}), "object_types": object_types}
        meta["meta"] = {
            **(meta.get("meta") or {}),
            "derived_from": [processor.raw_file, ACES_FILE] + ([] if name == "groups" else ["raw_groups.jsonl"]),
        }

        out_path = output_dir / processor.domain_file
        write_jsonl(out_path, meta, processed)
        written[name] = out_path
        logger.info("[%s] engine wrote %d records to %s", name, len(processed), out_path)
    return written


def _object_context(output_dir: Path, classified: dict, aces: list[dict], records: list[dict], logger) -> ObjectContext:
    """Index of classified principals for the OU/GPO rules: records processed
    in this run are used directly, the rest are read from domain_*.jsonl."""
    index = PrincipalIndex()
    for name, i in _PRINCIPAL_FILES.items():
        file_name, name_key, sid_key, dn_key, kind = PRINCIPAL_SOURCES[i]
        if name in classified:
            rows = classified[name]
        else:
            _, rows = read_jsonl(output_dir / file_name)
            if not rows:
                logger.warning("%s missing or empty: OU/GPO tier-0 and control rules will be incomplete", file_name)
        index.add(rows, name_key, sid_key, dn_key, kind)
    domain_dn = domain_dn_from(r.get("dn") or r.get("group_dn") or "" for r in records) or \
        domain_dn_from(a.get("target_dn") for a in aces[:200])
    return ObjectContext(aces, index, domain_dn)
