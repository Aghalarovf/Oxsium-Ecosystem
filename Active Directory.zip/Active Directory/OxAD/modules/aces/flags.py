from __future__ import annotations

from .constants import (
    ACE_FLAG_INHERITED,
    ACE_FLAG_INHERIT_ONLY,
    MEDIUM_RIGHTS,
    _DANGEROUS_ACE_NOISY_NAMES,
    _DANGEROUS_ACE_NOISY_RIDS,
)

_DENY_TYPES = (1, 6)


def _is_deny(record: dict) -> bool:
    return record.get("ace_type_raw") in _DENY_TYPES


def _is_inherited(record: dict) -> bool:
    return bool(int(record.get("ace_flags") or 0) & ACE_FLAG_INHERITED)


def _is_inherit_only(record: dict) -> bool:
    return bool(int(record.get("ace_flags") or 0) & ACE_FLAG_INHERIT_ONLY)


def _is_noisy_principal(record: dict) -> bool:
    # EN: Principals listed in constants.json -> trustees.dangerous_ace_noisy_names / _rids
    #     (e.g. DnsAdmins, Exchange groups) never produce a "dangerous" ACE.
    # AZ: constants.json -> trustees.dangerous_ace_noisy_names / _rids siyahısındakı
    #     principal-lar (DnsAdmins, Exchange qrupları və s.) heç vaxt "dangerous" ACE yaratmır.
    sid = record.get("principal_sid") or ""
    if sid.startswith("S-1-5-21-") and f"-{sid.rsplit('-', 1)[-1]}" in _DANGEROUS_ACE_NOISY_RIDS:
        return True
    name = str(record.get("principal_name") or "").rsplit("\\", 1)[-1].strip().upper()
    return bool(name) and name in _DANGEROUS_ACE_NOISY_NAMES


def annotate_ace_flags(records: list[dict]) -> None:
    for record in records:
        allowed = not _is_deny(record)
        dangerous = bool(record.get("dangerous_ace"))
        inherited = _is_inherited(record)
        demoted_to_medium = False

        if allowed and dangerous:
            if _is_noisy_principal(record):
                # EN: Known noisy principal -> not dangerous, not medium.
                # AZ: Məlum "noisy" principal -> nə dangerous, nə də medium.
                dangerous = False
                record["dangerous_ace"] = False
            elif _is_inherit_only(record):
                # EN: Inherit-Only ACE does not apply to this object itself -> Medium.
                # AZ: Inherit-Only ACE obyektin özünə tətbiq olunmur -> Medium.
                dangerous = False
                demoted_to_medium = True
                record["dangerous_ace"] = False

        has_medium = any(right in MEDIUM_RIGHTS for right in record.get("rights") or [])
        record["medium_rights"] = allowed and not dangerous and (has_medium or demoted_to_medium)
        record["suspicious_ace"] = allowed and dangerous and not inherited
        record["default_high_rights"] = allowed and dangerous and inherited
        record["orphaned_sid"] = bool(record.get("principal_sid")) and not record.get("principal_name")


def build_ace_summary(records: list[dict]) -> dict:
    def count(predicate) -> int:
        return sum(1 for record in records if predicate(record))

    def type_counts(field: str) -> dict:
        counts: dict[str, int] = {}
        for record in records:
            value = str(record.get(field) or "Others")
            counts[value] = counts.get(value, 0) + 1
        return dict(sorted(counts.items(), key=lambda item: (-item[1], item[0])))

    return {
        "total_aces": len(records),
        "target_type_counts": type_counts("target_type"),
        "principal_type_counts": type_counts("principal_type"),
        "dangerous_ace_count": count(lambda r: bool(r.get("dangerous_ace")) and not _is_deny(r)),
        "extended_rights_count": count(lambda r: bool(r.get("extended_rights")) and not _is_deny(r)),
        "orphaned_sid_count": count(lambda r: bool(r.get("orphaned_sid"))),
        "suspicious_ace_count": count(lambda r: bool(r.get("suspicious_ace"))),
        "default_high_rights_count": count(lambda r: bool(r.get("default_high_rights"))),
        "medium_rights_count": count(lambda r: bool(r.get("medium_rights"))),
        "is_deny_count": count(_is_deny),
        "inherited_count": count(_is_inherited),
    }