from __future__ import annotations

import configparser
import logging
import socket
import struct
from datetime import datetime, timezone

from ldap3 import ALL, ANONYMOUS, BASE, Connection, Server

from core.config import Config
from core.ldap.probes import check_ldap_channel_binding, check_ldap_signing
from core.models import ADDomain
from core.session import AuthMethod, Session
from core.smb.probes import check_null_session, check_smb_signing, get_os_info
from core.smb.sysvol import read_sysvol_file
from modules.base import BaseModule, ModuleResult
from utils.adutils import ldap_timestamp_to_iso, normalize_value, safe_int
from utils.constants import UAC_FLAGS
from utils.sid_utils import sid_bytes_to_str

logger = logging.getLogger(__name__)

_DOMAIN_ATTRS = [
    "name",
    "distinguishedName",
    "objectSid",
    "msDS-Behavior-Version",
    "maxPwdAge",
    "minPwdAge",
    "minPwdLength",
    "pwdHistoryLength",
    "pwdProperties",
    "lockoutThreshold",
    "lockoutDuration",
    "lockOutObservationWindow",
    "fSMORoleOwner",
]

_DC_ATTRS = ["name", "dNSHostName", "objectSid", "operatingSystem"]

_GUEST_ATTRS = [
    "sAMAccountName",
    "distinguishedName",
    "userAccountControl",
    "lastLogonTimestamp",
    "pwdLastSet",
    "description",
]

# Well-known RID for the built-in Guest account (same on every domain,
# regardless of its sAMAccountName -- it can be renamed, but its RID can't).
_RID_GUEST = 501

_DNS_RECORD_HEADER_LEN = 24
_DNS_TYPE_A = 1

_FUNCTIONAL_LEVELS = {
    "0": "2000",
    "1": "2003 Mixed",
    "2": "2003",
    "3": "2008",
    "4": "2008 R2",
    "5": "2012",
    "6": "2012 R2",
    "7": "2016+",
}




def _first(value):
    if isinstance(value, list):
        return value[0] if value else None
    return value


def _raw_filetime_int(entry, attr_name):
    """Read an AD FILETIME-interval attribute as a plain signed int.

    ldap3 recognizes maxPwdAge, minPwdAge, lockoutDuration and
    lockOutObservationWindow by OID and silently reformats `.value` into a
    `datetime.timedelta` (see ldap3.protocol.formatters.standard /
    format_ad_timedelta). safe_int() can't convert a timedelta, so reading
    `.value` for these four attributes always fell back to the default
    (previously a misleading 0, now a misleading None), regardless of what
    the DC actually returned. `.raw_values` bypasses that formatter and
    gives the attribute's original wire value (a byte string holding the
    signed 100ns-interval integer, e.g. b'-18000000000'), which is what
    _filetime_interval_to_minutes() expects. Returns None only when the
    attribute truly wasn't returned or isn't a parseable integer.
    """
    raw_values = entry[attr_name].raw_values
    if not raw_values:
        return None
    try:
        return int(raw_values[0])
    except (TypeError, ValueError):
        return None


def _safe_search(ldap, base_dn, ldap_filter, attributes, scope="SUBTREE"):
    try:
        return ldap.search(base_dn, ldap_filter, attributes, scope=scope)
    except Exception as exc:
        logger.debug("domains collector sub-query against %s failed: %s", base_dn, exc)
        return []


def _parse_dns_a_records(raw_values):
    ips = []
    for raw in raw_values or []:
        if not raw or len(raw) < _DNS_RECORD_HEADER_LEN:
            continue
        data_length, record_type = struct.unpack_from("<HH", raw, 0)
        if record_type != _DNS_TYPE_A:
            continue
        data = raw[_DNS_RECORD_HEADER_LEN:_DNS_RECORD_HEADER_LEN + data_length]
        if len(data) == 4:
            ips.append(socket.inet_ntoa(data))
    return ips


def _lookup_dns_a_records(ldap, dns_hostname, domain_dn):
    if not dns_hostname or "." not in str(dns_hostname):
        return []
    label, zone = str(dns_hostname).split(".", 1)
    zone_containers = (
        f"DC={zone},CN=MicrosoftDNS,DC=DomainDnsZones,{domain_dn}",
        f"DC={zone},CN=MicrosoftDNS,CN=System,{domain_dn}",
    )
    for zone_container in zone_containers:
        node_entries = _safe_search(
            ldap, f"DC={label},{zone_container}", "(objectClass=dnsNode)", ["dnsRecord"], scope="BASE"
        )
        if node_entries:
            ips = _parse_dns_a_records(node_entries[0]["dnsRecord"].raw_values)
            if ips:
                return ips
    return []


def _role_owner_name(dn_value):
    if not dn_value:
        return None
    parts = [part.strip() for part in str(dn_value).split(",")]
    for index, part in enumerate(parts):
        if part.lower() == "cn=ntds settings" and index + 1 < len(parts):
            return parts[index + 1].split("=", 1)[-1]
    return None


def _ldap_escape_sid_bytes(sid_bytes):
    """Hex-escape a binary SID for use as an LDAP filter value (RFC 4515)."""
    return "".join(f"\\{b:02x}" for b in sid_bytes)


def _rid_sid_bytes(domain_sid_bytes, rid):
    """Build the binary SID of <domain_sid>-<rid> from the domain's own
    binary objectSid, by appending one more sub-authority. Used to find the
    built-in Guest account (RID 501) even if it has been renamed -- its
    sAMAccountName can change, its RID cannot."""
    sub_authority_count = domain_sid_bytes[1]
    revision_and_authority = domain_sid_bytes[0:8]
    sub_authorities = domain_sid_bytes[8:8 + 4 * sub_authority_count]
    return (
        revision_and_authority[0:1]
        + bytes([sub_authority_count + 1])
        + revision_and_authority[2:8]
        + sub_authorities
        + struct.pack("<I", rid)
    )


def _lookup_guest_account(ldap, domain_dn, domain_sid_bytes):
    """Find and assess the built-in Guest account (SID RID 501).

    Tries the default location (CN=Guest,CN=Users,<domain>) first, since
    that covers the overwhelming majority of domains and costs one cheap
    base-scope lookup. Falls back to a subtree search by binary objectSid
    for the RID-501 SID, which still finds the account if it has been
    renamed and/or moved to a different OU -- renaming Guest is a common
    hardening step, but it doesn't change its RID.
    """
    result = {
        "found": False,
        "sam_account_name": None,
        "dn": None,
        "enabled": None,
        "pwd_last_set": None,
        "last_logon": None,
        "description": None,
        "error": None,
    }
    try:
        entries = _safe_search(
            ldap, f"CN=Guest,CN=Users,{domain_dn}", "(objectClass=user)", _GUEST_ATTRS, scope="BASE"
        )
        if not entries and domain_sid_bytes:
            guest_sid_bytes = _rid_sid_bytes(domain_sid_bytes, _RID_GUEST)
            entries = _safe_search(
                ldap,
                domain_dn,
                f"(objectSid={_ldap_escape_sid_bytes(guest_sid_bytes)})",
                _GUEST_ATTRS,
            )
        if not entries:
            return result

        entry = entries[0]
        uac = safe_int(normalize_value(entry["userAccountControl"].value), default=None)
        result.update(
            {
                "found": True,
                "sam_account_name": normalize_value(entry["sAMAccountName"].value),
                "dn": str(entry["distinguishedName"].value),
                "enabled": (not bool(uac & UAC_FLAGS["ACCOUNTDISABLE"])) if uac is not None else None,
                "pwd_last_set": ldap_timestamp_to_iso(normalize_value(entry["pwdLastSet"].value)),
                "last_logon": ldap_timestamp_to_iso(normalize_value(entry["lastLogonTimestamp"].value)),
                "description": normalize_value(entry["description"].value),
            }
        )
    except Exception as exc:
        logger.debug("guest account lookup failed: %s", exc)
        result["error"] = str(exc)
    return result


def _filetime_interval_to_minutes(raw):
    # `raw` is a FILETIME interval in 100ns units (negative, per AD
    # convention). A genuine 0 is a meaningful AD value here -- for
    # lockoutDuration it means "locked out accounts are never
    # auto-unlocked, an admin must unlock them manually" -- so it must
    # convert to 0.0, not be swallowed into the same `None` used for
    # "attribute could not be read". Only `None` (missing/unreadable)
    # should short-circuit; `if not raw` used to also catch 0.
    if raw is None:
        return None
    return round(abs(raw) / 10_000_000 / 60, 2)


# Int64.MinValue: the sentinel AD stores in maxPwdAge (and sometimes
# minPwdAge) to mean "never" -- e.g. "passwords never expire". Converting
# this through the usual filetime-interval math would print as ~29,247
# years, which is technically correct but not what a reader expects.
_FILETIME_NEVER = -9223372036854775808


def _filetime_interval_to_days(raw):
    if raw is None or raw == _FILETIME_NEVER:
        return None
    return round(abs(raw) / 10_000_000 / 86400, 2)


def _filetime_is_never(raw):
    if raw is None:
        return None
    return raw == _FILETIME_NEVER


def _probe_anonymous_bind(host, port=389, timeout=Config.LDAP_CONNECT_TIMEOUT):
    probe = {"allowed": None, "visible_naming_contexts": [], "error": None}
    try:
        server = Server(host, port=port, use_ssl=False, get_info=ALL, connect_timeout=timeout)
        conn = Connection(server, authentication=ANONYMOUS, receive_timeout=timeout)
        if conn.bind():
            probe["allowed"] = True
            contexts = server.info.naming_contexts if server.info else None
            probe["visible_naming_contexts"] = list(contexts) if contexts else []
            conn.unbind()
        else:
            probe["allowed"] = False
            probe["error"] = (conn.result or {}).get("description")
    except Exception as exc:
        probe["error"] = str(exc)
    return probe


def _ensure_utc(value):
    return value if value.tzinfo else value.replace(tzinfo=timezone.utc)


def _parse_ca_certificate(raw_cert):
    info = {
        "subject": None,
        "issuer": None,
        "serial_number": None,
        "thumbprint_sha1": None,
        "not_before": None,
        "not_after": None,
        "expired": None,
        "self_signed": None,
        "error": None,
    }
    if not raw_cert:
        return info
    try:
        from cryptography import x509
        from cryptography.hazmat.primitives import hashes
    except ImportError as exc:
        info["error"] = str(exc)
        return info
    try:
        certificate = x509.load_der_x509_certificate(bytes(raw_cert))
        not_before = _ensure_utc(getattr(certificate, "not_valid_before_utc", None) or certificate.not_valid_before)
        not_after = _ensure_utc(getattr(certificate, "not_valid_after_utc", None) or certificate.not_valid_after)
        info.update(
            {
                "subject": certificate.subject.rfc4514_string(),
                "issuer": certificate.issuer.rfc4514_string(),
                "serial_number": format(certificate.serial_number, "x"),
                "thumbprint_sha1": certificate.fingerprint(hashes.SHA1()).hex(),
                "not_before": not_before.isoformat(),
                "not_after": not_after.isoformat(),
                "expired": not_after < datetime.now(timezone.utc),
                "self_signed": certificate.subject == certificate.issuer,
            }
        )
    except Exception as exc:
        info["error"] = str(exc)
    return info


def _discover_certificate_authorities(ldap, config_dn):
    discovery = {
        "enterprise_cas": [],
        "root_cas": [],
        "ntauth_cas": [],
        "has_enterprise_ca": False,
    }
    if not config_dn:
        return discovery

    pki_root = f"CN=Public Key Services,CN=Services,{config_dn}"

    enrollment_entries = _safe_search(
        ldap,
        f"CN=Enrollment Services,{pki_root}",
        "(objectClass=pKIEnrollmentService)",
        ["cn", "dNSHostName", "cACertificate", "flags"],
    )
    for entry in enrollment_entries:
        cert_raw = entry["cACertificate"].raw_values
        discovery["enterprise_cas"].append(
            {
                "object_type": "EnrollmentService",
                "name": normalize_value(entry["cn"].value),
                "dns_hostname": normalize_value(entry["dNSHostName"].value),
                "flags": safe_int(normalize_value(entry["flags"].value), default=None),
                "certificate": _parse_ca_certificate(cert_raw[0] if cert_raw else None),
            }
        )

    root_ca_entries = _safe_search(
        ldap,
        f"CN=Certification Authorities,{pki_root}",
        "(objectClass=certificationAuthority)",
        ["cn", "cACertificate"],
        scope="LEVEL",
    )
    for entry in root_ca_entries:
        cert_raw = entry["cACertificate"].raw_values
        discovery["root_cas"].append(
            {
                "object_type": "CA",
                "name": normalize_value(entry["cn"].value),
                "certificate": _parse_ca_certificate(cert_raw[0] if cert_raw else None),
            }
        )

    ntauth_entries = _safe_search(
        ldap,
        f"CN=NTAuthCertificates,{pki_root}",
        "(objectClass=certificationAuthority)",
        ["cn", "cACertificate"],
        scope="BASE",
    )
    for entry in ntauth_entries:
        name = normalize_value(entry["cn"].value)
        for raw_cert in entry["cACertificate"].raw_values or []:
            discovery["ntauth_cas"].append(
                {"object_type": "CA", "name": name, "certificate": _parse_ca_certificate(raw_cert)}
            )

    discovery["has_enterprise_ca"] = bool(discovery["enterprise_cas"])
    return discovery


def _derive_ldap_signing(anonymous_probe):
    probe = {"required": None, "basis": None, "error": None}
    allowed = anonymous_probe.get("allowed")
    if allowed is True:
        probe["required"] = False
        probe["basis"] = "unsigned anonymous bind and search succeeded over plaintext LDAP"
    elif allowed is False:
        probe["basis"] = "anonymous bind rejected; signing requirement cannot be confirmed without an unsigned authenticated probe"
    else:
        probe["error"] = anonymous_probe.get("error")
    return probe


_GPT_TMPL_RELATIVE_SUFFIX = "MACHINE\\Microsoft\\Windows NT\\SecEdit\\GptTmpl.inf"


def _lookup_default_domain_policy(ldap, domain_dn):
    entries = _safe_search(
        ldap,
        f"CN=Policies,CN=System,{domain_dn}",
        "(&(objectClass=groupPolicyContainer)(displayName=Default Domain Policy))",
        ["cn", "gPCFileSysPath"],
    )
    if not entries:
        return None
    return normalize_value(entries[0]["gPCFileSysPath"].value)


def _sysvol_relative_path(fs_path):
    if not fs_path:
        return None
    parts = [part for part in str(fs_path).split("\\") if part]
    try:
        sysvol_index = next(index for index, part in enumerate(parts) if part.lower() == "sysvol")
    except StopIteration:
        return None
    policy_dir = "\\".join(parts[sysvol_index + 1:])
    if not policy_dir:
        return None
    return f"{policy_dir}\\{_GPT_TMPL_RELATIVE_SUFFIX}"


def _decode_gpt_tmpl(raw_bytes):
    for encoding in ("utf-16", "utf-8-sig", "latin-1"):
        try:
            return raw_bytes.decode(encoding)
        except (UnicodeError, LookupError):
            continue
    return raw_bytes.decode("latin-1", errors="replace")


def _parse_kerberos_policy_section(text):
    parser = configparser.ConfigParser(strict=False, interpolation=None)
    try:
        parser.read_string(text)
    except configparser.Error:
        return None
    if not parser.has_section("Kerberos Policy"):
        return None
    section = parser["Kerberos Policy"]
    return {
        "MaxTicketAge": safe_int(section.get("MaxTicketAge"), default=None),
        "MaxRenewAge": safe_int(section.get("MaxRenewAge"), default=None),
        "MaxServiceAge": safe_int(section.get("MaxServiceAge"), default=None),
        "MaxClockSkew": safe_int(section.get("MaxClockSkew"), default=None),
        "TicketValidateClient": safe_int(section.get("TicketValidateClient"), default=None),
    }


def _fetch_kerberos_policy(ldap, session, domain_dn):
    result = {
        "max_ticket_age_hours": None,
        "max_renew_age_days": None,
        "max_service_age_minutes": None,
        "max_clock_skew_minutes": None,
        "ticket_validate_client": None,
        "source": None,
        "error": None,
    }

    fs_path = _lookup_default_domain_policy(ldap, domain_dn)
    if not fs_path:
        result["error"] = "Default Domain Policy GPO not found"
        return result

    relative_path = _sysvol_relative_path(fs_path)
    if not relative_path:
        result["error"] = f"could not derive a SYSVOL-relative path from {fs_path!r}"
        return result

    raw_bytes, read_error = read_sysvol_file(session.target, session.credentials, relative_path)
    if raw_bytes is None:
        result["error"] = read_error
        return result

    policy = _parse_kerberos_policy_section(_decode_gpt_tmpl(raw_bytes))
    if not policy:
        result["error"] = "Kerberos Policy section not present in GptTmpl.inf"
        return result

    validate_client = policy.get("TicketValidateClient")
    result.update(
        {
            "max_ticket_age_hours": policy.get("MaxTicketAge"),
            "max_renew_age_days": policy.get("MaxRenewAge"),
            "max_service_age_minutes": policy.get("MaxServiceAge"),
            "max_clock_skew_minutes": policy.get("MaxClockSkew"),
            "ticket_validate_client": bool(validate_client) if validate_client is not None else None,
            "source": fs_path,
        }
    )
    return result


class DomainsModule(BaseModule):
    name = "domains"

    def run(self, session: Session) -> ModuleResult:
        try:
            ldap = session.ldap()
            entries = ldap.search(session.base_dn, "(objectClass=domain)", _DOMAIN_ATTRS, scope=BASE)
        except Exception as exc:
            logger.warning("domains collector failed: %s", exc)
            return ModuleResult([], {"success": False, "count": 0, "error": str(exc), "meta": {}})

        if not entries:
            logger.warning("domains collector failed: domain object not found")
            return ModuleResult(
                [], {"success": False, "count": 0, "error": "domain object not found", "meta": {}}
            )

        entry = entries[0]
        domain_dn = str(entry["distinguishedName"].value)

        sid_raw = entry["objectSid"].raw_values
        sid = sid_bytes_to_str(sid_raw[0]) if sid_raw else None
        if sid:
            session.domain_sid = sid

        level_raw = str(safe_int(normalize_value(entry["msDS-Behavior-Version"].value)))
        pwd_properties = safe_int(normalize_value(entry["pwdProperties"].value))

        domain = ADDomain(
            name=str(normalize_value(entry["name"].value)),
            dn=domain_dn,
            sid=sid,
            functional_level=_FUNCTIONAL_LEVELS.get(level_raw, level_raw),
            # Keys below are kept identical to their LDAP attribute names
            # (maxPwdAge, minPwdAge, ...) end-to-end, including in the
            # domain_info.jsonl output written by api/backends.py, so a
            # reader can map a field straight back to the AD schema
            # attribute it came from. lockoutDuration and
            # lockOutObservationWindow are still converted from raw FILETIME
            # (100ns intervals) to minutes for readability; the two "_mins"
            # suffixes are the only departure from a literal LDAP name.
            # default=None on every call below: safe_int()'s own default is
            # 0, which would make "attribute missing/unreadable" look
            # identical to "attribute is genuinely 0" (e.g. lockoutDuration
            # == 0 means "never auto-unlocks, admin must unlock manually" --
            # a real, security-relevant policy value, not a gap in the
            # data). Passing default=None keeps those two cases distinct in
            # the output: a true null means the attribute wasn't read.
            password_policy={
                # maxPwdAge / minPwdAge: ldap3 reformats `.value` into a
                # timedelta for these (see _raw_filetime_int), so they're
                # read from raw_values, not normalize_value(...).value.
                # The *_days fields add a human-readable figure alongside
                # the raw LDAP integer; maxPwdAge_never_expires flags the
                # Int64.MinValue "never" sentinel explicitly instead of
                # letting it print as a nonsense day count.
                "maxPwdAge": _raw_filetime_int(entry, "maxPwdAge"),
                "maxPwdAge_days": _filetime_interval_to_days(_raw_filetime_int(entry, "maxPwdAge")),
                "maxPwdAge_never_expires": _filetime_is_never(_raw_filetime_int(entry, "maxPwdAge")),
                "minPwdAge": _raw_filetime_int(entry, "minPwdAge"),
                "minPwdAge_days": _filetime_interval_to_days(_raw_filetime_int(entry, "minPwdAge")),
                "minPwdLength": safe_int(normalize_value(entry["minPwdLength"].value), default=None),
                "pwdHistoryLength": safe_int(normalize_value(entry["pwdHistoryLength"].value), default=None),
                "lockoutThreshold": safe_int(normalize_value(entry["lockoutThreshold"].value), default=None),
                # lockoutDuration / lockOutObservationWindow: same ldap3
                # timedelta reformatting applies, so these are also read
                # from raw_values before being converted to minutes.
                "lockoutDuration_mins": _filetime_interval_to_minutes(
                    _raw_filetime_int(entry, "lockoutDuration")
                ),
                "lockOutObservationWindow_mins": _filetime_interval_to_minutes(
                    _raw_filetime_int(entry, "lockOutObservationWindow")
                ),
                "pwdProperties": pwd_properties,
                "complexityEnabled": bool(pwd_properties & 0x1),
            },
        )

        domain.smb_signing_required = check_smb_signing(session.target).get("signing_required")
        os_info = get_os_info(session.target)
        domain.os_info = os_info

        guest_account = _lookup_guest_account(ldap, domain_dn, sid_raw[0] if sid_raw else None)
        null_session = check_null_session(session.target)
        domain.guest_account = guest_account
        domain.null_session = null_session

        info_other = ldap.server.info.other if ldap.server.info else {}
        config_dn = _first(info_other.get("configurationNamingContext"))
        schema_dn = _first(info_other.get("schemaNamingContext"))
        root_dn = _first(info_other.get("rootDomainNamingContext")) or domain_dn

        netbios_name = None
        if config_dn:
            partitions_entries = _safe_search(
                ldap,
                f"CN=Partitions,{config_dn}",
                f"(&(objectClass=crossRef)(nCName={domain_dn}))",
                ["nETBIOSName"],
            )
            if partitions_entries:
                netbios_name = normalize_value(partitions_entries[0]["nETBIOSName"].value)

        dc_entries = _safe_search(
            ldap,
            domain_dn,
            "(&(objectCategory=computer)(userAccountControl:1.2.840.113556.1.4.803:=8192))",
            _DC_ATTRS,
        )
        domain_controllers = []
        for dc_entry in dc_entries:
            dns_hostname = normalize_value(dc_entry["dNSHostName"].value)
            dc_sid_raw = dc_entry["objectSid"].raw_values
            dc_ips = _lookup_dns_a_records(ldap, dns_hostname, domain_dn)
            domain_controllers.append(
                {
                    "name": normalize_value(dc_entry["name"].value),
                    "dns_hostname": dns_hostname,
                    "ip_address": dc_ips[0] if dc_ips else None,
                    "ip_addresses": dc_ips,
                    "sid": sid_bytes_to_str(dc_sid_raw[0]) if dc_sid_raw else None,
                    "operating_system": normalize_value(dc_entry["operatingSystem"].value),
                }
            )

        fsmo = {"pdc_emulator": _role_owner_name(normalize_value(entry["fSMORoleOwner"].value))}

        rid_entries = _safe_search(
            ldap, f"CN=RID Manager$,CN=System,{domain_dn}", "(objectClass=*)", ["fSMORoleOwner"], scope="BASE"
        )
        fsmo["rid_master"] = (
            _role_owner_name(normalize_value(rid_entries[0]["fSMORoleOwner"].value)) if rid_entries else None
        )

        infra_entries = _safe_search(
            ldap, f"CN=Infrastructure,{domain_dn}", "(objectClass=*)", ["fSMORoleOwner"], scope="BASE"
        )
        fsmo["infrastructure_master"] = (
            _role_owner_name(normalize_value(infra_entries[0]["fSMORoleOwner"].value)) if infra_entries else None
        )

        if schema_dn:
            schema_role_entries = _safe_search(ldap, schema_dn, "(objectClass=*)", ["fSMORoleOwner"], scope="BASE")
            fsmo["schema_master"] = (
                _role_owner_name(normalize_value(schema_role_entries[0]["fSMORoleOwner"].value))
                if schema_role_entries
                else None
            )
        else:
            fsmo["schema_master"] = None

        if config_dn:
            naming_entries = _safe_search(
                ldap, f"CN=Partitions,{config_dn}", "(objectClass=*)", ["fSMORoleOwner"], scope="BASE"
            )
            fsmo["domain_naming_master"] = (
                _role_owner_name(normalize_value(naming_entries[0]["fSMORoleOwner"].value))
                if naming_entries
                else None
            )
        else:
            fsmo["domain_naming_master"] = None

        global_catalogs = []
        if config_dn:
            gc_entries = _safe_search(
                ldap,
                f"CN=Sites,{config_dn}",
                "(&(objectClass=nTDSDSA)(options:1.2.840.113556.1.4.803:=1))",
                ["distinguishedName"],
            )
            for gc_entry in gc_entries:
                owner_name = _role_owner_name(str(gc_entry["distinguishedName"].value))
                if owner_name:
                    global_catalogs.append(owner_name)

        dns_zones = []
        for partition_label, zones_base_dn in (
            ("domain", f"CN=MicrosoftDNS,DC=DomainDnsZones,{domain_dn}"),
            ("forest", f"CN=MicrosoftDNS,DC=ForestDnsZones,{root_dn}"),
            ("legacy", f"CN=MicrosoftDNS,CN=System,{domain_dn}"),
        ):
            zone_entries = _safe_search(ldap, zones_base_dn, "(objectClass=dnsZone)", ["name"])
            for zone_entry in zone_entries:
                zone_name = normalize_value(zone_entry["name"].value)
                if zone_name:
                    dns_zones.append({"name": zone_name, "partition": partition_label})

        laps = {
            "legacy_schema_present": False,
            "windows_schema_present": False,
            "legacy_deployed_count": 0,
            "windows_deployed_count": 0,
        }
        if schema_dn:
            laps_schema_entries = _safe_search(
                ldap, schema_dn, "(|(name=ms-Mcs-AdmPwd)(name=msLAPS-Password))", ["name"]
            )
            schema_names = {str(normalize_value(e["name"].value)) for e in laps_schema_entries}
            laps["legacy_schema_present"] = "ms-Mcs-AdmPwd" in schema_names
            laps["windows_schema_present"] = "msLAPS-Password" in schema_names

        if laps["legacy_schema_present"]:
            laps["legacy_deployed_count"] = len(
                _safe_search(ldap, domain_dn, "(ms-Mcs-AdmPwdExpirationTime=*)", ["distinguishedName"])
            )
        if laps["windows_schema_present"]:
            laps["windows_deployed_count"] = len(
                _safe_search(ldap, domain_dn, "(msLAPS-PasswordExpirationTime=*)", ["distinguishedName"])
            )

        ca_discovery = _discover_certificate_authorities(ldap, config_dn)

        kerberos_policy = _fetch_kerberos_policy(ldap, session, domain_dn)

        ntlm_supported = os_info.get("error") is None and bool(
            os_info.get("netbios_name") or os_info.get("domain") or os_info.get("os")
        )

        anonymous_bind = _probe_anonymous_bind(session.target)

        credentials = session.credentials
        if credentials.auth_method == AuthMethod.KERBEROS_CCACHE:
            ldap_signing = _derive_ldap_signing(anonymous_bind)
            ldap_channel_binding = {
                "enforced": None,
                "error": "channel binding probe requires NTLM/simple credentials, not a Kerberos ccache",
            }
        else:
            ldap_signing = check_ldap_signing(
                session.target,
                credentials.domain,
                credentials.username,
                credentials.password or "",
                "",
                credentials.nt_hash or "",
            )
            ldap_channel_binding = check_ldap_channel_binding(
                session.target,
                credentials.domain,
                credentials.username,
                credentials.password or "",
                "",
                credentials.nt_hash or "",
            )

        # Mirror the discovered data onto the ADDomain object's own fields too
        # (not just `meta`), so consumers reading the domain model directly
        # see domain_controllers / fsmo_roles / dns_zones / laps /
        # authentication_security / null_anonymous_access populated.
        domain.domain_controllers = domain_controllers
        domain.fsmo_roles = fsmo
        domain.dns_zones = [zone["name"] for zone in dns_zones if zone.get("name")]
        domain.laps = laps
        domain.authentication_security = {
            "ntlm_supported": ntlm_supported,
            "ldap_signing": ldap_signing,
            "ldap_channel_binding": ldap_channel_binding,
        }
        domain.null_anonymous_access = anonymous_bind
        domain.ca_discovery = ca_discovery
        domain.kerberos_policy = kerberos_policy

        meta = {
            "netbios_name": netbios_name,
            "domain_controllers": domain_controllers,
            "fsmo": fsmo,
            "global_catalogs": global_catalogs,
            "dns_zones": dns_zones,
            "laps": laps,
            "ca_discovery": ca_discovery,
            "kerberos_policy": kerberos_policy,
            "ntlm_supported": ntlm_supported,
            "ldap_signing": ldap_signing,
            "ldap_channel_binding": ldap_channel_binding,
            "anonymous_bind": anonymous_bind,
            "guest_account": guest_account,
            "null_session": null_session,
        }

        result = {"success": True, "count": 1, "error": None, "meta": meta}
        return ModuleResult([domain], result)