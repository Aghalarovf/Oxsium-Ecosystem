import re

GUID_PATTERN = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")


def _clean(value):
    return str(value or "").strip().strip("{}").lower()


def guid_entries(ctx):
    entries = []
    seen = set()
    guids = set()

    def put(right, guid, kind=""):
        guid = _clean(guid)
        if not GUID_PATTERN.fullmatch(guid) or (right, guid) in seen:
            return
        seen.add((right, guid))
        guids.add(guid)
        entries.append({"right": right or "", "guid": guid, "kind": kind or ""})

    for item in ctx.get("rights_details") or []:
        if isinstance(item, dict):
            put(item.get("right"), item.get("guid"), item.get("kind"))
    rights = ctx.get("rights") or []
    label = rights[0] if rights else ""
    for value in (ctx.get("object_guid"), ctx.get("object_acetype")):
        if _clean(value) not in guids:
            put(label, value)
    return entries


def merge_guids(target, entries):
    known = {(item["right"], item["guid"]) for item in target}
    for item in entries:
        key = (item["right"], item["guid"])
        if key not in known:
            known.add(key)
            target.append(item)
    return target