"""Nodes that end a chain, driven by the chain-stop rules in rules/00_core/chain_stop.yaml."""
from . import ingest, rules_engine
from .rules_engine.matcher import evaluate
from .rules_engine.normalize import normalize_dn, normalize_sid

SID_FIELDS = ("sid", "object_sid", "objectsid", "group_sid", "computer_sid")
DN_FIELDS = ("dn", "group_dn", "distinguishedname")
COMBINATORS = ("all_of", "any_of", "none_of")


def _condition_fields(condition, found):
    if not isinstance(condition, dict):
        return found
    for key, value in condition.items():
        if key in COMBINATORS:
            for child in value:
                _condition_fields(child, found)
        elif key in ("field_equals", "field_in"):
            found.add(value["field"])
        elif key == "field_truthy":
            found.update([value] if isinstance(value, str) else value)
    return found


class ChainStops:
    def __init__(self, sids=(), dns=()):
        self.sids = {sid for sid in (normalize_sid(item) for item in sids) if sid}
        self.dns = {dn for dn in (normalize_dn(item) for item in dns) if dn}

    @classmethod
    def load(cls, connection):
        sids, dns = set(), set()
        for rule in rules_engine.chain_stop_rules():
            condition = rule.raw.get("match", {})
            fields = sorted(_condition_fields(condition, set()))
            wanted = tuple(fields) + SID_FIELDS + DN_FIELDS
            for row in ingest.read_table(connection, rule.raw["source_table"], wanted):
                if not evaluate(condition, row):
                    continue
                sids.update(row[name] for name in SID_FIELDS if row.get(name))
                dns.update(row[name] for name in DN_FIELDS if row.get(name))
        return cls(sids, dns)

    def blocks(self, sid=None, dn=None):
        """True when the node is a chain stop, so chains must not continue past it."""
        return normalize_sid(sid) in self.sids or normalize_dn(dn) in self.dns

    def __len__(self):
        return len(self.sids) + len(self.dns)
