import json
import sqlite3
from contextlib import contextmanager

from config import DOMAIN_DATABASE_PATH

NON_ALLOW_ACE_TYPES = (1, 6, 10, 12)


@contextmanager
def connect(path=None):
    connection = sqlite3.connect(path or DOMAIN_DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    try:
        yield connection
    finally:
        connection.close()


def fetch_ace_rows(connection, search="", dangerous_only=True, limit=500, target_type="", principal="", target="", right=""):
    clauses = ["principal_sid IS NOT NULL", "target_sid IS NOT NULL", "principal_sid != target_sid"]
    params = []
    if dangerous_only:
        clauses.append("dangerous_ace = 1")
        clauses.append(f"ace_type_raw NOT IN ({','.join(str(v) for v in NON_ALLOW_ACE_TYPES)})")
    if search:
        clauses.append("(principal_name LIKE ? OR target_name LIKE ?)")
        like = f"%{search}%"
        params.extend([like, like])
    if target_type:
        clauses.append("LOWER(target_type) LIKE ?")
        params.append(f"%{target_type.lower()}%")
    if principal:
        clauses.append("(principal_name LIKE ? OR principal_sid = ?)")
        params.extend([f"%{principal}%", principal])
    if target:
        clauses.append("(target_name LIKE ? OR target_sid = ?)")
        params.extend([f"%{target}%", target])
    if right:
        clauses.append("rights LIKE ?")
        params.append(f"%{right}%")
    sql = (
        "SELECT principal_sid, principal_name, target_sid, target_dn, target_name, target_type, rights "
        f"FROM domain_aces WHERE {' AND '.join(clauses)} LIMIT ?"
    )
    params.append(int(limit))
    try:
        rows = connection.execute(sql, params).fetchall()
    except sqlite3.Error:
        return []
    result = []
    for row in rows:
        item = dict(row)
        try:
            item["rights"] = json.loads(item["rights"] or "[]")
        except (TypeError, json.JSONDecodeError):
            item["rights"] = []
        result.append(item)
    return result
