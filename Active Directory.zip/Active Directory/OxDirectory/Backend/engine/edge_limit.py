from collections import Counter

from .graph import _layers

DEFAULT_MAX_RIGHT_EDGES = 50
MAX_RIGHT_EDGES_CEILING = 1000000
MEMBERSHIP_TYPE = "MemberOf"
RISK_RANK = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}


def _truthy(value):
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "on")
    return bool(value)


def parse_options(options):
    options = options if isinstance(options, dict) else {}
    show_all = _truthy(options.get("show_all_rights", False))
    raw = options.get("max_right_edges")
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        maximum = DEFAULT_MAX_RIGHT_EDGES
    else:
        if isinstance(raw, bool):
            raise ValueError("Max Right Edges must be a whole number")
        try:
            maximum = int(str(raw).strip())
        except (TypeError, ValueError):
            raise ValueError("Max Right Edges must be a whole number")
        if maximum < 1:
            raise ValueError("Max Right Edges must be at least 1")
        maximum = min(maximum, MAX_RIGHT_EDGES_CEILING)
    return {"show_all_rights": show_all, "max_right_edges": maximum}


def _weight(edge):
    value = edge.get("weight")
    return float(value) if isinstance(value, (int, float)) else 0.0


def _priority(edge, continuing):
    return (
        -RISK_RANK.get(edge.get("risk"), 0),
        0 if edge["target"] in continuing else 1,
        _weight(edge),
        -len(edge.get("rights") or ()),
        str(edge.get("label") or edge.get("type") or ""),
        str(edge["target"]),
    )


def _prune_unreachable(edges, had_outgoing, had_incoming):
    while True:
        sources = {edge["source"] for edge in edges}
        targets = {edge["target"] for edge in edges}
        kept = [
            edge for edge in edges
            if (edge["target"] not in had_outgoing or edge["target"] in sources)
            and (edge["source"] not in had_incoming or edge["source"] in targets)
        ]
        if len(kept) == len(edges):
            return kept
        edges = kept


def limits_summary(options, total, shown):
    return {
        "show_all_rights": options["show_all_rights"],
        "max_right_edges": options["max_right_edges"],
        "total_edges": total,
        "shown_edges": shown,
        "limited_edges": total - shown,
    }


def apply_limit(graph, options):
    edges = graph.get("edges") or []
    total = len(edges)
    if options["show_all_rights"] or not total:
        graph["limits"] = limits_summary(options, total, total)
        return graph
    maximum = options["max_right_edges"]
    by_source = {}
    for edge in edges:
        if edge.get("type") != MEMBERSHIP_TYPE:
            by_source.setdefault(edge["source"], []).append(edge)
    had_outgoing = {edge["source"] for edge in edges}
    had_incoming = {edge["target"] for edge in edges}
    dropped = set()
    for items in by_source.values():
        if len(items) > maximum:
            items.sort(key=lambda edge: _priority(edge, had_outgoing))
            dropped.update(id(edge) for edge in items[maximum:])
    if not dropped:
        graph["limits"] = limits_summary(options, total, total)
        return graph
    connected_before = had_outgoing | had_incoming
    kept = _prune_unreachable(
        [edge for edge in edges if id(edge) not in dropped],
        had_outgoing,
        had_incoming,
    )
    connected_now = {edge["source"] for edge in kept} | {edge["target"] for edge in kept}
    nodes = [
        node for node in graph["nodes"]
        if node["id"] in connected_now or node["id"] not in connected_before
    ]
    depth = _layers([node["id"] for node in nodes], kept)
    for node in nodes:
        node["layer"] = depth[node["id"]]
    graph["nodes"] = nodes
    graph["edges"] = kept
    graph["layers"] = (max(depth.values()) + 1) if depth else 0
    graph["limits"] = limits_summary(options, total, len(kept))
    return graph
