from .db import connect, fetch_ace_rows
from .privileges import annotate_nodes


def _node_kind(type_value):
    value = str(type_value or "").lower()
    if "user" in value:
        return "user"
    if "group" in value:
        return "group"
    if "computer" in value:
        return "computer"
    if value == "domain":
        return "domain"
    if "organizationalunit" in value or value == "ou":
        return "ou"
    if "gpo" in value or "grouppolicy" in value:
        return "gpo"
    return "other"


def _layers(node_ids, edges):
    outgoing = {node_id: [] for node_id in node_ids}
    indegree = {node_id: 0 for node_id in node_ids}
    for edge in edges:
        outgoing[edge["source"]].append(edge["target"])
        indegree[edge["target"]] += 1
    depth = {}
    queue = [node_id for node_id in node_ids if indegree[node_id] == 0]
    if not queue and node_ids:
        queue = [sorted(node_ids)[0]]
    for node_id in queue:
        depth[node_id] = 0
    visited = set()
    while queue:
        current = queue.pop(0)
        if current in visited:
            continue
        visited.add(current)
        for nxt in outgoing[current]:
            if nxt in visited:
                continue
            depth[nxt] = max(depth.get(nxt, 0), depth[current] + 1)
            queue.append(nxt)
    for node_id in node_ids:
        depth.setdefault(node_id, 0)
    return depth


class GraphBuilder:
    def __init__(self):
        self.nodes = {}
        self.edges = {}

    def add_node(self, node_id, name, kind="other", dn=None):
        node = self.nodes.get(node_id)
        if node is None:
            self.nodes[node_id] = {"id": node_id, "name": name or node_id, "kind": kind}
            if dn:
                self.nodes[node_id]["dn"] = dn
        elif node["kind"] == "other" and kind != "other":
            node["kind"] = kind
        return self.nodes[node_id]

    def add_edge(self, source, target, edge_type=None, rights=(), risk=None, weight=None, rule_id=None, evidence=None, types=None, guids=None):
        key = (source, target, edge_type or "")
        edge = self.edges.get(key)
        if edge is None:
            edge = {
                "source": source,
                "target": target,
                "type": edge_type,
                "risk": risk,
                "weight": weight,
                "rule_id": rule_id,
                "rights": [],
                "evidence": [],
                "types": types or [],
                "guids": [],
            }
            self.edges[key] = edge
        for right in rights:
            if right not in edge["rights"]:
                edge["rights"].append(right)
        for item in guids or ():
            if item not in edge["guids"]:
                edge["guids"].append(item)
        if evidence is not None:
            edge["evidence"].append(evidence)
        return edge

    def build(self):
        edge_list = list(self.edges.values())
        depth = _layers(list(self.nodes), edge_list)
        for node_id, node in self.nodes.items():
            node["layer"] = depth[node_id]
        for edge in edge_list:
            if edge["type"]:
                edge["label"] = edge["type"]
                edge["extra"] = max(len(edge["types"]) - 1, 0)
            else:
                edge["label"] = edge["rights"][0] if edge["rights"] else ""
                edge["extra"] = max(len(edge["rights"]) - 1, 0)
        return {
            "nodes": list(self.nodes.values()),
            "edges": edge_list,
            "layers": (max(depth.values()) + 1) if depth else 0,
        }


def graph_from_rows(rows):
    builder = GraphBuilder()
    for row in rows:
        # OUs and GPOs have no SID in the ACE table, so they are identified by DN.
        target_id = row["target_sid"] or row.get("target_dn") or row["target_sid"]
        builder.add_node(row["principal_sid"], row["principal_name"])
        builder.add_node(target_id, row["target_name"], _node_kind(row["target_type"]), dn=row.get("target_dn"))
        builder.add_edge(row["principal_sid"], target_id, rights=row["rights"])
    return builder.build()


def build_attack_graph(search="", limit=300, db_path=None, **filters):
    with connect(db_path) as connection:
        rows = fetch_ace_rows(connection, search=search, limit=limit, **filters)
        return annotate_nodes(connection, graph_from_rows(rows))