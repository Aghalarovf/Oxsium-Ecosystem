import threading
import time
from collections import deque

_LOCK = threading.Lock()
_ENTRIES = deque(maxlen=100)
_COUNTER = 0


def record(user, query_id, name, params, nodes, edges, elapsed_ms, error=None):
    global _COUNTER
    with _LOCK:
        _COUNTER += 1
        entry = {
            "id": _COUNTER,
            "user": user,
            "query_id": query_id,
            "name": name,
            "params": params,
            "nodes": nodes,
            "edges": edges,
            "elapsed_ms": elapsed_ms,
            "error": error,
            "timestamp": time.time(),
        }
        _ENTRIES.appendleft(entry)
    return entry


def list_entries(user=None, limit=50):
    with _LOCK:
        items = [entry for entry in _ENTRIES if user is None or entry["user"] == user]
    return items[:limit]


def clear(user=None):
    with _LOCK:
        keep = [entry for entry in _ENTRIES if user is not None and entry["user"] != user]
        _ENTRIES.clear()
        _ENTRIES.extend(keep)
