import json
import re
from typing import Any, Iterable, Iterator

IDENTIFIER = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
CHUNK = 500


def _quote(identifier):
    if not IDENTIFIER.fullmatch(identifier):
        raise ValueError(f"Invalid identifier: {identifier!r}")
    return f'"{identifier}"'


def table_exists(connection, table):
    row = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)
    ).fetchone()
    return row is not None


def attribute_columns(connection, table):
    if not table_exists(connection, "domain_attributes"):
        return {}
    rows = connection.execute(
        "SELECT attribute_name, column_name, value_type FROM domain_attributes WHERE table_name = ?",
        (table,),
    ).fetchall()
    return {str(row[0]).casefold(): (row[1], row[2]) for row in rows}


def _decode(value, value_type):
    if isinstance(value, str) and (value_type == "JSON" or value[:1] in ("[", "{")):
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value
    return value


def read_table(connection, table, wanted: Iterable[str]) -> Iterator[dict[str, Any]]:
    if not table_exists(connection, table):
        return
    columns = attribute_columns(connection, table)
    present = [name for name in wanted if name.casefold() in columns]
    if not present:
        return
    select = ", ".join(
        f"{_quote(columns[name.casefold()][0])} AS {_quote(name)}" for name in present
    )
    types = {name: columns[name.casefold()][1] for name in present}
    for row in connection.execute(f"SELECT {select} FROM {_quote(table)} ORDER BY id"):
        yield {name: _decode(row[name], types[name]) for name in present}


def read_aces_for_principals(connection, sids: Iterable[str]) -> Iterator[dict[str, Any]]:
    wanted = sorted({sid.upper() for sid in sids})
    for start in range(0, len(wanted), CHUNK):
        part = wanted[start:start + CHUNK]
        marks = ",".join("?" for _ in part)
        cursor = connection.execute(
            f"SELECT * FROM domain_aces WHERE UPPER(principal_sid) IN ({marks})", part
        )
        names = [column[0] for column in cursor.description]
        for row in cursor:
            yield dict(zip(names, row))


def read_all_aces(connection) -> Iterator[dict[str, Any]]:
    cursor = connection.execute(
        "SELECT * FROM domain_aces WHERE principal_sid IS NOT NULL AND target_sid IS NOT NULL"
    )
    names = [column[0] for column in cursor.description]
    for row in cursor:
        yield dict(zip(names, row))
