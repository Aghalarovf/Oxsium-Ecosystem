from collections import deque
from typing import Any, Optional

from . import ingest
from .rules_engine.normalize import normalize_dn, normalize_sid, parse_json_list


def _reference_keys(value):
    sid = dn = None
    if isinstance(value, dict):
        sid = normalize_sid(value.get("sid") or value.get("object_sid") or value.get("member_sid"))
        dn = normalize_dn(value.get("dn") or value.get("distinguishedName"))
    elif isinstance(value, str):
        text = value.strip()
        if text.upper().startswith("S-1-"):
            sid = normalize_sid(text)
        elif "=" in text:
            dn = normalize_dn(text)
    return sid, dn


class Directory:
    def __init__(self, connection):
        self.users: dict[str, dict[str, Any]] = {}
        self.groups: dict[str, dict[str, Any]] = {}
        self.computers: dict[str, dict[str, Any]] = {}
        self._group_by_dn: dict[str, str] = {}
        self._load_groups(connection)
        self._load_users(connection)
        self._load_computers(connection)

    def _load_groups(self, connection):
        wanted = ("group_sid", "group_dn", "group_name", "member_of")
        for row in ingest.read_table(connection, "domain_groups", wanted):
            sid = normalize_sid(row.get("group_sid"))
            if not sid:
                continue
            self.groups[sid] = {
                "kind": "group",
                "sid": sid,
                "name": row.get("group_name") or sid,
                "dn": row.get("group_dn"),
                "member_of": parse_json_list(row.get("member_of")),
            }
            dn = normalize_dn(row.get("group_dn"))
            if dn:
                self._group_by_dn[dn] = sid

    def _load_users(self, connection):
        wanted = ("sid", "username", "display_name", "dn", "member_of", "disabled")
        for row in ingest.read_table(connection, "domain_users", wanted):
            sid = normalize_sid(row.get("sid"))
            if not sid:
                continue
            self.users[sid] = {
                "kind": "user",
                "sid": sid,
                "name": row.get("username") or row.get("display_name") or sid,
                "display_name": row.get("display_name"),
                "dn": row.get("dn"),
                "member_of": parse_json_list(row.get("member_of")),
                "disabled": bool(row.get("disabled")),
            }

    def _load_computers(self, connection):
        wanted = ("sid", "computer_name", "dns_name", "dn", "member_of")
        for row in ingest.read_table(connection, "domain_computers", wanted):
            sid = normalize_sid(row.get("sid"))
            if not sid:
                continue
            self.computers[sid] = {
                "kind": "computer",
                "sid": sid,
                "name": row.get("computer_name") or row.get("dns_name") or sid,
                "display_name": row.get("dns_name"),
                "dn": row.get("dn"),
                "member_of": parse_json_list(row.get("member_of")),
            }

    def find_objects(self, needle: str, limit: int = 10) -> list[dict[str, Any]]:
        text = (needle or "").strip().casefold()
        if not text:
            return []
        pool = [*self.users.values(), *self.groups.values(), *self.computers.values()]
        exact = [
            item for item in pool
            if text in (
                item["sid"].casefold(),
                str(item["name"]).casefold(),
                str(item.get("display_name") or "").casefold(),
                str(item.get("dn") or "").casefold(),
            )
        ]
        if exact:
            return exact[:limit]
        partial = [
            item for item in pool
            if text in str(item["name"]).casefold() or text in str(item.get("display_name") or "").casefold()
        ]
        return partial[:limit]

    def find_users(self, needle: str, limit: int = 10) -> list[dict[str, Any]]:
        text = (needle or "").strip().casefold()
        if not text:
            return []
        exact = [
            user for user in self.users.values()
            if text in (user["sid"].casefold(), str(user["name"]).casefold(), str(user.get("display_name") or "").casefold())
        ]
        if exact:
            return exact[:limit]
        partial = [
            user for user in self.users.values()
            if text in str(user["name"]).casefold() or text in str(user.get("display_name") or "").casefold()
        ]
        return partial[:limit]

    def _parents(self, member_of) -> list[str]:
        parents = []
        for item in member_of:
            sid, dn = _reference_keys(item)
            resolved = sid if sid in self.groups else self._group_by_dn.get(dn or "")
            if resolved and resolved not in parents:
                parents.append(resolved)
        return parents

    def group_chains(self, user: dict[str, Any], stops=None) -> dict[str, list[str]]:
        """Group chains of a user. A group matching `stops` is kept in the chain but not expanded further."""
        chains: dict[str, list[str]] = {}
        queue: deque[tuple[str, list[str]]] = deque()
        for parent in self._parents(user["member_of"]):
            chains[parent] = [user["sid"], parent]
            queue.append((parent, chains[parent]))
        while queue:
            current, path = queue.popleft()
            if stops is not None and stops.blocks(sid=current, dn=self.groups[current].get("dn")):
                continue
            for parent in self._parents(self.groups[current]["member_of"]):
                if parent not in chains:
                    chains[parent] = path + [parent]
                    queue.append((parent, chains[parent]))
        return chains

    def membership_links(self):
        for sid, user in self.users.items():
            for parent in self._parents(user["member_of"]):
                yield sid, parent
        for sid, group in self.groups.items():
            for parent in self._parents(group["member_of"]):
                yield sid, parent

    def node_info(self, sid: str, fallback_name: Optional[str] = None) -> tuple[str, str]:
        if sid in self.users:
            return self.users[sid]["name"], "user"
        if sid in self.groups:
            return self.groups[sid]["name"], "group"
        if sid in self.computers:
            return self.computers[sid]["name"], "computer"
        return fallback_name or sid, "other"