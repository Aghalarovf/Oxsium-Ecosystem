import random

from .. import ingest, rules_engine
from ..ace_guids import guid_entries, merge_guids
from ..chain_stops import ChainStops
from ..graph import GraphBuilder, _node_kind
from ..membership import Directory
from ..rules_engine.normalize import normalize_sid

GROUP = "dangerous_aces"
IMPLICIT_PRINCIPALS = {"S-1-1-0": "Everyone", "S-1-5-11": "Authenticated Users"}
DEFAULT_MAX_TARGETS = 50
DEFAULT_MAX_TARGETS_ALL = 200
RISK_RANK = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
MAX_OBJECTS = 10


def run(connection, params):
    directory = Directory(connection)
    stops = ChainStops.load(connection)
    rules = rules_engine.ace_rules(group=GROUP)
    if not rules:
        raise ValueError(f"No ACE rules defined for group {GROUP}")
    needle = str(params.get("object", "") or "").strip()
    max_targets, max_targets_all, sampling = _limits(rules)
    subjects = []
    if needle:
        subjects = _resolve(connection, directory, needle)
        if not subjects:
            raise ValueError(f"Object not found: {needle}")
        collected = [_collect(connection, directory, rules, subject, stops) for subject in subjects]
    else:
        max_targets = max_targets_all
        collected = [_collect_all(connection, rules)]
    all_targets = {target for _, hits in collected for (_, target) in hits}
    kept = _select(all_targets, max_targets, sampling)
    builder = GraphBuilder()
    for subject in subjects:
        builder.add_node(subject["sid"], subject["name"], subject["kind"])
    for principals, hits in collected:
        for (principal, target), matches in hits.items():
            if target in kept:
                _add_hit(directory, builder, principals, principal, target, matches)
    graph = builder.build()
    graph["meta"] = {
        "mode": "object" if needle else "all",
        "object": needle,
        "objects": len(subjects),
        "total_targets": len(all_targets),
        "shown_targets": len(kept),
        "max_targets": max_targets,
        "sampling": sampling,
        "chain_stops": len(stops),
    }
    return graph


def _limits(rules):
    single, every = [], []
    sampling = "random"
    for rule in rules:
        limits = rule.raw.get("limits") or {}
        sampling = str(limits.get("sampling", sampling))
        for bucket, key in ((single, "max_targets"), (every, "max_targets_all_objects")):
            try:
                bucket.append(int(limits[key]))
            except (KeyError, TypeError, ValueError):
                continue
    max_single = max(min(single), 0) if single else DEFAULT_MAX_TARGETS
    max_all = max(min(every) if every else DEFAULT_MAX_TARGETS_ALL, 1)
    return max_single, max_all, sampling


def _select(targets, max_targets, sampling):
    ordered = sorted(targets)
    if max_targets <= 0 or len(ordered) <= max_targets:
        return set(ordered)
    if sampling == "random":
        return set(random.sample(ordered, max_targets))
    return set(ordered[:max_targets])


def _resolve(connection, directory, needle):
    found = directory.find_objects(needle, MAX_OBJECTS)
    if found:
        return found
    text = needle.casefold()
    cursor = connection.execute(
        "SELECT DISTINCT principal_sid, principal_name FROM domain_aces "
        "WHERE principal_sid IS NOT NULL AND (UPPER(principal_sid) = UPPER(?) OR LOWER(principal_name) LIKE ?) LIMIT ?",
        (needle, f"%{text}%", MAX_OBJECTS),
    )
    subjects = []
    for sid, name in cursor.fetchall():
        sid = normalize_sid(sid)
        if sid:
            subjects.append({"sid": sid, "name": name or sid, "kind": "other", "member_of": []})
    return subjects


def _match_row(rules, row, hits):
    ctx = rules_engine.ace_context(row)
    if ctx["is_deny"]:
        return
    principal = normalize_sid(row["principal_sid"])
    target = normalize_sid(row.get("target_sid")) or row.get("target_dn")
    if not principal or not target or target == principal:
        return
    for rule in rules:
        if rules_engine.match_ace(rule, ctx):
            hits.setdefault((principal, target), []).append((rules_engine.edge_attributes(rule), ctx))


def _read_every_ace(connection):
    cursor = connection.execute(
        "SELECT * FROM domain_aces WHERE principal_sid IS NOT NULL AND (target_sid IS NOT NULL OR target_dn IS NOT NULL)"
    )
    names = [column[0] for column in cursor.description]
    for row in cursor:
        yield dict(zip(names, row))


def _collect_all(connection, rules):
    hits = {}
    for row in _read_every_ace(connection):
        _match_row(rules, row, hits)
    principals = {principal: [principal] for principal, _ in hits}
    return principals, hits


def _collect(connection, directory, rules, subject, stops):
    chains = directory.group_chains(subject, stops)
    principals = {subject["sid"]: [subject["sid"]]}
    principals.update(chains)
    for sid in IMPLICIT_PRINCIPALS:
        principals.setdefault(sid, [subject["sid"], sid])
    expandable = [
        sid for sid in principals
        if sid == subject["sid"] or not stops.blocks(sid=sid, dn=(directory.groups.get(sid) or {}).get("dn"))
    ]
    hits = {}
    for row in ingest.read_aces_for_principals(connection, expandable):
        _match_row(rules, row, hits)
    return principals, hits


def _add_hit(directory, builder, principals, principal, target, matches):
    first = matches[0][1]
    name, kind = directory.node_info(principal, first.get("principal_name"))
    builder.add_node(principal, name, kind)
    builder.add_node(target, first.get("target_name"), _target_kind(directory, target, first), dn=first.get("target_dn"))
    types = {}
    rights = []
    guids = []
    for attrs, ctx in matches:
        merge_guids(guids, guid_entries(ctx))
        types.setdefault(attrs["type"], attrs)
        for right in ctx["rights"]:
            if right not in rights:
                rights.append(right)
    ranked = sorted(types.values(), key=lambda a: (-RISK_RANK.get(a["risk"], 0), a["weight"], a["type"]))
    primary = ranked[0]
    builder.add_edge(
        principal,
        target,
        primary["type"],
        rights=rights,
        risk=primary["risk"],
        weight=primary["weight"],
        rule_id=primary["rule_id"],
        evidence=[ctx.get("id") for _, ctx in matches],
        guids=guids,
        types=[{"type": a["type"], "risk": a["risk"], "rule_id": a["rule_id"]} for a in ranked],
    )
    chain = principals.get(principal) or [principal]
    for child, parent in zip(chain, chain[1:]):
        parent_name, parent_kind = directory.node_info(parent, IMPLICIT_PRINCIPALS.get(parent))
        builder.add_node(parent, parent_name, parent_kind)
        builder.add_edge(child, parent, "MemberOf", risk="info", weight=0.0)


def _target_kind(directory, sid, ctx):
    if sid in directory.users:
        return "user"
    if sid in directory.groups:
        return "group"
    if sid in directory.computers:
        return "computer"
    return _node_kind(ctx.get("target_type"))