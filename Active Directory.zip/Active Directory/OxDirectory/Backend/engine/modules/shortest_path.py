from collections import defaultdict, deque

from .. import ingest, privileges, rules_engine
from ..ace_guids import guid_entries, merge_guids
from ..graph import GraphBuilder, _node_kind
from ..membership import Directory
from ..rules_engine.normalize import normalize_dn, normalize_sid, parse_json_list

GROUP = "shortest_path"
ACE_GROUP = "dangerous_aces"
RISK_RANK = {"info": 0, "low": 1, "medium": 2, "high": 3, "critical": 4}
DEFAULT_MIN_RISK = "medium"
DEFAULT_TERMINAL_RISK = "high"
DEFAULT_MAX_START_NODES = 100
DEFAULT_IGNORED_SIDS = ("S-1-5-18", "S-1-3-0", "S-1-3-1", "S-1-5-10", "S-1-5-9")


def run(connection, params):
    rules = rules_engine.path_rules(group=GROUP)
    if not rules:
        raise ValueError(f"No path rules defined for group {GROUP}")
    ace_rules = rules_engine.ace_rules(group=ACE_GROUP)
    if not ace_rules:
        raise ValueError(f"No ACE rules defined for group {ACE_GROUP}")
    settings = _settings(rules[0])
    directory = Directory(connection)
    network = _Network()
    network.load_directory(directory)
    network.load_aces(connection, ace_rules)
    network.load_memberships(directory)
    privileged = network.privileged_ids(connection)
    needle = str(params.get("target", "") or "").strip()
    if needle:
        sinks = network.find(needle)
        if not sinks:
            raise ValueError(f"Object not found: {needle}")
        terminal_rank = settings["min_rank"]
    else:
        sinks = set(privileged)
        terminal_rank = settings["terminal_rank"]
    thresholds = _Thresholds(sinks, settings["min_rank"], terminal_rank)
    blocked = privileged | (set(settings["ignored_sids"]) & set(network.nodes))
    distance = _distances(network, sinks, blocked, thresholds)
    starts = sorted(
        (node for node, hops in distance.items() if hops > 0),
        key=lambda node: (distance[node], network.name(node).casefold(), node),
    )
    kept = starts[:settings["max_start_nodes"]]
    edges = _collect(network, kept, distance, thresholds)
    graph = _assemble(network, edges, sinks)
    graph["meta"] = {
        "mode": "target" if needle else "privileged",
        "target": needle,
        "sinks": len(sinks),
        "total_starts": len(starts),
        "shown_starts": len(kept),
        "max_start_nodes": settings["max_start_nodes"],
        "min_risk": settings["min_risk"],
        "terminal_min_risk": settings["terminal_risk"],
    }
    return graph


def _rank(value, default):
    value = str(value or default).lower()
    return value, RISK_RANK.get(value, RISK_RANK[default])


def _settings(rule):
    raw = rule.raw
    limits = raw.get("limits") or {}
    min_risk, min_rank = _rank(raw.get("min_risk"), DEFAULT_MIN_RISK)
    terminal_risk, terminal_rank = _rank(raw.get("terminal_min_risk"), DEFAULT_TERMINAL_RISK)
    try:
        max_start_nodes = max(int(limits["max_start_nodes"]), 1)
    except (KeyError, TypeError, ValueError):
        max_start_nodes = DEFAULT_MAX_START_NODES
    ignored = raw.get("ignore_sids")
    if not isinstance(ignored, list):
        ignored = DEFAULT_IGNORED_SIDS
    return {
        "ignored_sids": [sid for sid in (normalize_sid(item) for item in ignored) if sid],
        "min_risk": min_risk,
        "min_rank": min_rank,
        "terminal_risk": terminal_risk,
        "terminal_rank": terminal_rank,
        "max_start_nodes": max_start_nodes,
    }


def _index_rules(ace_rules):
    by_right = defaultdict(list)
    generic = []
    for rule in ace_rules:
        match = rule.raw.get("match") or {}
        if set(match) == {"rights_contains"}:
            by_right[match["rights_contains"]].append(rule)
        else:
            generic.append(rule)
    return by_right, generic


class _Thresholds:
    def __init__(self, sinks, hop_rank, terminal_rank):
        self.sinks = sinks
        self.hop_rank = hop_rank
        self.terminal_rank = terminal_rank

    def allows(self, edge, target):
        if edge["membership"]:
            return True
        return edge["rank"] >= (self.terminal_rank if target in self.sinks else self.hop_rank)


class _Network:
    def __init__(self):
        self.nodes = {}
        self.outgoing = {}
        self.incoming = {}
        self.links = {}

    def add_node(self, node_id, name=None, kind="other", dn=None):
        node = self.nodes.get(node_id)
        if node is None:
            self.nodes[node_id] = {"name": name or node_id, "kind": kind, "dn": dn}
            return
        if node["kind"] == "other" and kind != "other":
            node["kind"] = kind
        if not node.get("dn") and dn:
            node["dn"] = dn

    def name(self, node_id):
        return self.nodes[node_id]["name"]

    def load_directory(self, directory):
        for sid, user in directory.users.items():
            self.add_node(sid, user["name"], "user", user.get("dn"))
        for sid, group in directory.groups.items():
            self.add_node(sid, group["name"], "group", group.get("dn"))

    def load_aces(self, connection, ace_rules):
        pairs = {}
        by_right, generic = _index_rules(ace_rules)
        attributes = {rule.id: rules_engine.edge_attributes(rule) for rule in ace_rules}
        for row in ingest.read_all_aces(connection):
            if row.get("ace_type_raw") in rules_engine.ruleset.DENY_ACE_TYPES:
                continue
            rights = parse_json_list(row.get("rights"))
            candidates = list(generic)
            for right in rights:
                candidates.extend(by_right.get(right, ()))
            if not candidates:
                continue
            ctx = rules_engine.ace_context(row)
            principal = normalize_sid(row.get("principal_sid"))
            target_sid = normalize_sid(row.get("target_sid"))
            target = target_sid or row.get("target_dn")
            if not principal or not target or target == principal:
                continue
            matches = [
                attributes[rule.id]
                for rule in candidates
                if rules_engine.match_ace(rule, ctx)
            ]
            if not matches:
                continue
            self.add_node(principal, row.get("principal_name"))
            self.add_node(target, row.get("target_name"), _node_kind(row.get("target_type")), row.get("target_dn"))
            pair = pairs.setdefault((principal, target), {"types": {}, "rights": [], "evidence": [], "guids": []})
            merge_guids(pair["guids"], guid_entries(ctx))
            for attrs in matches:
                pair["types"].setdefault(attrs["type"], attrs)
            for right in ctx["rights"]:
                if right not in pair["rights"]:
                    pair["rights"].append(right)
            pair["evidence"].append(ctx.get("id"))
        for (principal, target), pair in pairs.items():
            ranked = sorted(
                pair["types"].values(),
                key=lambda a: (-RISK_RANK.get(a["risk"], 0), a["weight"], a["type"]),
            )
            self._link({
                "source": principal,
                "target": target,
                "membership": False,
                "rank": RISK_RANK.get(ranked[0]["risk"], 0),
                "ranked": ranked,
                "rights": pair["rights"],
                "evidence": pair["evidence"],
                "guids": pair["guids"],
            })

    def load_memberships(self, directory):
        for child, parent in directory.membership_links():
            self._link({
                "source": child,
                "target": parent,
                "membership": True,
                "rank": 0,
                "ranked": [],
                "rights": [],
                "evidence": [],
                "guids": [],
            })

    def _link(self, edge):
        key = (edge["source"], edge["target"], edge["membership"])
        if key in self.links:
            return
        self.links[key] = edge
        self.outgoing.setdefault(edge["source"], []).append(edge)
        self.incoming.setdefault(edge["target"], []).append(edge)

    def privileged_ids(self, connection):
        sids, dns = privileges.privileged_keys(connection)
        found = set()
        for node_id, node in self.nodes.items():
            if (
                node["kind"] == "domain"
                or normalize_sid(node_id) in sids
                or normalize_dn(node.get("dn")) in dns
            ):
                found.add(node_id)
        return found

    def find(self, needle):
        text = needle.casefold()
        exact = {
            node_id for node_id, node in self.nodes.items()
            if text in (
                str(node_id).casefold(),
                str(node.get("dn") or "").casefold(),
                str(node["name"]).casefold(),
            )
        }
        if exact:
            return exact
        return {
            node_id for node_id, node in self.nodes.items()
            if text in str(node["name"]).casefold()
        }


def _distances(network, sinks, blocked, thresholds):
    distance = {sink: 0 for sink in sinks}
    queue = deque(sorted(sinks))
    while queue:
        current = queue.popleft()
        for edge in network.incoming.get(current, ()):
            source = edge["source"]
            if source in distance or source in blocked:
                continue
            if not thresholds.allows(edge, current):
                continue
            distance[source] = distance[current] + 1
            queue.append(source)
    return distance


def _collect(network, starts, distance, thresholds):
    selected = {}
    seen = set(starts)
    stack = list(starts)
    while stack:
        current = stack.pop()
        for edge in network.outgoing.get(current, ()):
            target = edge["target"]
            if distance.get(target) != distance[current] - 1:
                continue
            if not thresholds.allows(edge, target):
                continue
            selected[(edge["source"], edge["target"], edge["membership"])] = edge
            if target not in seen:
                seen.add(target)
                stack.append(target)
    return list(selected.values())


def _assemble(network, edges, sinks):
    builder = GraphBuilder()
    for edge in edges:
        for node_id in (edge["source"], edge["target"]):
            node = network.nodes[node_id]
            builder.add_node(node_id, node["name"], node["kind"], node.get("dn"))
        if edge["membership"]:
            builder.add_edge(edge["source"], edge["target"], "MemberOf", risk="info", weight=0.0)
            continue
        primary = edge["ranked"][0]
        builder.add_edge(
            edge["source"],
            edge["target"],
            primary["type"],
            rights=edge["rights"],
            risk=primary["risk"],
            weight=primary["weight"],
            rule_id=primary["rule_id"],
            evidence=edge["evidence"],
            guids=edge["guids"],
            types=[{"type": a["type"], "risk": a["risk"], "rule_id": a["rule_id"]} for a in edge["ranked"]],
        )
    return builder.build()