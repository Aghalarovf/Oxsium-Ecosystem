from collections import deque


def _matches(name, sid, needle):
    needle = needle.lower()
    return needle == (sid or "").lower() or needle in (name or "").lower()


def shortest_paths(rows, source, target, max_paths=10, stops=None):
    adjacency = {}
    meta = {}
    for row in rows:
        adjacency.setdefault(row["principal_sid"], []).append(row)
        meta[row["principal_sid"]] = row["principal_name"]
        meta.setdefault(row["target_sid"], row["target_name"])
    starts = [sid for sid, name in meta.items() if _matches(name, sid, source)]
    goals = {sid for sid, name in meta.items() if _matches(name, sid, target)}
    found = []
    for start in starts:
        parents = {start: None}
        queue = deque([start])
        while queue:
            current = queue.popleft()
            if current in goals and current != start:
                chain = []
                node = current
                while parents[node] is not None:
                    row = parents[node]
                    chain.append(row)
                    node = row["principal_sid"]
                found.append(list(reversed(chain)))
                continue
            if stops is not None and current != start and stops.blocks(sid=current):
                continue
            for row in adjacency.get(current, []):
                nxt = row["target_sid"]
                if nxt not in parents:
                    parents[nxt] = row
                    queue.append(nxt)
    found.sort(key=len)
    selected = []
    for chain in found[:max_paths]:
        selected.extend(chain)
    return selected
