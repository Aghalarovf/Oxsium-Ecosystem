"""Marks graph nodes that carry privilege attributes stored in the domain database.

user / group / computer : absolute_admin, nested_admin, potential_admin
computer                : potential_privileged (extra)
group                   : is_privileged (extra); admin_count is NOT used on its own,
                          it is a hint and not proof of privilege
ou / gpo                : tier0, highvalue
domain                  : always privileged (flag "domain_object"), the domain root is Tier 0

Every matching node gets ``node["flags"]`` (list of the attributes that are set).
Nodes without any flag get no ``flags`` key.
"""
import re

from . import ingest
from .rules_engine import well_known
from .rules_engine.matcher import is_set
from .rules_engine.normalize import normalize_dn, normalize_sid

ADMIN_FLAGS = ("absolute_admin", "nested_admin", "potential_admin")

# kind -> (table, key column, key normaliser, flags)
SOURCES = {
    "user": ("domain_users", "sid", normalize_sid, ADMIN_FLAGS),
    "group": ("domain_groups", "group_sid", normalize_sid, ADMIN_FLAGS + ("is_privileged",)),
    "computer": ("domain_computers", "sid", normalize_sid, ADMIN_FLAGS + ("potential_privileged",)),
    "ou": ("domain_ous", "dn", normalize_dn, ("tier0", "highvalue")),
    "gpo": ("domain_gpos", "dn", normalize_dn, ("tier0", "highvalue")),
}
SID_KINDS = ("user", "group", "computer")
SID_PATTERN = re.compile(r"^S-1-\d+(-\d+)+$", re.IGNORECASE)


def _is_orphaned(node, sid):
    if not sid or not SID_PATTERN.match(sid) or well_known().is_known(sid):
        return False
    name = str(node.get("name") or "").strip()
    return not name or bool(SID_PATTERN.match(name))


def _load(connection):
    """kind -> {normalised key: [set flags]} for every object of that kind."""
    loaded = {}
    for kind, (table, key, normalise, flags) in SOURCES.items():
        entries = {}
        for row in ingest.read_table(connection, table, (key,) + flags):
            ident = normalise(row.get(key))
            if ident:
                entries[ident] = [flag for flag in flags if is_set(row.get(flag))]
        loaded[kind] = entries
    return loaded


def annotate_nodes(connection, graph):
    nodes = graph.get("nodes") or []
    if not nodes:
        return graph
    loaded = _load(connection)
    for node in nodes:
        kind = node.get("kind")
        if kind == "other":
            # Principals are added without a type; resolve it from the directory.
            sid = normalize_sid(node.get("id"))
            for candidate in SID_KINDS:
                if sid and sid in loaded[candidate]:
                    kind = node["kind"] = candidate
                    break
            if kind == "other" and _is_orphaned(node, sid):
                node["orphaned"] = True
        if kind == "domain":
            node["flags"] = ["domain_object"]
            continue
        source = SOURCES.get(kind)
        if source is None:
            continue
        _, _, normalise, _ = source
        ident = normalise(node.get("dn") if kind in ("ou", "gpo") else node.get("id"))
        flags = loaded[kind].get(ident)
        if flags:
            node["flags"] = flags
    return graph


def privileged_keys(connection):
    sids, dns = set(), set()
    for kind, entries in _load(connection).items():
        target = dns if kind in ("ou", "gpo") else sids
        target.update(ident for ident, flags in entries.items() if flags)
    return sids, dns