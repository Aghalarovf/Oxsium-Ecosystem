import time

from . import history
from .chain_stops import ChainStops
from .db import connect, fetch_ace_rows
from .edge_limit import apply_limit, parse_options
from .graph import graph_from_rows
from .modules import dangerous_aces_of_object, shortest_path_to_privileged
from .pathfinder import shortest_paths
from .privileges import annotate_nodes

PATH_POOL = 50000


def _limit(params, default=300):
    try:
        return min(max(int(params.get("limit", default)), 1), 2000)
    except (TypeError, ValueError):
        return default


def _all_dangerous(connection, params):
    return fetch_ace_rows(connection, limit=_limit(params))


def _over_type(kind):
    def run(connection, params):
        return fetch_ace_rows(connection, target_type=kind, limit=_limit(params))
    return run


def _by_right(right):
    def run(connection, params):
        return fetch_ace_rows(connection, right=right, limit=_limit(params))
    return run


def _outbound(connection, params):
    return fetch_ace_rows(connection, principal=params.get("principal", ""), limit=_limit(params))


def _inbound(connection, params):
    return fetch_ace_rows(connection, target=params.get("target", ""), limit=_limit(params))


def _shortest(connection, params):
    rows = fetch_ace_rows(connection, limit=PATH_POOL)
    return shortest_paths(rows, params.get("source", ""), params.get("target", ""), stops=ChainStops.load(connection))


def _dangerous_aces(connection, params):
    return dangerous_aces_of_object(connection, params)


def _shortest_path(connection, params):
    return shortest_path_to_privileged(connection, params)


def _text(name, label, placeholder, required=True):
    return {"name": name, "label": label, "placeholder": placeholder, "required": required}


PACKAGES = [
    {
        "id": "rules",
        "name": "Rules",
        "queries": [
            {"id": "dangerous_aces_object", "name": "Dangerous ACEs of an object", "description": "Objects that a user, group or computer holds dangerous rights over, directly or through group membership. Leave the object empty to calculate across all objects", "params": [_text("object", "Object", "empty = all objects", required=False)], "run": _dangerous_aces},
            {"id": "shortest_path", "name": "Shortest path", "description": "Shortest attack vectors ending in critical rights over privileged objects. Leave the object empty to calculate against all privileged objects, or enter a user or object to calculate every vector directed at it", "params": [_text("target", "Object", "empty = privileged objects", required=False)], "run": _shortest_path},
        ],
    },
    {
        "id": "overview",
        "name": "Overview",
        "queries": [
            {"id": "dangerous_all", "name": "All dangerous rights", "description": "Every dangerous allow ACE between principals and objects", "params": [], "run": _all_dangerous},
            {"id": "over_domain", "name": "Rights over the domain object", "description": "Principals holding dangerous rights on domain objects", "params": [], "run": _over_type("domain")},
            {"id": "over_groups", "name": "Rights over groups", "description": "Principals holding dangerous rights on groups", "params": [], "run": _over_type("group")},
            {"id": "over_computers", "name": "Rights over computers", "description": "Principals holding dangerous rights on computers", "params": [], "run": _over_type("computer")},
            {"id": "over_users", "name": "Rights over users", "description": "Principals holding dangerous rights on users", "params": [], "run": _over_type("user")},
        ],
    },
    {
        "id": "rights",
        "name": "Rights",
        "queries": [
            {"id": "generic_all", "name": "GenericAll", "description": "Edges granting GenericAll", "params": [], "run": _by_right("GenericAll")},
            {"id": "write_dacl", "name": "WriteDacl", "description": "Edges granting WriteDacl", "params": [], "run": _by_right("WriteDacl")},
            {"id": "write_owner", "name": "WriteOwner", "description": "Edges granting WriteOwner", "params": [], "run": _by_right("WriteOwner")},
            {"id": "dcsync", "name": "DCSync", "description": "Edges granting replication rights", "params": [], "run": _by_right("GetChanges")},
        ],
    },
    {
        "id": "pathfinding",
        "name": "Pathfinding",
        "queries": [
            {"id": "outbound", "name": "Outbound rights of a principal", "description": "Everything a principal has rights over", "params": [_text("principal", "Principal", "name or SID")], "run": _outbound},
            {"id": "inbound", "name": "Inbound rights over an object", "description": "Everyone who has rights over an object", "params": [_text("target", "Object", "name or SID")], "run": _inbound},
            {"id": "shortest", "name": "Shortest paths", "description": "Shortest rights chains between two objects", "params": [_text("source", "Start", "name or SID"), _text("target", "End", "name or SID")], "run": _shortest},
        ],
    },
]

_INDEX = {query["id"]: query for package in PACKAGES for query in package["queries"]}


def catalog():
    return [
        {
            "id": package["id"],
            "name": package["name"],
            "queries": [
                {key: query[key] for key in ("id", "name", "description", "params")}
                for query in package["queries"]
            ],
        }
        for package in PACKAGES
    ]


def run_query(query_id, params=None, user="anonymous", record=True, db_path=None, options=None):
    params = {key: str(value).strip() for key, value in (params or {}).items() if isinstance(key, str)}
    query = _INDEX.get(query_id)
    if query is None:
        raise KeyError(query_id)
    for spec in query["params"]:
        if spec["required"] and not params.get(spec["name"]):
            raise ValueError(f"{spec['label']} is required")
    limits = parse_options(options)
    started = time.perf_counter()
    try:
        with connect(db_path) as connection:
            rows = query["run"](connection, params)
            graph = rows if isinstance(rows, dict) else graph_from_rows(rows)
            apply_limit(graph, limits)
            annotate_nodes(connection, graph)
    except Exception as error:
        if record:
            history.record(user, query_id, query["name"], params, 0, 0, int((time.perf_counter() - started) * 1000), str(error))
        raise
    elapsed = int((time.perf_counter() - started) * 1000)
    if record:
        history.record(user, query_id, query["name"], params, len(graph["nodes"]), len(graph["edges"]), elapsed)
    graph["query"] = {"id": query_id, "name": query["name"], "params": params, "elapsed_ms": elapsed}
    return graph