class RuleEngineError(Exception):
    pass


class RuleValidationError(RuleEngineError):
    pass
