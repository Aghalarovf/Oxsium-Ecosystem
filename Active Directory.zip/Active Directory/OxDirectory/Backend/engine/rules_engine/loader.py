from __future__ import annotations

from pathlib import Path

import yaml

from .errors import RuleValidationError
import logging
from .models import Rule
from .schema import parse_rule

logger = logging.getLogger(__name__)


def discover_rule_files(rule_dirs: list[Path]) -> list[Path]:
    files: list[Path] = []
    for rule_dir in rule_dirs:
        if not rule_dir.exists():
            continue
        files.extend(sorted(rule_dir.rglob("*.yaml")))
        files.extend(sorted(rule_dir.rglob("*.yml")))
    return files


def load_rules(rule_dirs: list[Path]) -> list[Rule]:
    rules: list[Rule] = []
    seen_ids: dict[str, str] = {}

    for path in discover_rule_files(rule_dirs):
        try:
            content = yaml.safe_load(path.read_text(encoding="utf-8"))
        except (OSError, yaml.YAMLError) as exc:
            raise RuleValidationError(f"Failed to read or parse YAML in {path}: {exc}") from exc

        if content is None:
            continue

        raw_rules = content if isinstance(content, list) else [content]

        for raw in raw_rules:
            if not isinstance(raw, dict):
                raise RuleValidationError(f"Invalid rule entry in {path}, expected a mapping")
            rule = parse_rule(raw, source_file=str(path))
            if rule.id in seen_ids:
                raise RuleValidationError(
                    f"Duplicate rule id '{rule.id}' in {path} (already defined in {seen_ids[rule.id]})"
                )
            seen_ids[rule.id] = str(path)
            rules.append(rule)

    logger.info("loaded %d rules from %d director(y/ies)", len(rules), len(rule_dirs))
    return rules