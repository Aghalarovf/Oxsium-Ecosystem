from __future__ import annotations

from typing import Any

from .errors import RuleValidationError
from .normalize import parse_json_list

LogicKey = str

COMBINATORS = {"all_of", "any_of", "none_of"}
FALSY_TEXT = {"", "0", "false", "no", "null", "none"}


def is_set(value: Any) -> bool:
    """True when a stored flag carries a value: non-zero numbers, true/yes/1 and any other non-empty text."""
    if value is None:
        return False
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        return value.strip().lower() not in FALSY_TEXT
    return bool(value)


def evaluate(condition: dict[str, Any] | None, ctx: dict[str, Any]) -> bool:
    if not condition:
        return True

    results = []
    for combinator in COMBINATORS:
        if combinator in condition:
            sub_conditions = condition[combinator]
            nested = [evaluate(c, ctx) for c in sub_conditions]
            if combinator == "all_of":
                results.append(all(nested))
            elif combinator == "any_of":
                results.append(any(nested))
            else:
                results.append(not any(nested))
    results.extend(
        _evaluate_leaf(key, value, ctx)
        for key, value in condition.items()
        if key not in COMBINATORS
    )
    return all(results)


def _evaluate_leaf(key: str, value: Any, ctx: dict[str, Any]) -> bool:
    if key == "rights_contains":
        return value in (ctx.get("rights") or [])

    if key == "rights_any":
        rights = ctx.get("rights") or []
        return any(v in rights for v in value)

    if key == "rights_all":
        rights = ctx.get("rights") or []
        return all(v in rights for v in value)

    if key == "guid_equals":
        expected = str(value).strip().strip("{}").lower()
        values = {
            str(ctx.get("object_guid") or "").strip().strip("{}").lower(),
            str(ctx.get("object_acetype") or "").strip().strip("{}").lower(),
        }
        values.update(
            str(item.get("guid") or "").strip().strip("{}").lower()
            for item in (ctx.get("rights_details") or [])
            if isinstance(item, dict)
        )
        return expected in values

    if key == "guid_in":
        expected = {str(item).strip().strip("{}").lower() for item in value}
        values = {
            str(ctx.get("object_guid") or "").strip().strip("{}").lower(),
            str(ctx.get("object_acetype") or "").strip().strip("{}").lower(),
        }
        values.update(
            str(item.get("guid") or "").strip().strip("{}").lower()
            for item in (ctx.get("rights_details") or [])
            if isinstance(item, dict)
        )
        return bool(values & expected)

    if key == "target_type_in":
        return ctx.get("target_type") in value

    if key == "target_type_prefix":
        return str(ctx.get("target_type") or "").startswith(value)

    if key == "principal_scope_in":
        return ctx.get("principal_scope") in value

    if key == "is_deny":
        return bool(ctx.get("is_deny")) == bool(value)

    if key == "is_inherited":
        return bool(ctx.get("is_inherited")) == bool(value)

    if key == "dangerous_ace":
        return bool(ctx.get("dangerous_ace")) == bool(value)

    if key == "suspicious_ace":
        return bool(ctx.get("suspicious_ace")) == bool(value)

    if key == "field_equals":
        return ctx.get(value["field"]) == value["value"]

    if key == "field_in":
        return ctx.get(value["field"]) in value["values"]

    if key == "field_truthy":
        fields = [value] if isinstance(value, str) else value
        return any(is_set(ctx.get(field)) for field in fields)

    if key == "finding_rule":
        findings = parse_json_list(ctx.get("esc_findings"))
        expected = str(value).casefold()
        return any(
            isinstance(finding, dict)
            and str(finding.get("rule") or "").casefold() == expected
            for finding in findings
        )

    raise RuleValidationError(f"Unknown condition key: {key}")