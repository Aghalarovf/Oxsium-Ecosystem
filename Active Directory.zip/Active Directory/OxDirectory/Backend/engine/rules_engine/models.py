from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class RiskLevel(str, Enum):
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class Rule:
    id: str
    description: str
    applies_to: str
    edge: dict[str, Any] | None = None
    node_tag: dict[str, Any] | None = None
    source_file: str | None = None
    raw: dict[str, Any] = field(default_factory=dict)
