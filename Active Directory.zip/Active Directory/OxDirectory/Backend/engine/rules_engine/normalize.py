from __future__ import annotations

import json
import uuid
from typing import Any, Optional


def parse_json(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, (list, dict)):
        return value
    if isinstance(value, str):
        value = value.strip()
        if not value:
            return None
        try:
            return json.loads(value)
        except (json.JSONDecodeError, ValueError):
            return None
    return None


def parse_json_list(value: Any) -> list[Any]:
    parsed = parse_json(value)
    if parsed is None:
        return []
    if isinstance(parsed, list):
        return parsed
    return [parsed]


def normalize_dn(dn: Optional[str]) -> Optional[str]:
    if not dn:
        return None
    value = str(dn).strip()
    return value.casefold() or None


def normalize_sid(sid: Optional[str]) -> Optional[str]:
    if not sid:
        return None
    sid_value = str(sid).strip()
    if not sid_value or sid_value.upper() == "NULL":
        return None
    return sid_value.upper()


def normalize_guid(guid: Any) -> Optional[str]:
    if guid is None:
        return None
    if isinstance(guid, (bytes, bytearray)):
        if not guid:
            return None
        try:
            return str(uuid.UUID(bytes_le=bytes(guid))).lower()
        except ValueError:
            return bytes(guid).hex()
    value = str(guid).strip().strip("{}").lower()
    if not value:
        return None
    try:
        return str(uuid.UUID(value))
    except ValueError:
        return value


def canonicalize(value: Any) -> Any:
    if isinstance(value, (bytes, bytearray)):
        return normalize_guid(value)
    if isinstance(value, str):
        parsed = parse_json(value)
        if parsed is not None:
            return canonicalize(parsed)
        guid = normalize_guid(value)
        if guid and guid != value.strip().casefold():
            return guid
        return value
    if isinstance(value, list):
        return [canonicalize(item) for item in value]
    if isinstance(value, dict):
        return {str(key): canonicalize(item) for key, item in value.items()}
    return value


def coerce_bool(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes")
    return False


def first_non_empty(*values: Any) -> Optional[Any]:
    for v in values:
        if v is not None and v != "":
            return v
    return None
