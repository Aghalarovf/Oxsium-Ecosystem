from __future__ import annotations

import math
from pathlib import Path
from typing import Any

import yaml

DEFAULT_WEIGHT = {"weight": 3, "risk": "low"}


class RiskWeightTable:
    def __init__(self, table: dict[str, dict[str, Any]]):
        self.table = table

    @classmethod
    def load(cls, path: Path) -> "RiskWeightTable":
        if not path.exists():
            return cls({})
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        if not isinstance(data, dict):
            raise ValueError(f"Risk weights must be a YAML mapping: {path}")
        for edge_type, value in data.items():
            if not isinstance(value, dict):
                raise ValueError(f"Risk weight for {edge_type!r} must be a mapping")
            weight = value.get("weight", DEFAULT_WEIGHT["weight"])
            risk = value.get("risk", DEFAULT_WEIGHT["risk"])
            if not isinstance(weight, (int, float)) or not math.isfinite(weight) or weight < 0:
                raise ValueError(f"Risk weight for {edge_type!r} must be finite and non-negative")
            if risk not in {"info", "low", "medium", "high", "critical"}:
                raise ValueError(f"Invalid risk level {risk!r} for {edge_type!r}")
        return cls(data)

    def get(self, edge_type: str) -> dict[str, Any]:
        return self.table.get(edge_type, self.table.get("DEFAULT", DEFAULT_WEIGHT))