from __future__ import annotations

import os
import threading
from pathlib import Path
from typing import Any

from .loader import discover_rule_files, load_rules
from .matcher import evaluate
from .models import Rule
from .normalize import parse_json_list
from .risk import RiskWeightTable
from .wellknown import WellKnownSids

ENGINE_DIR = Path(__file__).resolve().parent.parent
RULES_DIR = Path(os.environ.get("OXENGINE_RULES_DIR", ENGINE_DIR / "rules"))
VARIABLES_DIR = Path(os.environ.get("OXENGINE_VARIABLES_DIR", ENGINE_DIR / "variables"))

INHERITED_ACE_FLAG = 0x10
DENY_ACE_TYPES = {1, 6}

_LOCK = threading.Lock()
_CACHE: dict[str, Any] = {"stamp": None, "rules": [], "weights": None, "well_known": None}


def _stamp():
    files = discover_rule_files([RULES_DIR])
    files += [VARIABLES_DIR / "risk_weights.yaml", VARIABLES_DIR / "well_known_sids.yaml"]
    return tuple((str(path), path.stat().st_mtime_ns) for path in files if path.exists())


def _refresh():
    stamp = _stamp()
    with _LOCK:
        if _CACHE["stamp"] != stamp:
            _CACHE["rules"] = load_rules([RULES_DIR])
            _CACHE["weights"] = RiskWeightTable.load(VARIABLES_DIR / "risk_weights.yaml")
            _CACHE["well_known"] = WellKnownSids.load(VARIABLES_DIR / "well_known_sids.yaml")
            _CACHE["stamp"] = stamp
        return _CACHE["rules"], _CACHE["weights"], _CACHE["well_known"]


def rules() -> list[Rule]:
    return _refresh()[0]


def risk_weights() -> RiskWeightTable:
    return _refresh()[1]


def well_known() -> WellKnownSids:
    return _refresh()[2]


def ace_rules(edge_type: str | None = None, group: str | None = None) -> list[Rule]:
    selected = [rule for rule in rules() if rule.applies_to == "ace"]
    if edge_type is not None:
        selected = [rule for rule in selected if (rule.edge or {}).get("type") == edge_type]
    if group is not None:
        selected = [rule for rule in selected if rule.raw.get("group") == group]
    return selected


def path_rules(group: str | None = None) -> list[Rule]:
    selected = [rule for rule in rules() if rule.applies_to == "path"]
    if group is not None:
        selected = [rule for rule in selected if rule.raw.get("group") == group]
    return selected


def chain_stop_rules() -> list[Rule]:
    """Node rules (chain: stop) whose matching nodes end a chain: nothing is expanded beyond them."""
    return [
        rule for rule in rules()
        if rule.applies_to == "node" and str(rule.raw.get("chain", "")).lower() == "stop"
    ]


def ace_context(row: dict[str, Any]) -> dict[str, Any]:
    ctx = dict(row)
    ctx["rights"] = parse_json_list(row.get("rights"))
    ctx["rights_details"] = parse_json_list(row.get("rights_details"))
    ctx["is_deny"] = row.get("ace_type_raw") in DENY_ACE_TYPES
    try:
        ctx["is_inherited"] = bool(int(row.get("ace_flags") or 0) & INHERITED_ACE_FLAG)
    except (TypeError, ValueError):
        ctx["is_inherited"] = False
    return ctx


def match_ace(rule: Rule, ctx: dict[str, Any]) -> bool:
    return evaluate(rule.raw.get("match", {}), ctx)


def edge_attributes(rule: Rule) -> dict[str, Any]:
    spec = rule.edge or {}
    edge_type = spec.get("type", rule.id)
    defaults = risk_weights().get(edge_type)
    return {
        "type": edge_type,
        "risk": spec.get("risk", defaults.get("risk", "low")),
        "weight": float(spec.get("weight", defaults.get("weight", 3))),
        "direction": spec.get("direction", "principal_to_target"),
        "rule_id": rule.id,
    }
