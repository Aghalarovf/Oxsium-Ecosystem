from __future__ import annotations

from typing import Any

from jsonschema import Draft202012Validator

from .errors import RuleValidationError
from .models import Rule

VALID_APPLIES_TO = {"ace", "ace_aggregate", "table_field", "node", "path"}
ENTITY_TABLES = {
    "domain_users",
    "domain_computers",
    "domain_groups",
    "domain_gpos",
    "domain_ous",
    "domain_certificates",
    "domain_trusts",
    "domain_info",
}
RULE_SCHEMA = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "type": "object",
    "required": ["id", "applies_to"],
    "properties": {
        "id": {"type": "string", "minLength": 1},
        "description": {"type": "string"},
        "applies_to": {"enum": sorted(VALID_APPLIES_TO)},
        "match": {"type": "object"},
        "exclude": {"type": "object"},
        "group_by": {"type": "array", "items": {"type": "string"}},
        "require_all": {"type": "array", "items": {"type": "object"}},
        "source_table": {"type": "string"},
        "field": {"type": "string"},
        "edge": {
            "type": "object",
            "properties": {
                "type": {"type": "string"},
                "direction": {
                    "enum": ["principal_to_target", "target_to_principal"]
                },
                "weight": {"type": "number", "minimum": 0},
                "risk": {"enum": ["info", "low", "medium", "high", "critical"]},
            },
            "additionalProperties": True,
        },
        "node_tag": {"oneOf": [{"type": "string"}, {"type": "object"}]},
    },
    "additionalProperties": True,
}
_RULE_VALIDATOR = Draft202012Validator(RULE_SCHEMA)
_CONDITION_KEYS = {
    "all_of",
    "any_of",
    "none_of",
    "rights_contains",
    "rights_any",
    "rights_all",
    "guid_equals",
    "guid_in",
    "target_type_in",
    "target_type_prefix",
    "principal_scope_in",
    "is_deny",
    "is_inherited",
    "dangerous_ace",
    "suspicious_ace",
    "field_equals",
    "field_in",
    "field_truthy",
    "finding_rule",
}


def _validate_condition(condition: Any, rule_id: str, source_file: str) -> None:
    if not isinstance(condition, dict):
        raise RuleValidationError(
            f"Rule '{rule_id}' in {source_file} has a condition that must be a mapping"
        )
    unknown = set(condition) - _CONDITION_KEYS
    if unknown:
        raise RuleValidationError(
            f"Rule '{rule_id}' in {source_file} uses unknown condition(s): "
            f"{', '.join(sorted(unknown))}"
        )
    for key in ("all_of", "any_of", "none_of"):
        if key in condition:
            if not isinstance(condition[key], list):
                raise RuleValidationError(
                    f"Rule '{rule_id}' in {source_file}: {key} must be a list"
                )
            for child in condition[key]:
                _validate_condition(child, rule_id, source_file)
    list_operators = {
        "rights_any",
        "rights_all",
        "guid_in",
        "target_type_in",
        "principal_scope_in",
    }
    for key in list_operators & condition.keys():
        if not isinstance(condition[key], list):
            raise RuleValidationError(
                f"Rule '{rule_id}' in {source_file}: {key} must be a list"
            )
    if "field_equals" in condition:
        field_equals = condition["field_equals"]
        if not isinstance(field_equals, dict) or not isinstance(
            field_equals.get("field"), str
        ) or "value" not in field_equals:
            raise RuleValidationError(
                f"Rule '{rule_id}' in {source_file}: field_equals requires field and value"
            )
    if "field_truthy" in condition:
        field_truthy = condition["field_truthy"]
        names = [field_truthy] if isinstance(field_truthy, str) else field_truthy
        if not isinstance(names, list) or not names or not all(isinstance(name, str) for name in names):
            raise RuleValidationError(
                f"Rule '{rule_id}' in {source_file}: field_truthy requires a field name or a list of field names"
            )
    if "field_in" in condition:
        field_in = condition["field_in"]
        if not isinstance(field_in, dict) or not isinstance(
            field_in.get("field"), str
        ) or not isinstance(field_in.get("values"), list):
            raise RuleValidationError(
                f"Rule '{rule_id}' in {source_file}: field_in requires field and values"
            )


def parse_rule(raw: dict[str, Any], source_file: str) -> Rule:
    errors = sorted(
        _RULE_VALIDATOR.iter_errors(raw),
        key=lambda error: tuple(map(str, error.path)),
    )
    if errors:
        error = errors[0]
        location = ".".join(str(part) for part in error.path) or "<rule>"
        raise RuleValidationError(
            f"Invalid rule in {source_file} at {location}: {error.message}"
        )
    for condition_name in ("match", "exclude"):
        condition = raw.get(condition_name)
        if condition is not None:
            _validate_condition(condition, str(raw.get("id", "<unknown>")), source_file)
    for condition in raw.get("require_all", []):
        _validate_condition(condition, str(raw.get("id", "<unknown>")), source_file)
    if "id" not in raw:
        raise RuleValidationError(f"Rule in {source_file} is missing 'id'")
    if "applies_to" not in raw:
        raise RuleValidationError(f"Rule '{raw['id']}' in {source_file} is missing 'applies_to'")

    applies_to = raw["applies_to"]
    if applies_to not in VALID_APPLIES_TO:
        raise RuleValidationError(
            f"Rule '{raw['id']}' in {source_file} has invalid applies_to '{applies_to}', "
            f"expected one of {sorted(VALID_APPLIES_TO)}"
        )

    if applies_to == "ace" and "match" not in raw:
        raise RuleValidationError(f"Rule '{raw['id']}' in {source_file} (applies_to=ace) requires 'match'")

    if applies_to == "ace_aggregate":
        if "group_by" not in raw or not isinstance(raw["group_by"], list) or not raw["group_by"]:
            raise RuleValidationError(
                f"Rule '{raw['id']}' in {source_file} (applies_to=ace_aggregate) requires 'group_by' list"
            )
        if (
            "require_all" not in raw
            or not isinstance(raw["require_all"], list)
            or not raw["require_all"]
        ):
            raise RuleValidationError(
                f"Rule '{raw['id']}' in {source_file} (applies_to=ace_aggregate) requires 'require_all' list"
            )

    if applies_to == "table_field":
        if raw.get("source_table") not in ENTITY_TABLES:
            raise RuleValidationError(
                f"Rule '{raw['id']}' in {source_file} (applies_to=table_field) requires 'source_table'"
            )
        if "field" not in raw:
            raise RuleValidationError(
                f"Rule '{raw['id']}' in {source_file} (applies_to=table_field) requires 'field'"
            )

    if applies_to == "node":
        if raw.get("source_table") not in ENTITY_TABLES:
            raise RuleValidationError(
                f"Rule '{raw['id']}' in {source_file} (applies_to=node) requires 'source_table'"
            )
        if "match" not in raw:
            raise RuleValidationError(
                f"Rule '{raw['id']}' in {source_file} (applies_to=node) requires 'match'"
            )
        if not raw.get("node_tag"):
            raise RuleValidationError(
                f"Rule '{raw['id']}' in {source_file} (applies_to=node) requires 'node_tag'"
            )

    if applies_to == "path":
        if not raw.get("group"):
            raise RuleValidationError(
                f"Rule '{raw['id']}' in {source_file} (applies_to=path) requires 'group'"
            )
        for key in ("min_risk", "terminal_min_risk"):
            if raw.get(key) is not None and raw[key] not in ("info", "low", "medium", "high", "critical"):
                raise RuleValidationError(
                    f"Rule '{raw['id']}' in {source_file}: {key} must be one of info, low, medium, high, critical"
                )
        limits = raw.get("limits")
        if limits is not None and not isinstance(limits, dict):
            raise RuleValidationError(
                f"Rule '{raw['id']}' in {source_file}: limits must be a mapping"
            )

    if applies_to != "path" and raw.get("edge") is None and raw.get("node_tag") is None:
        raise RuleValidationError(
            f"Rule '{raw['id']}' in {source_file} must define 'edge' or 'node_tag'"
        )

    return Rule(
        id=raw["id"],
        description=raw.get("description", ""),
        applies_to=applies_to,
        edge=raw.get("edge"),
        node_tag=raw.get("node_tag"),
        source_file=source_file,
        raw=raw,
    )