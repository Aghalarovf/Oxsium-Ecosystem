from __future__ import annotations

from pathlib import Path
from typing import Optional

import yaml


class WellKnownSids:
    def __init__(self, fixed: dict[str, str], rid_suffixes: dict[int, str]):
        self.fixed = {k.upper(): v for k, v in fixed.items()}
        self.rid_suffixes = rid_suffixes

    @classmethod
    def load(cls, path: Path) -> "WellKnownSids":
        if not path.exists():
            return cls(fixed={}, rid_suffixes={})
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        rid_raw = data.pop("RID_SUFFIXES", {}) or {}
        rid_suffixes = {int(k): v for k, v in rid_raw.items()}
        return cls(fixed=data, rid_suffixes=rid_suffixes)

    def lookup(self, sid: Optional[str]) -> Optional[str]:
        if not sid:
            return None
        sid_u = sid.upper()
        if sid_u in self.fixed:
            return self.fixed[sid_u]
        if not sid_u.startswith("S-1-5-21-"):
            return None
        parts = sid_u.split("-")
        if len(parts) < 8:
            return None
        try:
            rid = int(parts[-1])
        except ValueError:
            return None
        return self.rid_suffixes.get(rid)

    def is_known(self, sid: Optional[str]) -> bool:
        return self.lookup(sid) is not None