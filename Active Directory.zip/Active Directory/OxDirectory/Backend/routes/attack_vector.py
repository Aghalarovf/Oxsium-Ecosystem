import sqlite3

from flask import g, request

from app import app
from helpers import _ok, _err
import auth
import engine


def _user_name():
    user = getattr(g, "current_user", None) or {}
    return str(user.get("username") or "anonymous")


@app.route("/api/attack-vector", methods=["GET"])
@auth.login_required
def attack_vector():
    try:
        limit = int(request.args.get("limit", 300))
    except ValueError:
        return _err("Limit must be an integer", 400)
    limit = min(max(limit, 1), 2000)
    try:
        graph = engine.build_attack_graph(search=request.args.get("q", "").strip(), limit=limit)
    except sqlite3.Error as error:
        return _err(f"Could not build attack graph: {error}", 500)
    return _ok(**graph)


@app.route("/api/attack-vector/queries", methods=["GET"])
@auth.login_required
def attack_vector_queries():
    return _ok(packages=engine.catalog())


@app.route("/api/attack-vector/query", methods=["POST"])
@auth.login_required
def attack_vector_run():
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict) or not isinstance(payload.get("query_id"), str):
        return _err("query_id is required", 400)
    params = payload.get("params")
    if not isinstance(params, dict):
        params = {}
    try:
        graph = engine.run_query(
            payload["query_id"],
            params,
            user=_user_name(),
            record=not payload.get("silent"),
            options=payload.get("options"),
        )
    except KeyError:
        return _err("Unknown query", 404)
    except ValueError as error:
        return _err(str(error), 400)
    except sqlite3.Error as error:
        return _err(f"Query failed: {error}", 500)
    return _ok(**graph)


@app.route("/api/attack-vector/history", methods=["GET"])
@auth.login_required
def attack_vector_history():
    return _ok(entries=engine.list_entries(user=_user_name()))


@app.route("/api/attack-vector/history", methods=["DELETE"])
@auth.login_required
def attack_vector_history_clear():
    engine.clear(user=_user_name())
    return _ok()
