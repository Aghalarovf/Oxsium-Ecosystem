const AV_RISK_ORDER = ["critical", "high", "medium", "low", "info"];
const AV_DETAILS_CLOSE_MS = 260;
const AV_ICON_AIM = '<svg class="av-d-aim" viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="3"/><path d="M8 1.5v3M8 11.5v3M1.5 8h3M11.5 8h3"/></svg>';
const AV_ICON_COLLAPSE = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3.5 6l4.5 4.5L12.5 6"/></svg>';
const AV_ICON_CLOSE = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 4l8 8M12 4l-8 8"/></svg>';
const AV_ICON_SEARCH = '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5L14 14"/></svg>';

function avRiskRank(risk) {
    const index = AV_RISK_ORDER.indexOf(risk);
    return index === -1 ? AV_RISK_ORDER.length : index;
}

function avRiskChip(risk) {
    if (!risk) return "";
    const known = AV_RISK_ORDER.includes(risk) ? risk : "info";
    return `<span class="av-d-risk is-${known}">${Util.esc(risk)}</span>`;
}

function avKindLabel(node) {
    return (AV_KINDS[node.kind] || AV_KINDS.other).label;
}

function avDetailsRow(label, value, mono = true) {
    if (value === null || value === undefined || value === "") return "";
    return `<div class="av-d-row"><span class="av-d-key">${Util.esc(label)}</span><span class="av-d-val${mono ? " is-mono" : ""}">${Util.esc(value)}</span></div>`;
}

function avDetailsStat(label, value) {
    return `<div class="av-d-stat"><span class="av-d-stat-value">${value}</span><span class="av-d-stat-label">${Util.esc(label)}</span></div>`;
}

function avDetailsEdge(item, index, byId) {
    const edge = item.edge;
    const peer = byId.get(item.dir === "out" ? edge.target : edge.source);
    const title = edge.type || edge.label || "Relation";
    const extraTypes = (edge.types || []).filter(entry => entry.type !== edge.type);
    const evidence = Array.isArray(edge.evidence) ? edge.evidence.filter(value => value !== null && value !== undefined) : [];
    const rights = (edge.rights || []).map(right => `<span class="av-d-right">${Util.esc(right)}</span>`).join("");
    const guids = Array.isArray(edge.guids) ? edge.guids : [];
    const guidBlock = guids.length
        ? `<div class="av-d-block"><span class="av-d-key">Object GUIDs</span><div class="av-d-guids">${guids.map(entry => `
            <div class="av-d-guid">${entry.right ? `<span class="av-d-guid-right">${Util.esc(entry.right)}</span>` : ""}<span class="av-d-guid-value">${Util.esc(entry.guid)}</span></div>`).join("")}</div></div>`
        : "";
    const search = [peer.name, title, edge.rule_id, ...(edge.rights || []), ...extraTypes.map(entry => entry.type), ...guids.map(entry => entry.guid)].join(" ").toLowerCase();
    const types = extraTypes.length
        ? `<div class="av-d-block"><span class="av-d-key">Also grants</span><div class="av-d-typelist">${extraTypes.map(entry => `
            <div class="av-d-typeitem"><span class="av-d-typename">${Util.esc(entry.type)}</span>${avRiskChip(entry.risk)}${entry.rule_id ? `<span class="av-d-typerule">${Util.esc(entry.rule_id)}</span>` : ""}</div>`).join("")}</div></div>`
        : "";
    return `
        <div class="av-query av-d-item" data-index="${index}" data-search="${Util.esc(search)}">
            <button class="av-query-btn" type="button" aria-expanded="false">
                <span class="av-d-dir">${item.dir === "out" ? "→" : "←"}</span>
                <span class="av-d-peer-dot" style="background:${avNodeColor(peer).fill}"></span>
                <span class="av-d-rowtext">
                    <span class="av-query-name">${Util.esc(peer.name)}</span>
                    <span class="av-d-rowsub">${Util.esc(title)} · ${Util.esc(avKindLabel(peer))}</span>
                </span>
                ${avRiskChip(edge.risk)}
                ${AV_ICON_CHEVRON}
            </button>
            <div class="av-query-form">
                <div class="av-query-inner">
                    <div class="av-d-edge-meta">
                        ${avDetailsRow("Relation", title)}
                        ${avDetailsRow("Direction", item.dir === "out" ? "Outbound" : "Inbound", false)}
                        ${avDetailsRow("Peer", avKindLabel(peer), false)}
                        ${avDetailsRow("Peer ID", peer.id)}
                        ${avDetailsRow("Rule", edge.rule_id)}
                        ${avDetailsRow("Weight", edge.weight)}
                        ${avDetailsRow("Evidence", evidence.length ? `${evidence.length} ${evidence.length === 1 ? "record" : "records"}` : "")}
                    </div>
                    ${rights ? `<div class="av-d-block"><span class="av-d-key">Rights</span><div class="av-d-rights">${rights}</div></div>` : ""}
                    ${types}
                    ${guidBlock}
                    <button class="av-run av-d-select" type="button" data-peer="${Util.esc(peer.id)}">${AV_ICON_AIM}<span>Select ${Util.esc(peer.name.length > 28 ? `${peer.name.slice(0, 27)}…` : peer.name)}</span></button>
                </div>
            </div>
        </div>`;
}

function avDetailsList(list, render, empty) {
    if (!list.length) return `<div class="av-note av-note-empty"><b>${Util.esc(empty)}</b></div>`;
    return `${list.map(render).join("")}<div class="av-note av-nomatch" hidden>No edges match your filter</div>`;
}

function avDetailsHide(panel) {
    if (!panel || panel.hidden) return;
    panel.classList.remove("is-open");
    clearTimeout(panel.avHideTimer);
    const finish = () => {
        panel.hidden = true;
        panel.innerHTML = "";
        panel.classList.remove("is-collapsed");
    };
    if (Util.reducedMotion()) finish();
    else panel.avHideTimer = setTimeout(finish, AV_DETAILS_CLOSE_MS);
}

function avDetailsShow(panel, node, graph, byId, handlers) {
    if (!panel) return;
    clearTimeout(panel.avHideTimer);
    const outgoing = graph.edges.filter(edge => edge.source === node.id).map(edge => ({ edge, dir: "out" }));
    const incoming = graph.edges.filter(edge => edge.target === node.id).map(edge => ({ edge, dir: "in" }));
    const items = [...outgoing, ...incoming];
    const peers = new Set(items.map(item => (item.dir === "out" ? item.edge.target : item.edge.source)));
    peers.delete(node.id);

    const counts = {};
    items.forEach(item => {
        if (item.edge.risk) counts[item.edge.risk] = (counts[item.edge.risk] || 0) + 1;
    });
    const ranked = Object.keys(counts).sort((a, b) => avRiskRank(a) - avRiskRank(b));
    const top = ranked[0];
    const flags = Array.isArray(node.flags) ? node.flags : [];
    const color = avNodeColor(node);
    const render = item => avDetailsEdge(item, items.indexOf(item), byId);

    const flagHtml = flags.length
        ? flags.map(flag => `<span class="av-d-flag">${Util.esc(String(flag).replace(/_/g, " "))}</span>`).join("")
        : '<span class="av-d-none-inline">None</span>';
    const riskHtml = ranked.length
        ? ranked.map(risk => `<span class="av-d-riskcount">${avRiskChip(risk)}<b>${counts[risk]}</b></span>`).join("")
        : '<span class="av-d-none-inline">No rated edges</span>';
    const footText = `${outgoing.length} outbound · ${incoming.length} inbound · ${top ? `top risk ${top}` : "no rated edges"}`;

    const wasOpen = panel.classList.contains("is-open");
    panel.innerHTML = `
        <div class="av-engine-head">
            <div class="av-engine-brand">
                <span class="av-engine-mark av-d-mark" style="border-color:${color.stroke}80;background:linear-gradient(145deg,${color.fill}66,${color.fill}14)">
                    <img src="${Util.esc(avNodeIconHref(node))}" alt="">
                </span>
                <div class="av-engine-heading">
                    <span class="av-engine-title" title="${Util.esc(node.name)}">${Util.esc(node.name)}</span>
                    <span class="av-engine-sub">${Util.esc(avKindLabel(node))}${avNodeIsPrivileged(node) ? " · Privileged" : ""}</span>
                </div>
            </div>
            <div class="av-d-actions">
                <button class="av-engine-toggle av-d-toggle" type="button" aria-expanded="true" aria-label="Collapse details">${AV_ICON_COLLAPSE}</button>
                <button class="av-engine-toggle av-d-close" type="button" aria-label="Close details">${AV_ICON_CLOSE}</button>
            </div>
        </div>
        <div class="av-engine-collapse">
            <div class="av-engine-body">
                <div class="av-tabs" role="tablist">
                    <button class="av-tab is-active" type="button" role="tab" data-tab="overview"><span>Overview</span></button>
                    <button class="av-tab" type="button" role="tab" data-tab="out"><span>Outbound</span><span class="av-tab-count">${outgoing.length || ""}</span></button>
                    <button class="av-tab" type="button" role="tab" data-tab="in"><span>Inbound</span><span class="av-tab-count">${incoming.length || ""}</span></button>
                </div>
                <div class="av-filter" hidden>
                    ${AV_ICON_SEARCH}
                    <input class="av-filter-input" type="search" placeholder="Filter edges" autocomplete="off" spellcheck="false" aria-label="Filter edges">
                </div>
                <div class="av-pane av-d-pane" data-pane="overview">
                    <div class="av-d-card">
                        <div class="av-d-card-head">Identity</div>
                        ${avDetailsRow("Name", node.name, false)}
                        ${avDetailsRow("Type", avKindLabel(node), false)}
                        ${avDetailsRow("Object ID", node.id)}
                        ${avDetailsRow("Distinguished name", node.dn)}
                        ${avDetailsRow("Graph layer", node.layer === undefined ? "" : node.layer + 1, false)}
                        <div class="av-d-row"><span class="av-d-key">Privileges</span><span class="av-d-flags">${flagHtml}</span></div>
                    </div>
                    <div class="av-d-card">
                        <div class="av-d-card-head">Connections</div>
                        <div class="av-d-stats">
                            ${avDetailsStat("Outbound", outgoing.length)}
                            ${avDetailsStat("Inbound", incoming.length)}
                            ${avDetailsStat("Neighbors", peers.size)}
                            ${avDetailsStat("Top risk", top ? avRiskChip(top) : "—")}
                        </div>
                        <div class="av-d-riskline">${riskHtml}</div>
                    </div>
                </div>
                <div class="av-pane av-d-pane" data-pane="out" hidden>${avDetailsList(outgoing, render, "No outbound edges")}</div>
                <div class="av-pane av-d-pane" data-pane="in" hidden>${avDetailsList(incoming, render, "No inbound edges")}</div>
                <div class="av-engine-foot" data-state="ok">
                    <span class="av-foot-dot" aria-hidden="true"></span>
                    <span class="av-foot-text" title="${Util.esc(footText)}">${Util.esc(footText)}</span>
                </div>
            </div>
        </div>`;
    panel.hidden = false;
    if (!wasOpen) {
        void panel.offsetWidth;
        panel.classList.add("is-open");
    }

    const filterWrap = panel.querySelector(".av-filter");
    const filterInput = panel.querySelector(".av-filter-input");
    const panes = [...panel.querySelectorAll(".av-d-pane")];
    const activePane = () => panes.find(pane => !pane.hidden);

    const applyFilter = () => {
        const pane = activePane();
        if (!pane || pane.dataset.pane === "overview") return;
        const term = filterInput.value.trim().toLowerCase();
        let shown = 0;
        pane.querySelectorAll(".av-d-item").forEach(row => {
            const hit = !term || row.dataset.search.includes(term);
            row.hidden = !hit;
            if (hit) shown += 1;
        });
        const none = pane.querySelector(".av-nomatch");
        if (none) none.hidden = shown > 0;
    };

    panel.querySelector(".av-d-close").addEventListener("click", () => handlers.close());

    const toggle = panel.querySelector(".av-d-toggle");
    toggle.addEventListener("click", () => {
        const collapsed = panel.classList.toggle("is-collapsed");
        toggle.setAttribute("aria-expanded", String(!collapsed));
        toggle.setAttribute("aria-label", collapsed ? "Expand details" : "Collapse details");
    });

    panel.querySelectorAll(".av-tab").forEach(tab => {
        tab.addEventListener("click", () => {
            panel.querySelectorAll(".av-tab").forEach(other => other.classList.toggle("is-active", other === tab));
            panes.forEach(pane => {
                pane.hidden = pane.dataset.pane !== tab.dataset.tab;
            });
            const edgesTab = tab.dataset.tab !== "overview";
            filterWrap.hidden = !edgesTab;
            if (edgesTab) applyFilter();
        });
    });

    filterInput.addEventListener("input", applyFilter);
    filterInput.addEventListener("keydown", event => {
        if (event.key === "Escape" && filterInput.value) {
            filterInput.value = "";
            applyFilter();
            event.stopPropagation();
        }
    });

    panel.querySelectorAll(".av-d-item").forEach(row => {
        const item = items[Number(row.dataset.index)];
        const button = row.querySelector(".av-query-btn");
        button.addEventListener("click", () => {
            const open = row.classList.contains("is-open");
            panel.querySelectorAll(".av-d-item.is-open").forEach(other => {
                other.classList.remove("is-open");
                other.querySelector(".av-query-btn").setAttribute("aria-expanded", "false");
            });
            row.classList.toggle("is-open", !open);
            button.setAttribute("aria-expanded", String(!open));
            if (!open) {
                setTimeout(() => row.scrollIntoView({ block: "nearest", behavior: Util.reducedMotion() ? "auto" : "smooth" }), 220);
            }
        });
        row.addEventListener("mouseenter", () => handlers.hoverEdge(item.edge));
        row.addEventListener("mouseleave", () => handlers.hoverEdge(null));
        row.querySelector(".av-d-select").addEventListener("click", event => {
            const peer = byId.get(event.currentTarget.dataset.peer);
            if (peer && peer !== node) handlers.select(peer);
        });
    });
}