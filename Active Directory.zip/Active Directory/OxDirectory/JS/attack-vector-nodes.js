// Node design for the Attack Vector graph.
// Ported from Oxsium-Framework / Decision Engine / Nodes / node_rule.js
// (icon per node type, per-type colours, dashed glow ring, type label).

const AV_NODE_RULES = {
    colors: {
        domain:   { fill: "#7c3aed", stroke: "#a78bfa", glow: "#c4b5fd" },
        user:     { fill: "#0ea5e9", stroke: "#38bdf8", glow: "#7dd3fc" },
        computer: { fill: "#10b981", stroke: "#34d399", glow: "#6ee7b7" },
        group:    { fill: "#8c00ff", stroke: "#7a24fb", glow: "#8d10fb" },
        ou:       { fill: "#6366f1", stroke: "#818cf8", glow: "#a5b4fc" },
        gpo:      { fill: "#ec4899", stroke: "#f472b6", glow: "#fbcfe8" },
        other:    { fill: "#475569", stroke: "#64748b", glow: "#94a3b8" }
    },
    icons: {
        user: "user.png",
        computer: "computer.png",
        group: "group.png",
        domain: "ou.png",
        ou: "ou.png",
        gpo: "gpo.png",
        other: "acl.png"
    },
    // Nodes carrying privilege attributes (node.flags from the backend) are drawn orange.
    privileged: { fill: "#ea580c", stroke: "#f97316", glow: "#fdba74", label: "#f97316" },
    iconBase: "/assets/Icons/",
    radius: { domain: 31.5, default: 22.5 },
    outerRingOffset: 7.2,
    outerRingOpacity: 0.55,
    outerRingDash: "3 3",
    strokeWidth: 1.5,
    activeStrokeWidth: 2.5,
    nodeOpacity: 0.95,
    iconScale: 1.25,
    label: { yOffset: 18, typeYOffset: 31.5, maxLength: 24, color: "#ffffff" },
    edgeExtraOffset: 3.6
};

function avNodeKind(node) {
    return AV_NODE_RULES.colors[node.kind] ? node.kind : "other";
}

function avNodeIsPrivileged(node) {
    return Array.isArray(node.flags) && node.flags.length > 0;
}

function avNodeColor(node) {
    return avNodeIsPrivileged(node) ? AV_NODE_RULES.privileged : AV_NODE_RULES.colors[avNodeKind(node)];
}

function avNodeRadius(node) {
    return node.kind === "domain" ? AV_NODE_RULES.radius.domain : AV_NODE_RULES.radius.default;
}

function avNodeOuterRadius(node) {
    return avNodeRadius(node) + AV_NODE_RULES.outerRingOffset;
}

// Edges start/end just outside the dashed ring.
function avNodeEdgePadding(node) {
    return avNodeOuterRadius(node) + AV_NODE_RULES.edgeExtraOffset;
}

function avNodeIconSize(node) {
    return Math.round(avNodeRadius(node) * AV_NODE_RULES.iconScale);
}

function avNodeIconHref(node) {
    return AV_NODE_RULES.iconBase + (AV_NODE_RULES.icons[avNodeKind(node)] || AV_NODE_RULES.icons.other);
}

function avNodeLabelDy(node) {
    return avNodeRadius(node) + AV_NODE_RULES.label.yOffset;
}

function avNodeTypeLabelDy(node) {
    return avNodeRadius(node) + AV_NODE_RULES.label.typeYOffset;
}

function avNodeLabelText(node) {
    const max = AV_NODE_RULES.label.maxLength;
    const name = node.name || "";
    return name.length > max ? `${name.slice(0, max - 1)}…` : name;
}

// Glow filter used by the outer ring (same as the Decision Engine's #glow).
function avNodeDefs(defs) {
    const filter = defs.append("filter").attr("id", "av-node-glow")
        .attr("x", "-50%").attr("y", "-50%").attr("width", "200%").attr("height", "200%");
    filter.append("feGaussianBlur").attr("stdDeviation", 5).attr("result", "coloredBlur");
    const merge = filter.append("feMerge");
    merge.append("feMergeNode").attr("in", "coloredBlur");
    merge.append("feMergeNode").attr("in", "coloredBlur");
    merge.append("feMergeNode").attr("in", "SourceGraphic");

    const gem = defs.append("linearGradient").attr("id", "av-gem-fill")
        .attr("x1", 0).attr("y1", 0).attr("x2", 1).attr("y2", 1);
    gem.append("stop").attr("offset", "0%").attr("stop-color", "#e0f7ff");
    gem.append("stop").attr("offset", "55%").attr("stop-color", "#67d4f5");
    gem.append("stop").attr("offset", "100%").attr("stop-color", "#2b8fd6");
}

// Crystal badge placed on the top-right of the icon of privileged nodes.
function avNodeBadge(nodes) {
    const privileged = nodes.filter(avNodeIsPrivileged);
    const badge = privileged.append("g")
        .attr("class", "av-node-badge")
        .attr("pointer-events", "none")
        .attr("transform", node => {
            const offset = avNodeRadius(node) * 0.72;
            return `translate(${offset},${-offset})`;
        });
    badge.append("circle").attr("class", "av-node-badge-bg").attr("r", 8.5);
    badge.append("polygon")
        .attr("class", "av-gem")
        .attr("points", "-3.2,-3.6 3.2,-3.6 5.4,-0.9 0,4.8 -5.4,-0.9")
        .attr("fill", "url(#av-gem-fill)");
    badge.append("path")
        .attr("class", "av-gem-facets")
        .attr("d", "M-5.4,-0.9H5.4M-1.8,-0.9L-0.9,-3.6M1.8,-0.9L0.9,-3.6M-1.8,-0.9L0,4.8L1.8,-0.9");
}

// Draws ring, circle, icon, name and type label for every node group.
function avNodeDraw(nodes) {
    const rules = AV_NODE_RULES;

    nodes.append("circle")
        .attr("class", "av-node-ring")
        .attr("r", avNodeOuterRadius)
        .attr("fill", "none")
        .attr("stroke", node => avNodeColor(node).glow)
        .attr("stroke-width", rules.strokeWidth)
        .attr("stroke-dasharray", rules.outerRingDash)
        .attr("opacity", rules.outerRingOpacity)
        .attr("filter", "url(#av-node-glow)");

    nodes.append("circle")
        .attr("class", "av-node-circle")
        .attr("r", avNodeRadius)
        .attr("fill", node => avNodeColor(node).fill)
        .attr("stroke", node => avNodeColor(node).stroke)
        .attr("stroke-width", rules.strokeWidth)
        .attr("opacity", rules.nodeOpacity);

    nodes.append("image")
        .attr("class", "av-node-icon")
        .attr("width", avNodeIconSize)
        .attr("height", avNodeIconSize)
        .attr("x", node => -avNodeIconSize(node) / 2)
        .attr("y", node => -avNodeIconSize(node) / 2)
        .attr("preserveAspectRatio", "xMidYMid meet")
        .attr("pointer-events", "none")
        .attr("href", avNodeIconHref);

    avNodeBadge(nodes);

    nodes.append("text")
        .attr("class", "av-name")
        .attr("y", avNodeLabelDy)
        .attr("fill", node => (avNodeIsPrivileged(node) ? rules.privileged.label : rules.label.color))
        .text(avNodeLabelText);

    nodes.append("text")
        .attr("class", "av-type")
        .attr("y", avNodeTypeLabelDy)
        .attr("fill", node => avNodeColor(node).fill)
        .text(node => (node.kind || "other").toUpperCase());
}
