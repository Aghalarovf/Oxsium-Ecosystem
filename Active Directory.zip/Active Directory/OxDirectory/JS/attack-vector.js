const AV_KINDS = {
    user: { label: "User" },
    group: { label: "Group" },
    computer: { label: "Computer" },
    domain: { label: "Domain" },
    ou: { label: "OU" },
    gpo: { label: "GPO" },
    other: { label: "Other" }
};

const AV_COLUMN_GAP = 360;
const AV_COLUMN_GAP_FREE_ROWS = 4;
const AV_COLUMN_GAP_PER_ROW = 36;
const AV_COLUMN_GAP_MAX = 3200;
const AV_ROW_GAP = 150;
const AV_ICON_CHEVRON = '<svg class="av-chev" viewBox="0 0 16 16" aria-hidden="true"><path d="M5.5 3.5L10 8l-4.5 4.5"/></svg>';
const AV_ICON_PLAY = '<svg class="av-play" viewBox="0 0 16 16" aria-hidden="true"><path d="M4.5 3.2v9.6L12.8 8z"/></svg>';
const AV_DEFAULT_MAX_RIGHT_EDGES = 50;
const AV_MAX_RIGHT_EDGES_CEILING = 1000000;
const AV_WAVE_PERIOD = 96;
const AV_WAVE_COLOR = "#ffa24a";
const AV_WAVE_SECONDS = 1.9;
const AV_LINE_COLOR = "#f5e8a0";
const AV_RISK_DOT = { info: "#8f8977", low: "#c9b98a", medium: "#f2c94c", high: "#ffb02e", critical: "#ff8a3d" };

function avApplyFilters(graph, filters) {
    const hiddenIds = new Set();
    graph.nodes.forEach(node => {
        if (node.orphaned && !filters.orphaned) hiddenIds.add(node.id);
    });
    if (!hiddenIds.size) return { nodes: graph.nodes, edges: graph.edges, hidden: 0 };
    const edges = graph.edges.filter(edge => !hiddenIds.has(edge.source) && !hiddenIds.has(edge.target));
    const connected = new Set();
    graph.edges.forEach(edge => {
        connected.add(edge.source);
        connected.add(edge.target);
    });
    const visible = new Set();
    edges.forEach(edge => {
        visible.add(edge.source);
        visible.add(edge.target);
    });
    const nodes = graph.nodes.filter(node => !hiddenIds.has(node.id) && (visible.has(node.id) || !connected.has(node.id)));
    return { nodes, edges, hidden: hiddenIds.size };
}

function avCrossings(segments) {
    let count = 0;
    for (let i = 0; i < segments.length; i++) {
        const s = segments[i];
        for (let j = i + 1; j < segments.length; j++) {
            const t = segments[j];
            const lo = Math.max(s.x0, t.x0);
            const hi = Math.min(s.x1, t.x1);
            if (lo >= hi) continue;
            const sl = s.y0 + (s.y1 - s.y0) * (lo - s.x0) / (s.x1 - s.x0);
            const tl = t.y0 + (t.y1 - t.y0) * (lo - t.x0) / (t.x1 - t.x0);
            const sh = s.y0 + (s.y1 - s.y0) * (hi - s.x0) / (s.x1 - s.x0);
            const th = t.y0 + (t.y1 - t.y0) * (hi - t.x0) / (t.x1 - t.x0);
            if ((sl - tl) * (sh - th) < 0) count++;
        }
    }
    return count;
}

function avOrderColumns(graph, lists) {
    const layerOf = new Map();
    lists.forEach((list, position) => list.forEach(node => layerOf.set(node.id, position)));
    const lower = new Map(graph.nodes.map(node => [node.id, []]));
    const upper = new Map(graph.nodes.map(node => [node.id, []]));
    const links = [];
    graph.edges.forEach(edge => {
        const a = layerOf.get(edge.source);
        const b = layerOf.get(edge.target);
        if (a === b) return;
        const [from, to] = a < b ? [edge.source, edge.target] : [edge.target, edge.source];
        upper.get(to).push(from);
        lower.get(from).push(to);
        links.push([from, to]);
    });
    const tallest = Math.max(1, ...lists.map(list => list.length));
    const slots = new Map();
    const assign = list => {
        const offset = (tallest - list.length) / 2;
        list.forEach((node, index) => slots.set(node.id, index + offset));
    };
    const measure = () => {
        if (links.length > 1500) return 0;
        return avCrossings(links.map(([from, to]) => ({
            x0: layerOf.get(from), y0: slots.get(from), x1: layerOf.get(to), y1: slots.get(to)
        })));
    };
    const reorder = (position, primary, secondary) => {
        const list = lists[position];
        const before = new Map(list.map((node, index) => [node.id, index]));
        const score = node => {
            let ids = primary.get(node.id);
            if (!ids.length) ids = secondary.get(node.id);
            if (!ids.length) return slots.get(node.id);
            return ids.reduce((sum, id) => sum + slots.get(id), 0) / ids.length;
        };
        const scores = new Map(list.map(node => [node.id, score(node)]));
        list.sort((a, b) => scores.get(a.id) - scores.get(b.id) || before.get(a.id) - before.get(b.id));
        assign(list);
    };
    const sweeps = lists.length > 1 ? 40 : 0;
    let best = lists.map(list => list.slice());
    lists.forEach(assign);
    let bestScore = measure();
    let stale = 0;
    for (let round = 0; round < sweeps && bestScore > 0 && stale < 8; round++) {
        for (let position = 1; position < lists.length; position++) reorder(position, upper, lower);
        for (let position = lists.length - 2; position >= 0; position--) reorder(position, lower, upper);
        const score = measure();
        if (score < bestScore) {
            bestScore = score;
            best = lists.map(list => list.slice());
            stale = 0;
        } else {
            stale++;
        }
    }
    return { lists: best, score: bestScore };
}

function avLayout(graph) {
    const columns = new Map();
    graph.nodes.forEach(node => {
        if (!columns.has(node.layer)) columns.set(node.layer, []);
        columns.get(node.layer).push(node);
    });
    const order = [...columns.keys()].sort((a, b) => a - b);
    const byName = (a, b) => a.name.localeCompare(b.name);
    const starts = [
        order.map(layer => columns.get(layer).slice().sort(byName)),
        order.map(layer => columns.get(layer).slice().sort((a, b) => byName(b, a)))
    ];
    let winner = null;
    starts.forEach(lists => {
        const result = avOrderColumns(graph, lists);
        if (!winner || result.score < winner.score) winner = result;
    });
    order.forEach((layer, position) => columns.set(layer, winner.lists[position]));
    const tallest = Math.max(1, ...[...columns.values()].map(list => list.length));
    let columnX = 0;
    order.forEach((layer, position) => {
        const list = columns.get(layer);
        if (position > 0) {
            const widest = Math.max(list.length, columns.get(order[position - 1]).length);
            const extra = Math.max(0, widest - AV_COLUMN_GAP_FREE_ROWS) * AV_COLUMN_GAP_PER_ROW;
            columnX += Math.min(AV_COLUMN_GAP + extra, AV_COLUMN_GAP_MAX);
        }
        const offset = (tallest - list.length) / 2;
        list.forEach((node, index) => {
            node.row = index;
            node.x = columnX;
            node.y = (index + offset) * AV_ROW_GAP;
        });
    });
}

function avTagSpread(geometry, widths) {
    const candidates = [0.5, 0.42, 0.58, 0.34, 0.66, 0.26, 0.74, 0.18, 0.82];
    const placed = [];
    const height = 24;
    return geometry.map((g, i) => {
        let bestT = 0.5;
        let bestHits = Infinity;
        for (const t of candidates) {
            const x = g.x1 + (g.x2 - g.x1) * t;
            const y = g.y1 + (g.y2 - g.y1) * t;
            let hits = 0;
            for (const box of placed) {
                if (Math.abs(box.x - x) < (box.w + widths[i]) / 2 + 4 && Math.abs(box.y - y) < height) hits++;
            }
            if (hits < bestHits) {
                bestHits = hits;
                bestT = t;
            }
            if (!hits) break;
        }
        placed.push({
            x: g.x1 + (g.x2 - g.x1) * bestT,
            y: g.y1 + (g.y2 - g.y1) * bestT,
            w: widths[i]
        });
        return bestT;
    });
}

function avEdgePath(edge, byId) {
    const source = byId.get(edge.source);
    const target = byId.get(edge.target);
    const dx = target.x - source.x;
    const dy = target.y - source.y;
    const len = Math.hypot(dx, dy) || 1;
    const ux = dx / len;
    const uy = dy / len;
    const sourcePad = avNodeEdgePadding(source);
    const targetPad = avNodeEdgePadding(target);
    const x1 = source.x + ux * sourcePad;
    const y1 = source.y + uy * sourcePad;
    const x2 = target.x - ux * targetPad;
    const y2 = target.y - uy * targetPad;
    return { x1, y1, x2, y2, ux, uy, d: `M${x1},${y1} L${x2},${y2}` };
}

function avRender(view, graph) {
    const svg = d3.select(view.querySelector(".av-svg"));
    const empty = view.querySelector(".av-empty");
    const tip = view.querySelector(".av-tip");
    const stage = view.querySelector(".av-stage");
    const details = view.querySelector(".av-details");
    avDetailsHide(details);
    svg.selectAll("*").remove();
    empty.textContent = "No attack paths found";
    empty.hidden = graph.nodes.length > 0;
    if (!graph.nodes.length) return null;

    avLayout(graph);
    const byId = new Map(graph.nodes.map(node => [node.id, node]));

    const defs = svg.append("defs");
    avNodeDefs(defs);
    const animate = !Util.reducedMotion();
    svg.classed("is-reduced", !animate);

    const root = svg.append("g");
    const edgeLayer = root.append("g");
    const tagLayer = root.append("g");
    const nodeLayer = root.append("g");

    const geometry = graph.edges.map(edge => avEdgePath(edge, byId));
    const stops = (grad, list) => list.forEach(([offset, color, opacity]) =>
        grad.append("stop").attr("offset", offset).attr("stop-color", color).attr("stop-opacity", opacity));

    geometry.forEach((g, i) => {
        stops(defs.append("linearGradient")
            .attr("id", `av-line-${i}`)
            .attr("gradientUnits", "userSpaceOnUse")
            .attr("x1", g.x1).attr("y1", g.y1).attr("x2", g.x2).attr("y2", g.y2),
        [["0%", AV_LINE_COLOR, 0.85], ["100%", AV_LINE_COLOR, 0.4]]);

        stops(defs.append("linearGradient")
            .attr("id", `av-wave-${i}`)
            .attr("gradientUnits", "userSpaceOnUse")
            .attr("spreadMethod", "repeat")
            .attr("x1", g.x1).attr("y1", g.y1)
            .attr("x2", g.x1 + g.ux * AV_WAVE_PERIOD).attr("y2", g.y1 + g.uy * AV_WAVE_PERIOD),
        [["0%", AV_WAVE_COLOR, 0], ["60%", AV_WAVE_COLOR, 0.18], ["90%", "#ffc27a", 0.95], ["100%", "#ffe2b0", 0]]);
    });

    const edges = edgeLayer.selectAll("g").data(graph.edges).enter().append("g")
        .attr("class", edge => `av-edge-group${edge.risk ? ` risk-${edge.risk}` : ""}`);
    edges.append("path").attr("class", "av-edge-glow").attr("d", (edge, i) => geometry[i].d);
    edges.append("path").attr("class", "av-edge-hit").attr("d", (edge, i) => geometry[i].d);
    edges.append("path").attr("class", "av-edge")
        .attr("d", (edge, i) => geometry[i].d)
        .attr("stroke", (edge, i) => `url(#av-line-${i})`);
    edges.append("path").attr("class", "av-flow av-flow-glow")
        .attr("d", (edge, i) => geometry[i].d)
        .attr("stroke", (edge, i) => `url(#av-wave-${i})`);
    edges.append("path").attr("class", "av-flow")
        .attr("d", (edge, i) => geometry[i].d)
        .attr("stroke", (edge, i) => `url(#av-wave-${i})`);
    edges.append("circle").attr("class", "av-port").attr("r", 2.6)
        .attr("cx", (edge, i) => geometry[i].x1).attr("cy", (edge, i) => geometry[i].y1);
    edges.append("circle").attr("class", "av-port").attr("r", 2.6)
        .attr("cx", (edge, i) => geometry[i].x2).attr("cy", (edge, i) => geometry[i].y2);

    const tagText = edge => edge.label;
    const tagExtra = edge => (edge.extra ? `+${edge.extra}` : "");
    const tagWidth = edge => Math.round(tagText(edge).length * 6.2 + (tagExtra(edge) ? tagExtra(edge).length * 6.2 + 10 : 0) + 26);
    const tagT = avTagSpread(geometry, graph.edges.map(tagWidth));
    const tagPoint = i => `translate(${geometry[i].x1 + (geometry[i].x2 - geometry[i].x1) * tagT[i]},${geometry[i].y1 + (geometry[i].y2 - geometry[i].y1) * tagT[i]})`;
    const tags = tagLayer.selectAll("g").data(graph.edges).enter().append("g")
        .attr("class", edge => `av-tag${edge.risk ? ` risk-${edge.risk}` : ""}`)
        .attr("transform", (edge, i) => tagPoint(i));
    tags.append("rect").attr("class", "av-tag-box")
        .attr("x", edge => -tagWidth(edge) / 2).attr("y", -10)
        .attr("width", tagWidth).attr("height", 20).attr("rx", 10);
    tags.append("circle").attr("class", "av-tag-dot").attr("r", 2.8)
        .attr("cx", edge => -tagWidth(edge) / 2 + 11).attr("cy", 0)
        .attr("fill", edge => AV_RISK_DOT[edge.risk] || AV_RISK_DOT.low);
    tags.append("text").attr("class", "av-tag-text")
        .attr("x", edge => -tagWidth(edge) / 2 + 20).attr("y", 0)
        .each(function(edge) {
            const node = d3.select(this);
            node.append("tspan").text(tagText(edge));
            if (tagExtra(edge)) node.append("tspan").attr("class", "av-tag-extra").attr("dx", 6).text(tagExtra(edge));
        });

    const nodes = nodeLayer.selectAll("g").data(graph.nodes).enter().append("g")
        .attr("class", "av-node")
        .attr("data-kind", node => node.kind)
        .attr("transform", node => `translate(${node.x},${node.y})`);
    avNodeDraw(nodes);

    let dragging = false;
    const showTip = (event, html) => {
        if (dragging) return;
        const box = stage.getBoundingClientRect();
        tip.innerHTML = html;
        tip.hidden = false;
        tip.style.left = `${event.clientX - box.left + 14}px`;
        tip.style.top = `${event.clientY - box.top + 14}px`;
    };
    const hideTip = () => {
        tip.hidden = true;
    };

    nodes.on("mousemove", (event, node) => {
        const flags = Array.isArray(node.flags) && node.flags.length ? `<br>${Util.esc(node.flags.join(", "))}` : "";
        showTip(event, `<b>${Util.esc(node.name)}</b><br>${Util.esc((AV_KINDS[node.kind] || AV_KINDS.other).label)}<br>${Util.esc(node.id)}${flags}`);
    }).on("mouseenter", (event, node) => {
        hoverNode = node;
        syncFlow();
    }).on("mouseleave", () => {
        hoverNode = null;
        syncFlow();
        hideTip();
    });

    const edgeIndex = new Map(graph.edges.map((edge, i) => [edge, i]));
    const incident = new Map(graph.nodes.map(node => [node.id, []]));
    graph.edges.forEach((edge, i) => {
        incident.get(edge.source).push(i);
        incident.get(edge.target).push(i);
    });
    const flowing = new Set();
    let selected = null;
    let hoverNode = null;
    const startFlow = i => {
        flowing.add(i);
        if (!animate) return;
        const g = geometry[i];
        defs.select(`#av-wave-${i}`).append("animateTransform")
            .attr("attributeName", "gradientTransform")
            .attr("type", "translate")
            .attr("from", "0 0")
            .attr("to", `${g.ux * AV_WAVE_PERIOD} ${g.uy * AV_WAVE_PERIOD}`)
            .attr("dur", `${AV_WAVE_SECONDS}s`)
            .attr("repeatCount", "indefinite");
    };
    const stopFlow = i => {
        flowing.delete(i);
        defs.select(`#av-wave-${i}`).select("animateTransform").remove();
    };
    const syncFlow = () => {
        const wanted = new Set();
        [hoverNode, selected].forEach(node => {
            if (node) incident.get(node.id).forEach(i => wanted.add(i));
        });
        [...flowing].forEach(i => { if (!wanted.has(i)) stopFlow(i); });
        wanted.forEach(i => { if (!flowing.has(i)) startFlow(i); });
        edges.classed("is-flowing", edge => flowing.has(edgeIndex.get(edge)));
    };

    let hovered = null;
    const setHover = edge => {
        hovered = edge;
        edges.classed("is-hover", e => e === hovered);
        tags.classed("is-hover", e => e === hovered);
    };
    const edgeTip = (event, edge) => {
        setHover(edge);
        const head = edge.type ? `<b>${Util.esc(edge.type)}</b>${edge.risk ? ` · ${Util.esc(edge.risk)}` : ""}<br>` : "";
        const types = (edge.types || []).length > 1 ? `<br>${edge.types.map(item => `${Util.esc(item.type)} · ${Util.esc(item.risk)}`).join("<br>")}` : "";
        const tail = edge.rule_id ? `<br>rule: ${Util.esc(edge.rule_id)}` : "";
        showTip(event, `${head}<b>${Util.esc(byId.get(edge.source).name)}</b> → <b>${Util.esc(byId.get(edge.target).name)}</b>${types}<br>${edge.rights.map(Util.esc).join("<br>")}${tail}`);
    };
    const edgeLeave = () => {
        setHover(null);
        hideTip();
    };
    edges.on("mousemove", edgeTip).on("mouseleave", edgeLeave);
    tags.on("mousemove", edgeTip).on("mouseleave", edgeLeave);

    const highlight = node => {
        selected = selected === node ? null : node;
        nodes.classed("is-active", n => n === selected);
        if (!selected) {
            nodes.classed("is-dim", false);
            [edges, tags].forEach(layer => layer.classed("is-dim", false).classed("is-active", false));
            setHover(null);
            avDetailsHide(details);
            syncFlow();
            return;
        }
        const linked = new Set([selected.id]);
        graph.edges.forEach(edge => {
            if (edge.source === selected.id) linked.add(edge.target);
            if (edge.target === selected.id) linked.add(edge.source);
        });
        const touches = edge => edge.source === selected.id || edge.target === selected.id;
        nodes.classed("is-dim", n => !linked.has(n.id));
        [edges, tags].forEach(layer => layer.classed("is-dim", edge => !touches(edge)).classed("is-active", touches));
        avDetailsShow(details, selected, graph, byId, {
            select: peer => {
                highlight(peer);
                focus(peer);
            },
            hoverEdge: setHover,
            close: () => highlight(selected)
        });
        syncFlow();
    };
    nodes.on("click", (event, node) => {
        event.stopPropagation();
        highlight(node);
    });
    svg.on("click", () => {
        if (selected) highlight(selected);
    });

    const edgeNodes = edges.nodes();
    const tagNodes = tags.nodes();
    const applyEdge = i => {
        const g = avEdgePath(graph.edges[i], byId);
        geometry[i] = g;
        const group = d3.select(edgeNodes[i]);
        group.selectAll("path").attr("d", g.d);
        group.selectAll("circle.av-port")
            .attr("cx", (edge, j) => (j === 0 ? g.x1 : g.x2))
            .attr("cy", (edge, j) => (j === 0 ? g.y1 : g.y2));
        defs.select(`#av-line-${i}`)
            .attr("x1", g.x1).attr("y1", g.y1).attr("x2", g.x2).attr("y2", g.y2);
        defs.select(`#av-wave-${i}`)
            .attr("x1", g.x1).attr("y1", g.y1)
            .attr("x2", g.x1 + g.ux * AV_WAVE_PERIOD).attr("y2", g.y1 + g.uy * AV_WAVE_PERIOD)
            .select("animateTransform")
            .attr("to", `${g.ux * AV_WAVE_PERIOD} ${g.uy * AV_WAVE_PERIOD}`);
        d3.select(tagNodes[i]).attr("transform", tagPoint(i));
    };

    const drag = d3.drag()
        .on("start", function(event, node) {
            dragging = true;
            hideTip();
            d3.select(this).raise().classed("is-dragging", true);
            svg.classed("is-node-dragging", true);
        })
        .on("drag", function(event, node) {
            node.x = event.x;
            node.y = event.y;
            d3.select(this).attr("transform", `translate(${node.x},${node.y})`);
            incident.get(node.id).forEach(applyEdge);
        })
        .on("end", function() {
            dragging = false;
            d3.select(this).classed("is-dragging", false);
            svg.classed("is-node-dragging", false);
        });
    nodes.call(drag);

    const zoom = d3.zoom().scaleExtent([0.1, 3]).on("zoom", event => root.attr("transform", event.transform));
    svg.call(zoom).on("dblclick.zoom", null);

    const insets = () => {
        const panel = stage.querySelector(".av-engine");
        return {
            left: panel ? panel.offsetWidth + 24 : 0,
            right: details && details.classList.contains("is-open") ? details.offsetWidth + 24 : 0
        };
    };
    const fit = () => {
        const box = stage.getBoundingClientRect();
        const bounds = root.node().getBBox();
        if (!bounds.width || !bounds.height) return;
        const pad = 40;
        const inset = insets();
        const width = box.width - inset.left - inset.right;
        const scale = Math.min(2, (width - pad * 2) / bounds.width, (box.height - pad * 2) / bounds.height);
        const tx = inset.left + (width - bounds.width * scale) / 2 - bounds.x * scale;
        const ty = (box.height - bounds.height * scale) / 2 - bounds.y * scale;
        svg.transition().duration(Util.reducedMotion() ? 0 : 300).call(zoom.transform, d3.zoomIdentity.translate(tx, ty).scale(scale));
    };
    const focus = node => {
        const box = stage.getBoundingClientRect();
        const inset = insets();
        const current = d3.zoomTransform(svg.node());
        const cx = inset.left + (box.width - inset.left - inset.right) / 2;
        const cy = box.height / 2;
        svg.transition().duration(Util.reducedMotion() ? 0 : 300)
            .call(zoom.transform, d3.zoomIdentity.translate(cx - node.x * current.k, cy - node.y * current.k).scale(current.k));
    };
    fit();
    return fit;
}

function avTime(timestamp) {
    return new Date(timestamp * 1000).toLocaleTimeString("en-US", { hour12: false });
}

function avParamText(params) {
    const parts = Object.entries(params || {}).map(([key, value]) => `${key}=${value}`);
    return parts.join(" ");
}

window.initAttackVector = function() {
    const view = document.querySelector(".av-view");
    if (!view || view.dataset.initialized) return;
    view.dataset.initialized = "true";
    const engine = view.querySelector(".av-engine");
    const packagesPane = view.querySelector(".av-pane-packages");
    const historyPane = view.querySelector(".av-pane-history");
    const empty = view.querySelector(".av-empty");
    const subtitle = view.querySelector(".av-engine-sub");
    const foot = view.querySelector(".av-engine-foot");
    const footText = view.querySelector(".av-foot-text");
    const filterWrap = view.querySelector(".av-filter");
    const filterInput = view.querySelector(".av-filter-input");
    const orphanSwitch = view.querySelector('[data-filter="orphaned"]');
    const orphanCount = view.querySelector("[data-orphan-count]");
    const allRightsSwitch = view.querySelector('[data-filter="all-rights"]');
    const limitedCount = view.querySelector("[data-limited-count]");
    const maxEdgesField = view.querySelector("[data-max-edges-field]");
    const maxEdgesInput = view.querySelector('[data-filter="max-edges"]');
    const filterBadge = view.querySelector("[data-filter-badge]");
    const filterSection = view.querySelector(".av-fsec");
    const filters = { orphaned: false, showAll: false, maxEdges: AV_DEFAULT_MAX_RIGHT_EDGES };
    let lastGraph = null;
    let lastMeta = null;
    let currentParams = {};
    let fit = null;
    let catalog = [];
    let token = 0;
    let currentQuery = null;

    const setStatus = (state, text) => {
        foot.dataset.state = state;
        footText.textContent = text;
        footText.title = text;
    };
    const setCount = (name, value) => {
        const badge = view.querySelector(`[data-count="${name}"]`);
        if (badge) badge.textContent = value ? String(value) : "";
    };
    const markCurrent = () => {
        packagesPane.querySelectorAll(".av-query").forEach(node => node.classList.toggle("is-current", node.dataset.id === currentQuery));
    };
    const setBusy = (queryId, busy) => {
        packagesPane.querySelectorAll(".av-run").forEach(button => {
            const owner = button.closest(".av-query");
            const active = busy && owner && owner.dataset.id === queryId;
            button.classList.toggle("is-loading", !!active);
            button.disabled = !!active;
        });
    };

    const refreshStatus = filtered => {
        if (!lastMeta) return;
        const hidden = filtered.hidden ? ` · ${filtered.hidden} orphaned hidden` : "";
        const limited = lastMeta.limited ? ` · ${lastMeta.limited} edges over the ${lastMeta.maxEdges} per node limit hidden` : "";
        setStatus("ok", `${lastMeta.name} · ${filtered.nodes.length} nodes · ${filtered.edges.length} edges · ${lastMeta.elapsed} ms${hidden}${limited}`);
    };

    const refreshFilterUi = () => {
        const total = lastGraph ? lastGraph.nodes.filter(node => node.orphaned).length : 0;
        orphanCount.hidden = !total;
        orphanCount.textContent = filters.orphaned ? `${total} shown` : `${total} hidden`;
        const limited = lastMeta && !filters.showAll ? lastMeta.limited : 0;
        limitedCount.hidden = !limited;
        limitedCount.textContent = `${limited} hidden`;
        const active = (filters.orphaned ? 1 : 0)
            + (filters.showAll ? 1 : 0)
            + (!filters.showAll && filters.maxEdges !== AV_DEFAULT_MAX_RIGHT_EDGES ? 1 : 0);
        filterBadge.hidden = !active;
        filterBadge.textContent = String(active);
    };

    const queryOptions = () => ({
        show_all_rights: filters.showAll,
        max_right_edges: filters.maxEdges
    });

    const redraw = () => {
        const filtered = avApplyFilters(lastGraph, filters);
        fit = avRender(view, filtered);
        if (!filtered.nodes.length && lastGraph.nodes.length) {
            empty.textContent = "Only orphaned SIDs found. Enable Show Orphaned SID to display them";
        }
        refreshFilterUi();
        refreshStatus(filtered);
    };

    const show = graph => {
        lastGraph = graph;
        empty.textContent = "No attack paths found";
        redraw();
    };

    const fail = message => {
        empty.textContent = message;
        empty.hidden = false;
    };

    const renderHistory = async () => {
        try {
            const result = await Api.getAttackHistory();
            if (!result.ok) throw new Error(result.error || "Request failed");
            const entries = result.entries || [];
            setCount("history", entries.length);
            if (!entries.length) {
                historyPane.innerHTML = '<div class="av-note av-note-empty"><b>No requests yet</b><span>Queries you run will be listed here so you can replay them.</span></div>';
                return;
            }
            historyPane.innerHTML = `
                <div class="av-history-bar">
                    <span>${entries.length} ${entries.length === 1 ? "request" : "requests"}</span>
                    <button class="av-history-clear" type="button">Clear all</button>
                </div>` + entries.map(entry => {
                const params = avParamText(entry.params);
                const detail = entry.error
                    ? `<span class="av-history-error">${Util.esc(entry.error)}</span>`
                    : `<span class="av-chip">${entry.nodes} nodes</span><span class="av-chip">${entry.edges} edges</span><span class="av-chip">${entry.elapsed_ms} ms</span>`;
                return `
                <button class="av-history-item${entry.error ? " is-error" : ""}" type="button" data-id="${entry.id}">
                    <span class="av-history-status" aria-hidden="true"></span>
                    <span class="av-history-main">
                        <span class="av-history-top">
                            <span class="av-history-name">${Util.esc(entry.name)}</span>
                            <span class="av-history-time">${Util.esc(avTime(entry.timestamp))}</span>
                        </span>
                        ${params ? `<span class="av-history-params">${Util.esc(params)}</span>` : ""}
                        <span class="av-history-chips">${detail}</span>
                    </span>
                </button>`;
            }).join("");
            historyPane.querySelector(".av-history-clear").addEventListener("click", async () => {
                await Api.clearAttackHistory();
                renderHistory();
            });
            historyPane.querySelectorAll(".av-history-item").forEach(button => {
                const entry = entries.find(item => String(item.id) === button.dataset.id);
                button.addEventListener("click", () => run(entry.query_id, entry.params));
            });
        } catch (error) {
            historyPane.innerHTML = `<div class="av-note is-error">${Util.esc(error.message)}</div>`;
        }
    };

    const run = async (queryId, params = {}, silent = false) => {
        const current = ++token;
        currentQuery = queryId;
        currentParams = params;
        markCurrent();
        setBusy(queryId, true);
        setStatus("running", "Running query…");
        try {
            const result = await Api.runAttackQuery(queryId, params, silent, queryOptions());
            if (current !== token) return;
            if (!result.ok) throw new Error(result.error || "Request failed");
            const limits = result.limits || {};
            lastMeta = {
                name: (result.query && result.query.name) || queryId,
                elapsed: result.query ? result.query.elapsed_ms : 0,
                limited: limits.show_all_rights ? 0 : (limits.limited_edges || 0),
                maxEdges: limits.max_right_edges || filters.maxEdges
            };
            show(result);
        } catch (error) {
            if (current !== token) return;
            fail(error.message);
            setStatus("error", error.message);
        }
        setBusy(queryId, false);
        if (!silent) renderHistory();
    };

    const renderPackages = () => {
        packagesPane.innerHTML = catalog.map(pkg => `
            <section class="av-pkg">
                <button class="av-pkg-head" type="button" aria-expanded="true">
                    ${AV_ICON_CHEVRON}
                    <span class="av-pkg-name">${Util.esc(pkg.name)}</span>
                    <span class="av-pkg-count">${pkg.queries.length}</span>
                </button>
                <div class="av-pkg-list">
                ${pkg.queries.map(query => `
                    <div class="av-query" data-id="${Util.esc(query.id)}" data-search="${Util.esc((query.name + " " + query.description + " " + pkg.name).toLowerCase())}">
                        <button class="av-query-btn" type="button" aria-expanded="false">
                            <span class="av-query-name">${Util.esc(query.name)}</span>
                            ${query.params.length ? `<span class="av-query-tag">${query.params.length} ${query.params.length === 1 ? "input" : "inputs"}</span>` : ""}
                            ${AV_ICON_CHEVRON}
                        </button>
                        <form class="av-query-form">
                            <div class="av-query-inner">
                                <div class="av-query-desc">${Util.esc(query.description)}</div>
                                ${query.params.map(param => `
                                <label class="av-field"><span>${Util.esc(param.label)}</span>
                                <input name="${Util.esc(param.name)}" placeholder="${Util.esc(param.placeholder || "")}" autocomplete="off" spellcheck="false" ${param.required ? "required" : ""}></label>`).join("")}
                                <button class="av-run" type="submit">${AV_ICON_PLAY}<span>Run query</span></button>
                            </div>
                        </form>
                    </div>`).join("")}
                </div>
            </section>`).join("") + '<div class="av-note av-nomatch" hidden>No queries match your filter</div>';
        packagesPane.querySelectorAll(".av-pkg-head").forEach(head => {
            head.addEventListener("click", () => {
                const pkg = head.closest(".av-pkg");
                const collapsed = pkg.classList.toggle("is-collapsed");
                head.setAttribute("aria-expanded", String(!collapsed));
            });
        });
        packagesPane.querySelectorAll(".av-query").forEach(node => {
            const button = node.querySelector(".av-query-btn");
            button.addEventListener("click", () => {
                const open = node.classList.contains("is-open");
                packagesPane.querySelectorAll(".av-query.is-open").forEach(other => {
                    other.classList.remove("is-open");
                    other.querySelector(".av-query-btn").setAttribute("aria-expanded", "false");
                });
                node.classList.toggle("is-open", !open);
                button.setAttribute("aria-expanded", String(!open));
                if (!open) {
                    const input = node.querySelector("input");
                    setTimeout(() => {
                        node.scrollIntoView({ block: "nearest", behavior: Util.reducedMotion() ? "auto" : "smooth" });
                        if (input) input.focus({ preventScroll: true });
                    }, 220);
                }
            });
            node.querySelector("form").addEventListener("submit", event => {
                event.preventDefault();
                const params = {};
                new FormData(event.target).forEach((value, key) => {
                    params[key] = String(value);
                });
                run(node.dataset.id, params);
            });
        });
        markCurrent();
        applyFilter();
    };

    const applyFilter = () => {
        const term = filterInput.value.trim().toLowerCase();
        let shown = 0;
        packagesPane.querySelectorAll(".av-pkg").forEach(pkg => {
            let hits = 0;
            pkg.querySelectorAll(".av-query").forEach(node => {
                const hit = !term || node.dataset.search.includes(term);
                node.hidden = !hit;
                if (hit) hits += 1;
            });
            pkg.hidden = !hits;
            pkg.classList.toggle("is-filtering", !!term);
            shown += hits;
        });
        const none = packagesPane.querySelector(".av-nomatch");
        if (none) none.hidden = shown > 0;
    };

    orphanSwitch.addEventListener("change", () => {
        filters.orphaned = orphanSwitch.checked;
        if (lastGraph) redraw();
        else refreshFilterUi();
    });

    const rerun = () => {
        if (currentQuery) run(currentQuery, currentParams, true);
        else refreshFilterUi();
    };

    allRightsSwitch.addEventListener("change", () => {
        filters.showAll = allRightsSwitch.checked;
        maxEdgesInput.disabled = filters.showAll;
        maxEdgesField.classList.toggle("is-disabled", filters.showAll);
        refreshFilterUi();
        rerun();
    });

    maxEdgesInput.addEventListener("change", () => {
        const value = Number.parseInt(maxEdgesInput.value, 10);
        if (!Number.isFinite(value) || value < 1) {
            maxEdgesInput.value = String(filters.maxEdges);
            return;
        }
        const next = Math.min(value, AV_MAX_RIGHT_EDGES_CEILING);
        maxEdgesInput.value = String(next);
        if (next === filters.maxEdges) return;
        filters.maxEdges = next;
        refreshFilterUi();
        if (!filters.showAll) rerun();
    });

    filterSection.querySelector(".av-fsec-head").addEventListener("click", event => {
        const open = filterSection.classList.toggle("is-open");
        event.currentTarget.setAttribute("aria-expanded", String(open));
    });

    filterInput.addEventListener("input", applyFilter);
    filterInput.addEventListener("keydown", event => {
        if (event.key === "Escape" && filterInput.value) {
            filterInput.value = "";
            applyFilter();
            event.stopPropagation();
        }
    });

    view.querySelectorAll(".av-tab").forEach(tab => {
        tab.addEventListener("click", () => {
            view.querySelectorAll(".av-tab").forEach(other => other.classList.toggle("is-active", other === tab));
            const history = tab.dataset.tab === "history";
            packagesPane.hidden = history;
            historyPane.hidden = !history;
            filterWrap.hidden = history;
            if (history) renderHistory();
        });
    });

    const toggle = view.querySelector(".av-engine-toggle");
    toggle.addEventListener("click", () => {
        const collapsed = engine.classList.toggle("is-collapsed");
        toggle.setAttribute("aria-expanded", String(!collapsed));
        toggle.setAttribute("aria-label", collapsed ? "Expand Request Engine" : "Collapse Request Engine");
        if (fit) fit();
    });

    window.addEventListener("resize", () => fit && fit());

    Api.getAttackQueries().then(result => {
        if (!result.ok) throw new Error(result.error || "Request failed");
        catalog = result.packages;
        const total = catalog.reduce((sum, pkg) => sum + pkg.queries.length, 0);
        subtitle.textContent = `${total} queries · ${catalog.length} packages`;
        setCount("packages", total);
        renderPackages();
    }).catch(error => {
        subtitle.textContent = "Unavailable";
        packagesPane.innerHTML = `<div class="av-note is-error">${Util.esc(error.message)}</div>`;
    });

    renderHistory();
};