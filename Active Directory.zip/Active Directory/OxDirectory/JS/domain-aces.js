const ACE_KIND_META = {
    access: { label: "Access right", tone: "access" },
    extended: { label: "Extended right", tone: "extended" },
    unresolved: { label: "Unresolved right", tone: "unresolved" },
    object_class: { label: "Child object class", short: "Class", tone: "target" },
    property: { label: "Attribute / property set", short: "Property", tone: "target" }
};

const ACE_TARGET_KINDS = ["object_class", "property"];

const ACE_TYPE_NAMES = {
    0: "ACCESS_ALLOWED_ACE",
    1: "ACCESS_DENIED_ACE",
    5: "ACCESS_ALLOWED_OBJECT_ACE",
    6: "ACCESS_DENIED_OBJECT_ACE"
};

const ACE_FLAG_HINTS = [
    [0x1, "Object Inherit", "Passes to child leaf objects"],
    [0x2, "Container Inherit", "Passes to child containers"],
    [0x4, "No Propagate Inherit", "Stops after one level"],
    [0x8, "Inherit Only", "Does not apply to this object itself"],
    [0x10, "Inherited", "Copied down from a parent container"],
    [0x40, "Successful Access", "Audit successful access"],
    [0x80, "Failed Access", "Audit failed access"]
];

function aceKindOf(detail) {
    return detail && ACE_KIND_META[detail.kind] ? detail.kind : "access";
}

function aceRightsView(ace) {
    const details = Array.isArray(ace.rights_details) ? ace.rights_details : [];
    const source = details.length
        ? details
        : (Array.isArray(ace.rights) ? ace.rights : []).map(right => ({ right, kind: "access", guid: "" }));
    return {
        rights: source.filter(item => !ACE_TARGET_KINDS.includes(aceKindOf(item))),
        targets: source.filter(item => ACE_TARGET_KINDS.includes(aceKindOf(item)))
    };
}

function aceScopeSummary(value) {
    const flags = Number(value) || 0;
    const containers = (flags & 0x2) !== 0;
    const leaves = (flags & 0x1) !== 0;
    const childrenOnly = (flags & 0x8) !== 0;
    const oneLevel = (flags & 0x4) !== 0;
    let applies = "This object only";
    if (containers || leaves) {
        const kinds = containers && leaves ? "child containers and objects" : containers ? "child containers" : "child objects";
        applies = childrenOnly ? `Only ${kinds}, not the object itself` : `This object and ${kinds}`;
        if (oneLevel) applies += ", one level deep";
    }
    return {
        applies,
        source: (flags & 0x10) !== 0 ? "Inherited from a parent container" : "Set directly on this object"
    };
}

function acePrincipalInfo(sid) {
    const text = String(sid || "");
    const domain = /^S-1-5-21-\d+-\d+-\d+-(\d+)$/i.exec(text);
    if (domain) return { kind: "Domain account or group", rid: domain[1] };
    const builtin = /^S-1-5-32-(\d+)$/i.exec(text);
    if (builtin) return { kind: "Built-in group", rid: builtin[1] };
    return { kind: "Well-known or external SID", rid: "" };
}

SCHEMAS.aces = {
    columns: [
        {
            label: "Target",
            render: d => `<strong>${renderValue(d.target_name)}</strong><small class="domain-dn-trunc" title="${esc(d.target_dn || "")}">${renderValue(d.target_dn)}</small>`
        },
        {
            label: "Principal",
            render: d => {
                const principal = d.principal_name || d.principal_sid;
                return principal ? `<span class="domain-dn-trunc ace-principal" title="${esc(principal)}">${esc(principal)}</span>` : '<span class="domain-muted">-</span>';
            }
        },
        {
            label: "Rights",
            render: d => {
                const view = aceRightsView(d);
                const extra = Math.max((Number(d.ace_count) || 1) - 1, 0);
                const main = view.rights.length ? rightsChip(view.rights.map(item => item.right)) : '<span class="domain-muted">Not exported</span>';
                const targets = view.targets.length
                    ? `<small class="ace-object-line">${view.targets.map(item => `${esc(ACE_KIND_META[aceKindOf(item)].short)}: ${esc(item.right)}`).join(", ")}</small>`
                    : "";
                return `${main}${targets}${extra ? `<small>+${fmtNumber(extra)} more ${extra === 1 ? "ACE" : "ACEs"}</small>` : ""}`;
            }
        },
        {
            label: "Flags",
            render: d => {
                const flags = [];
                if (d.rights_category) flags.push(badge(d.rights_category, d.rights_category === "Unknown" ? "warn" : "medium"));
                if (d.medium_rights) flags.push(badge("Medium Rights", "medium"));
                if (d.extended_rights) flags.push(badge("Extended Rights", "info"));
                return flags.length ? `<div class="domain-flag-list">${flags.join("")}</div>` : '<span class="domain-muted">Empty</span>';
            }
        }
    ],
    rowClass: d => {
        if (d.dangerous_ace && !d.is_deny) return "dangerous";
        if (d.medium_rights && !d.is_deny) return "medium-rights";
        return "";
    },
    clickable: true
};

const ACES_MODULE_FILTER_CONFIG = {
    serverSide: true,
    multiPreset: true,
    hideBarReset: true,
    multiTextFields: ["target_name", "target_dn", "target_type", "target_sid", "principal_name", "principal_sid"],
    subtitle: "Narrow down ACEs by any attribute or flag",
    presets: [
        { id: "dangerous", label: "Dangerous ACEs", apply: s => { s.tri.dangerous_ace = "yes"; } },
        { id: "suspicious", label: "Suspicious ACEs", apply: s => { s.tri.suspicious_ace = "yes"; } },
        { id: "default-high", label: "Default high rights", apply: s => { s.tri.default_high_rights = "yes"; } },
        { id: "medium", label: "Medium rights", apply: s => { s.tri.medium_rights = "yes"; } },
        { id: "extended", label: "Extended rights", apply: s => { s.tri.extended_rights = "yes"; } },
        { id: "orphaned", label: "Orphaned SID", apply: s => { s.tri.orphaned_sid = "yes"; } },
        { id: "unknown", label: "Unknown ACEs", apply: s => { s.tri.unknown_ace = "yes"; } },
        { id: "deny", label: "Deny ACEs", apply: s => { s.tri.is_deny = "yes"; } }
    ],
    textFields: [
        { key: "target_name", label: "Target Name", get: a => a.target_name },
        { key: "target_dn", label: "Target DN", get: a => a.target_dn },
        { key: "target_type", label: "Target Type", get: a => a.target_type },
        { key: "target_sid", label: "Target SID", get: a => a.target_sid },
        { key: "principal_name", label: "Principal Name", get: a => a.principal_name },
        { key: "principal_sid", label: "Principal SID", get: a => a.principal_sid },
        { key: "principal_scope", label: "Principal Scope", get: a => a.principal_scope },
        { key: "rights", label: "Rights", get: a => rightsText(a.rights) },
        { key: "object_acetype", label: "Object ACE Type", get: a => a.object_acetype }
    ],
    triFields: [
        { key: "dangerous_ace", label: "Dangerous ACE", tone: "danger", get: a => !!a.dangerous_ace },
        { key: "suspicious_ace", label: "Suspicious ACE", tone: "danger", get: a => !!a.suspicious_ace },
        { key: "default_high_rights", label: "Default High Rights", tone: "danger", get: a => !!a.default_high_rights },
        { key: "medium_rights", label: "Medium Rights", tone: "medium", get: a => !!a.medium_rights },
        { key: "extended_rights", label: "Extended Rights", tone: "info", get: a => !!a.extended_rights },
        { key: "orphaned_sid", label: "Orphaned SID", tone: "warn", get: a => ufHasText(a.principal_name) && ufHasText(a.target_name) },
        { key: "unknown_ace", label: "Unknown ACE", tone: "warn", get: a => /^(UNRESOLVED-Custom-GUID|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i.test(String(a.object_acetype || "")) },
        { key: "categories_of_rights", label: "Categories of Rights", tone: "medium", get: a => false },
        { key: "is_deny", label: "Deny ACE", tone: "warn", get: a => !!a.is_deny },
        { key: "inherited", label: "Inherited", tone: "info", get: a => (Number(a.ace_flags) & 0x10) === 0x10 },
        { key: "has_target_dn", label: "Has Target DN", tone: "info", get: a => ufHasText(a.target_dn) },
        { key: "has_principal_name", label: "Has Principal Name", tone: "info", get: a => ufHasText(a.principal_name) }
    ],
    dateFields: [],
    numFields: [
        { key: "ace_count", label: "ACE Count", get: a => ufNum(a.ace_count) },
        { key: "ace_type_raw", label: "ACE Type Code", get: a => ufNum(a.ace_type_raw) },
        { key: "ace_flags", label: "ACE Flags Value", get: a => ufNum(a.ace_flags) }
    ],
    sortFields: [
        { key: "target_name", label: "Target Name", type: "text", get: a => String(a.target_name || "").toLowerCase() },
        { key: "principal_name", label: "Principal Name", type: "text", get: a => String(a.principal_name || a.principal_sid || "").toLowerCase() },
        { key: "ace_count", label: "ACE Count", type: "num", get: a => ufNum(a.ace_count) }
    ],
    tabs: [
        { key: "identity", label: "Identity", icon: "user" },
        { key: "security", label: "Security", icon: "shield" }
    ],
    layout: {
        identity: [
            { title: "Target", kind: "text", keys: ["target_name", "target_dn", "target_type", "target_sid"] },
            { title: "Principal", kind: "text", keys: ["principal_name", "principal_sid", "principal_scope"] }
        ],
        security: [
            { title: "Rights", kind: "text", keys: ["rights", "object_acetype"] },
            { title: "Categories of Rights", kind: "tri", keys: ["categories_of_rights", "unknown_ace"] },
            { title: "ACE Flags", kind: "tri", keys: ["dangerous_ace", "suspicious_ace", "default_high_rights", "medium_rights", "extended_rights", "is_deny", "inherited"] },
            { title: "Counters", kind: "num", keys: ["ace_count", "ace_type_raw", "ace_flags"] }
        ]
    },
    knownKeys: ["target_name", "target_dn", "target_type", "target_sid", "principal_name", "principal_sid", "principal_scope", "rights", "rights_details", "ace_count", "ace_type_raw", "object_acetype", "object_guid", "ace_flags", "dangerous_ace", "medium_rights", "suspicious_ace", "default_high_rights", "extended_rights", "is_deny", "aces"]
};

FULL_FILTER_CONFIGS.aces = ACES_MODULE_FILTER_CONFIG;

function aceFlagLabels(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) return [];
    const names = [
        [0x1, "Object Inherit"], [0x2, "Container Inherit"], [0x4, "No Propagate Inherit"],
        [0x8, "Inherit Only"], [0x10, "Inherited"], [0x40, "Successful Access"], [0x80, "Failed Access"]
    ];
    return names.filter(([bit]) => (number & bit) === bit).map(([, name]) => name);
}

function aceTypeLabel(ace) {
    const raw = Number(ace.ace_type_raw);
    const isDeny = raw === 1 || raw === 6;
    const isObject = raw === 5 || raw === 6;
    return `${isDeny ? "Deny" : "Allow"}${isObject ? " (Object)" : ""}`;
}

function aceChips(items, className) {
    return `<div class="ace-chips">${items.map(item => `<span class="ace-chip ${className(item)}" title="${esc(item.title || "")}">${esc(item.text)}</span>`).join("")}</div>`;
}

function aceRowHtml(label, html) {
    return `<div class="ace-row"><span class="ace-row-label">${esc(label)}</span><div class="ace-row-value">${html}</div></div>`;
}

function aceCardHtml(ace, index) {
    const view = aceRightsView(ace);
    const deny = !!ace.is_deny;
    const scope = aceScopeSummary(ace.ace_flags);
    const flagItems = ACE_FLAG_HINTS.filter(([bit]) => (Number(ace.ace_flags) & bit) === bit).map(([, name, hint]) => ({ text: name, title: hint }));
    const guid = ace.object_guid || [...view.rights, ...view.targets].map(item => item.guid).find(Boolean) || "";
    const raw = Number(ace.ace_type_raw);
    const marks = [];
    if (ace.dangerous_ace) marks.push(badge("Dangerous", "danger"));
    if (ace.extended_rights) marks.push(badge("Extended", "info"));
    if (ace.medium_rights) marks.push(badge("Medium", "medium"));
    if (ace.suspicious_ace) marks.push(badge("Suspicious", "danger"));
    if (ace.default_high_rights) marks.push(badge("Default High", "danger"));
    const rightsHtml = view.rights.length
        ? aceChips(
            view.rights.map(item => ({ text: item.right, title: ACE_KIND_META[aceKindOf(item)].label, kind: aceKindOf(item) })),
            item => `ace-chip-${ACE_KIND_META[item.kind].tone}`
        )
        : '<span class="ace-note">Not recorded by the collector. This entry only names the object it applies to, so the read or write access mask is unknown.</span>';
    const targetHtml = view.targets.length
        ? view.targets.map(item => `
            <div class="ace-target">
                <span class="ace-chip ace-chip-target">${esc(ACE_KIND_META[aceKindOf(item)].label)}</span>
                <strong>${esc(item.right)}</strong>
            </div>`).join("")
        : '<span class="ace-note">The whole object</span>';
    return `
        <article class="ace-card ${deny ? "is-deny" : "is-allow"}">
            <header class="ace-card-head">
                <span class="ace-index">#${index + 1}</span>
                <span class="ace-verdict ${deny ? "is-deny" : "is-allow"}">${deny ? "Deny" : "Allow"}</span>
                ${marks.join("")}
            </header>
            <div class="ace-card-body">
                ${aceRowHtml("Access rights", rightsHtml)}
                ${aceRowHtml("Applies to", targetHtml)}
                ${guid ? aceRowHtml("Object GUID", `<code class="ace-code">${esc(guid)}</code>`) : ""}
                ${aceRowHtml("Scope", `
                    <div class="ace-scope"><strong>${esc(scope.applies)}</strong><span>${esc(scope.source)}</span></div>
                    ${flagItems.length ? aceChips(flagItems, () => "ace-chip-flag") : '<span class="ace-note">No inheritance flags</span>'}`)}
                ${aceRowHtml("ACE type", `<span>${esc(Number.isFinite(raw) ? raw : "-")} &middot; ${esc(ACE_TYPE_NAMES[raw] || aceTypeLabel(ace))}</span>`)}
            </div>
        </article>`;
}

function openAceDetailPanel(record) {
    closeUserDetailPanel();
    const aces = Array.isArray(record.aces) && record.aces.length ? record.aces : [record];
    const primary = aces[0];
    const principalName = aces.map(ace => ace.principal_name).find(Boolean) || "";
    const principalSid = aces.map(ace => ace.principal_sid).find(Boolean) || "";
    const principal = acePrincipalInfo(principalSid);
    const denyCount = aces.filter(ace => ace.is_deny).length;
    const rightNames = new Set(aces.flatMap(ace => aceRightsView(ace).rights.map(item => item.right)));
    const dangerousCount = aces.filter(ace => ace.dangerous_ace).length;
    const overlay = document.createElement("div");
    overlay.className = "user-detail-overlay";
    overlay.innerHTML = `
        <aside class="user-detail-panel" role="dialog" aria-modal="true" aria-label="ACE details">
            <div class="user-detail-header">
                <div class="user-detail-avatar">${esc(initials(primary.target_name))}</div>
                <div class="user-detail-heading">
                    <h2>${esc(primary.target_name || "Unknown target")}</h2>
                    <span class="user-detail-dn">${esc(primary.target_dn || "")}</span>
                </div>
                <button class="user-detail-close" type="button" aria-label="Close">&times;</button>
            </div>
            <div class="user-detail-status-row">
                ${dangerousCount ? badge(`${dangerousCount} Dangerous`, "danger") : badge("Non-Dangerous", "muted")}
                ${aces.some(ace => ace.medium_rights) ? badge("Medium Rights", "medium") : ""}
                ${denyCount ? badge(`${denyCount} Deny`, "warn") : ""}
                ${badge(`${aces.length} ACE${aces.length === 1 ? "" : "s"}`, "info")}
            </div>
            <div class="user-detail-body">
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Principal</div>
                    <div class="ace-principal-name${principalName ? "" : " is-unresolved"}">${esc(principalName || "Name not resolved")}</div>
                    <code class="ace-code">${esc(principalSid || "-")}</code>
                    <div class="user-detail-grid ace-principal-grid">
                        <div class="user-detail-kv"><span>Kind</span><strong>${esc(principal.kind)}</strong></div>
                        <div class="user-detail-kv"><span>Scope</span><strong>${esc(primary.principal_scope || "-")}</strong></div>
                        ${principal.rid ? `<div class="user-detail-kv"><span>RID</span><strong>${esc(principal.rid)}</strong></div>` : ""}
                    </div>
                </section>
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Overview</div>
                    <div class="user-detail-grid">
                        <div class="user-detail-kv"><span>Target type</span><strong>${esc(primary.target_type || "-")}</strong></div>
                        <div class="user-detail-kv"><span>Target SID</span><strong>${esc(primary.target_sid || "-")}</strong></div>
                        <div class="user-detail-kv"><span>Allow / Deny</span><strong>${aces.length - denyCount} / ${denyCount}</strong></div>
                        <div class="user-detail-kv"><span>Distinct rights</span><strong>${rightNames.size}</strong></div>
                    </div>
                </section>
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Access control entries (${aces.length})</div>
                    <div class="ace-list">${aces.map(aceCardHtml).join("")}</div>
                </section>
            </div>
        </aside>`;
    overlay.addEventListener("mousedown", event => {
        if (event.target === overlay) closeUserDetailPanel();
    });
    overlay.querySelector(".user-detail-close").addEventListener("click", closeUserDetailPanel);
    document.body.appendChild(overlay);
    document.addEventListener("keydown", handleUserDetailKeydown);
}

(function initAcesViewAnimations() {
    function pulseCount(root) {
        const el = root.querySelector(".domain-count");
        if (!el) return;
        const current = el.textContent;
        if (el.dataset.acLast === current) return;
        el.dataset.acLast = current;
        el.classList.remove("ac-count-pulse");
        void el.offsetWidth;
        el.classList.add("ac-count-pulse");
    }

    function staggerRows(root) {
        const rows = root.querySelectorAll(".domain-table-body tr");
        rows.forEach((row, index) => {
            row.style.setProperty("--row-index", String(Math.min(index, 24)));
            row.classList.add("ac-row-in");
        });
    }

    function markFilterReady(root) {
        const filter = root.querySelector(".user-filter");
        if (filter) filter.classList.add("ac-filter-ready");
    }

    function enhance(root) {
        pulseCount(root);
        staggerRows(root);
        markFilterReady(root);
    }

    function attach(root) {
        if (root.dataset.acWatching) return;
        root.dataset.acWatching = "1";
        enhance(root);
        loadStats(root);
        const body = root.querySelector(".domain-table-body");
        const count = root.querySelector(".domain-count");
        [body, count].filter(Boolean).forEach(target => {
            new MutationObserver(() => enhance(root)).observe(target, { childList: true, characterData: true, subtree: true });
        });
    }

    const STAT_ICONS = {
        alert: '<path d="M12 3l10 18H2L12 3z"/><path d="M12 10v5M12 18v.01"/>',
        key: '<circle cx="8" cy="15" r="4"/><path d="M10.5 12.5L20 3M16 7l3 3M19 4l3 3"/>',
        lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
        arrow: '<path d="M4 12h14M13 6l6 6-6 6"/>',
        target: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r=".8"/>',
        nested: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z"/><path d="M9 12l2 2 4-4"/>'
    };

    const STAT_CARDS = [
        { label: "Dangerous ACEs", tone: "red", icon: "alert", summaryKeys: ["dangerous_ace_count", "dangerous_count"] },
        { label: "Extended Rights", tone: "blue", icon: "key", summaryKeys: ["extended_rights_count"] },
        { label: "Orphaned ACEs", tone: "purple", icon: "target", summaryKeys: ["orphaned_sid_count"] },
        { label: "Suspicious ACEs", tone: "orange", icon: "lock", summaryKeys: ["suspicious_ace_count"] },
        { label: "Default High Rights", tone: "pink", icon: "arrow", summaryKeys: ["default_high_rights_count"] },
        { label: "Medium Severity", tone: "yellow", icon: "nested", summaryKeys: ["medium_rights_count"] }
    ];

    function fmtInt(value) {
        return Number(value).toLocaleString("en-US");
    }

    function fmtPct(count, total) {
        if (!total) return "0%";
        const pct = count / total * 100;
        if (count > 0 && pct < 0.1) return "<0.1%";
        return (pct < 10 ? pct.toFixed(1) : Math.round(pct)) + "%";
    }

    function countUp(el, target) {
        const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        if (reduce || target < 2) {
            el.textContent = fmtInt(target);
            return;
        }
        const start = performance.now();
        const duration = 800;
        function tick(now) {
            const progress = Math.min(1, (now - start) / duration);
            const eased = 1 - Math.pow(1 - progress, 3);
            el.textContent = fmtInt(Math.round(target * eased));
            if (progress < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
    }

    function skeletonHtml() {
        return STAT_CARDS.map(() => '<div class="ac-stat ac-skel"><span></span><span></span><span></span></div>').join("");
    }

    async function fetchAllAces() {
        const size = (typeof DOMAIN_PAGE_SIZES !== "undefined" && DOMAIN_PAGE_SIZES.aces) || 500;
        const result = await Api.getDomainAcesSummary();
        if (!result || !result.ok) throw new Error(result && result.error || "Unable to load ACE summary");
        return result.summary && typeof result.summary === "object" ? result.summary : null;
    }

    function renderSplit(root, summary) {
        const el = root.querySelector(".ac-split");
        if (!el) return;
        const total = Number(summary && summary.total_aces) || 0;
        const deny = Number(summary && (summary.is_deny_count || summary.deny_count)) || 0;
        const allow = Math.max(total - deny, 0);
        const dangerous = Number(summary && (summary.dangerous_ace_count || summary.dangerous_count)) || 0;
        const medium = Number(summary && summary.medium_rights_count) || 0;
        const allowPct = total ? allow / total * 100 : 0;
        el.innerHTML = `
            <div class="ac-split-bar"><span style="--w:${allowPct.toFixed(2)}%"></span></div>
            <div class="ac-split-legend">
                <span class="ac-leg ac-leg-ok"><i></i>Allow <strong>${fmtInt(allow)}</strong></span>
                <span class="ac-leg ac-leg-off"><i></i>Deny <strong>${fmtInt(deny)}</strong></span>
                <span class="ac-leg ac-leg-red"><i></i>Dangerous <strong>${fmtInt(dangerous)}</strong></span>
                <span class="ac-leg ac-leg-yellow"><i></i>Medium <strong>${fmtInt(medium)}</strong></span>
            </div>`;
        requestAnimationFrame(() => el.classList.add("ac-in"));
    }

    function renderStats(root, summary) {
        const el = root.querySelector(".ac-stats");
        if (!el) return;
        const total = Number(summary && summary.total_aces) || 0;
        el.innerHTML = STAT_CARDS.map((card, index) => {
            const metaCount = summary && card.summaryKeys
                ? Number(card.summaryKeys.map(key => summary[key]).find(value => value !== undefined))
                : NaN;
            const count = Number.isFinite(metaCount) ? metaCount : 0;
            const pct = total ? count / total * 100 : 0;
            return `
            <div class="ac-stat ac-tone-${card.tone}${count === 0 ? " ac-zero" : ""}" style="--i:${index};--pct:${Math.min(100, pct).toFixed(2)}%">
                <div class="ac-stat-head">
                    <span class="ac-stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${STAT_ICONS[card.icon]}</svg></span>
                    <span class="ac-stat-label">${card.label}</span>
                </div>
                <div class="ac-stat-value" data-target="${count}">0</div>
                <div class="ac-stat-foot"><span>${fmtPct(count, total)} of ACEs</span></div>
                <div class="ac-stat-bar"><span></span></div>
            </div>`;
        }).join("");
        requestAnimationFrame(() => {
            el.classList.add("ac-in");
            el.querySelectorAll(".ac-stat-value").forEach(v => countUp(v, Number(v.dataset.target) || 0));
        });
    }

    async function loadStats(root) {
        const el = root.querySelector(".ac-stats");
        if (!el) return;
        if (typeof Api === "undefined" || typeof Api.getDomainResults !== "function") {
            el.remove();
            return;
        }
        el.innerHTML = skeletonHtml();
        try {
            const summary = await fetchAllAces();
            if (!summary) {
                el.remove();
                return;
            }
            renderSplit(root, summary);
            renderStats(root, summary);
        } catch (error) {
            el.remove();
        }
    }

    function findRoot() {
        return document.querySelector('.domain-result-view[data-domain-kind="aces"]');
    }

    const existing = findRoot();
    if (existing) {
        attach(existing);
    } else {
        const bodyObserver = new MutationObserver(() => {
            const root = findRoot();
            if (root) {
                attach(root);
                bodyObserver.disconnect();
            }
        });
        bodyObserver.observe(document.body, { childList: true, subtree: true });
    }
})();