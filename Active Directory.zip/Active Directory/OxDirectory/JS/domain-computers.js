SCHEMAS.computers = {
    columns: [
        {
            label: "Computer",
            render: d => `<strong>${esc(d.computer_name || "Unknown")}</strong><small>${esc(d.dns_name || "Empty")}</small>`
        },
        { label: "Operating System", render: d => esc(d.os || "Unknown") },
        {
            label: "IP Address",
            render: d => {
                const addresses = [].concat(d.ipv4_addresses || d.ip_address || []).filter(Boolean);
                return addresses.length ? esc(addresses.join(", ")) : '<span class="domain-muted">-</span>';
            }
        },
        {
            label: "Role",
            render: d => d.is_domain_controller ? badge("Domain Controller", "admin-potential")
                : d.is_server ? badge("Server", "muted")
                    : d.is_workstation ? badge("Workstation", "muted")
                        : badge("Unknown", "muted")
        }
    ],
    rowClass: d => d.is_domain_controller ? "user-admin-high"
        : (d.unconstrained_delegation || d.rbcd_enabled) ? "flagged" : "",
    clickable: true
};

const COMPUTERS_FILTER_CONFIG = {
    subtitle: "Narrow down computers by any attribute, flag, date or counter",
    presets: [],
    textFields: [
        { key: "computer_name", label: "Computer Name", placeholder: "e.g. SRV-01", get: c => c.computer_name },
        { key: "dns_name", label: "DNS Name", placeholder: "e.g. srv-01.corp.local", get: c => c.dns_name },
        { key: "display_name", label: "Display Name", placeholder: "e.g. SRV-01$", get: c => c.display_name },
        { key: "sid", label: "SID", placeholder: "e.g. S-1-5-21", get: c => c.sid },
        { key: "os", label: "Operating System", placeholder: "e.g. Windows Server 2022", get: c => c.os },
        { key: "os_version", label: "OS Version", placeholder: "e.g. 10.0.20348", get: c => c.os_version },
        { key: "os_service_pack", label: "Service Pack", placeholder: "e.g. SP1", get: c => c.os_service_pack },
        { key: "location", label: "Location", placeholder: "e.g. Datacenter 1", get: c => c.location },
        { key: "domain_name", label: "Domain", placeholder: "e.g. corp.local", get: c => c.domain_name },
        { key: "domainsid", label: "Domain SID", placeholder: "e.g. S-1-5-21", get: c => c.domainsid },
        { key: "description", label: "Description", placeholder: "e.g. file server", get: c => c.description },
        { key: "admin_description", label: "Admin Description", placeholder: "e.g. Tier-0 evidence", get: c => c.admin_description },
        { key: "admin_evidence", label: "Admin Evidence", placeholder: "e.g. nested membership", get: c => c.admin_evidence },
        { key: "smb_version", label: "SMB Version", placeholder: "e.g. 3.1.1", get: c => c.smb_version }
    ],
    triFields: [
        { key: "enabled", label: "Account Enabled", tone: "ok", get: c => !c.disabled },
        { key: "is_domain_controller", label: "Domain Controller", tone: "danger", get: c => !!c.is_domain_controller },
        { key: "is_server", label: "Server", tone: "info", get: c => !!c.is_server },
        { key: "is_workstation", label: "Workstation", tone: "info", get: c => !!c.is_workstation },
        { key: "is_stale", label: "Stale", tone: "warn", get: c => !!c.is_stale },
        { key: "smb_port_open", label: "SMB Port Open", tone: "info", get: c => !!c.smb_port_open },
        { key: "smb_signing_required", label: "SMB Signing Required", tone: "ok", get: c => !!c.smb_signing_required },
        { key: "has_laps", label: "LAPS", tone: "ok", get: c => !!c.has_laps || !!c.haslaps },
        { key: "absolute_admin", label: "Absolute Admin", tone: "danger", get: c => !!c.absolute_admin },
        { key: "nested_admin", label: "Nested Admin", tone: "danger", get: c => !!c.nested_admin },
        { key: "potential_admin", label: "Potential Admin", tone: "warn", get: c => !!c.potential_admin },
        { key: "potential_privileged", label: "Potential Privileged", tone: "warn", get: c => !!c.potential_privileged },
        { key: "unconstrained_delegation", label: "Unconstrained Delegation", tone: "danger", get: c => !!c.unconstrained_delegation },
        { key: "constrained_delegation", label: "Constrained Delegation", tone: "warn", get: c => !!c.constrained_delegation },
        { key: "protocol_transition_delegation", label: "Protocol Transition", tone: "warn", get: c => !!c.protocol_transition_delegation },
        { key: "trusted_for_delegation", label: "Trusted For Delegation", tone: "warn", get: c => !!c.trusted_for_delegation },
        { key: "rbcd_enabled", label: "RBCD Enabled", tone: "danger", get: c => !!c.rbcd_enabled },
        { key: "kerberoastable", label: "Kerberoastable", tone: "info", get: c => !!c.kerberoastable },
        { key: "asrep", label: "AS-REP Roastable", tone: "info", get: c => !!c.asrep },
        { key: "has_shadow_credential", label: "Shadow Credential", tone: "danger", get: c => !!c.has_shadow_credential },
        { key: "has_spn", label: "Has SPN", tone: "info", get: c => !!c.has_spn },
        { key: "isaclprotected", label: "ACL Protected", tone: "info", get: c => !!c.isaclprotected }
    ],
    dateFields: [
        { key: "when_created", label: "Created", get: c => ufTime(c.when_created) },
        { key: "when_changed", label: "Last Changed", get: c => ufTime(c.when_changed) },
        { key: "last_logon", label: "Last Logon", get: c => ufTime(c.last_logon) },
        { key: "pwd_last_set", label: "Password Last Set", get: c => ufTime(c.pwd_last_set) },
        { key: "laps_expiration", label: "LAPS Expiration", get: c => ufTime(c.laps_expiration) }
    ],
    numFields: [
        { key: "risk_score", label: "Risk Score", get: c => ufNum(c.risk_score) },
        { key: "primary_group_id", label: "Primary Group ID", get: c => ufNum(c.primary_group_id) }
    ],
    sortFields: [
        { key: "computer_name", label: "Computer Name", type: "text", get: c => String(c.computer_name || "").toLowerCase() },
        { key: "os", label: "Operating System", type: "text", get: c => String(c.os || "").toLowerCase() },
        { key: "last_logon", label: "Last Logon", type: "num", get: c => ufTime(c.last_logon) },
        { key: "risk_score", label: "Risk Score", type: "num", get: c => { const n = ufNum(c.risk_score); return Number.isFinite(n) ? n : null; } },
        { key: "when_created", label: "Created", type: "num", get: c => ufTime(c.when_created) }
    ],
    tabs: [
        { key: "identity", label: "Identity", icon: "user" },
        { key: "status", label: "Account", icon: "status" },
        { key: "security", label: "Security", icon: "shield" },
        { key: "activity", label: "Activity", icon: "clock" }
    ],
    layout: {
        identity: [
            { title: "Computer Names", kind: "text", keys: ["computer_name", "dns_name", "display_name"] },
            { title: "Location & Domain", kind: "text", keys: ["location", "domain_name", "domainsid"] },
            { title: "Operating System", kind: "text", keys: ["os", "os_version", "os_service_pack"] },
            { title: "Identifiers & Description", kind: "text", keys: ["sid", "smb_version", "description", "admin_description", "admin_evidence"] }
        ],
        status: [
            { title: "Role", kind: "tri", keys: ["enabled", "is_domain_controller", "is_server", "is_workstation"] },
            { title: "Health & SMB", kind: "tri", keys: ["is_stale", "smb_port_open", "smb_signing_required", "has_laps"] }
        ],
        security: [
            { title: "Administrative Rights", kind: "tri", keys: ["absolute_admin", "nested_admin", "potential_admin", "potential_privileged"] },
            { title: "Delegation", kind: "tri", keys: ["unconstrained_delegation", "constrained_delegation", "protocol_transition_delegation", "trusted_for_delegation", "rbcd_enabled"] },
            { title: "Exposure", kind: "tri", keys: ["kerberoastable", "asrep", "has_shadow_credential", "has_spn", "isaclprotected"] }
        ],
        activity: [
            { title: "Timeline", kind: "date", keys: ["when_created", "when_changed", "last_logon", "pwd_last_set", "laps_expiration"] },
            { title: "Counters", kind: "num", keys: ["risk_score", "primary_group_id"] }
        ]
    },
    knownKeys: [
        "computer_name", "dns_name", "display_name", "sid", "os", "os_version", "os_service_pack", "location",
        "domain_name", "domainsid", "description", "admin_description", "admin_evidence", "smb_version",
        "risk_score", "primary_group_id", "when_created", "when_changed", "last_logon", "pwd_last_set",
        "laps_expiration", "disabled", "is_domain_controller", "is_server", "is_workstation", "is_stale",
        "smb_port_open", "smb_signing_required", "has_laps", "haslaps", "absolute_admin", "nested_admin",
        "potential_admin", "potential_privileged", "unconstrained_delegation", "constrained_delegation",
        "protocol_transition_delegation", "trusted_for_delegation", "rbcd_enabled", "kerberoastable", "asrep",
        "has_shadow_credential", "has_spn", "isaclprotected", "ipv4_addresses", "ipv6_addresses"
    ]
};

FULL_FILTER_CONFIGS.computers = COMPUTERS_FILTER_CONFIG;

function openComputerDetailPanel(computer) {
    closeUserDetailPanel();
    const disabled = !!computer.disabled;
    const isDc = !!computer.is_domain_controller;
    const highAdmin = !!computer.absolute_admin || !!computer.nested_admin;
    const role = isDc ? "Domain Controller" : computer.is_server ? "Server" : computer.is_workstation ? "Workstation" : "Unknown";
    const list = value => Array.isArray(value) ? value : [];
    const chipText = item => (item !== null && typeof item === "object") ? JSON.stringify(item) : String(item);
    const chips = (items, empty) => items.length
        ? items.map(item => `<span class="domain-chip">${esc(chipText(item))}</span>`).join("")
        : `<span class="domain-muted">${esc(empty)}</span>`;
    const kv = (label, html) => `<div class="user-detail-kv"><span>${esc(label)}</span><strong>${html}</strong></div>`;
    const text = value => (value === null || value === undefined || value === "") ? '<span class="domain-muted">-</span>' : esc(String(value));
    const overview = [
        ["Computer Name", text(computer.computer_name)],
        ["DNS Name", text(computer.dns_name)],
        ["Display Name", text(computer.display_name)],
        ["SID", text(computer.sid)],
        ["Role", text(role)],
        ["Operating System", text(computer.os)],
        ["OS Version", text(computer.os_version)],
        ["Service Pack", text(computer.os_service_pack)],
        ["Location", text(computer.location)],
        ["Primary Group ID", text(computer.primary_group_id)],
        ["Domain", text(computer.domain_name)],
        ["Domain SID", text(computer.domainsid)],
        ["IPv4 Addresses", text(list(computer.ipv4_addresses).join(", "))],
        ["IPv6 Addresses", text(list(computer.ipv6_addresses).join(", "))],
        ["SMB Version", text(computer.smb_version)],
        ["Risk Score", text(computer.risk_score)]
    ];
    const timeline = [
        ["Created", fmtDate(computer.when_created)],
        ["Changed", fmtDate(computer.when_changed)],
        ["Last Logon", fmtDate(computer.last_logon)],
        ["Password Last Set", fmtDate(computer.pwd_last_set)],
        ["LAPS Expiration", fmtDate(computer.laps_expiration)]
    ];
    const delegateTo = list(computer.allowed_to_delegate_to);
    const delegateStructured = list(computer.allowed_to_delegate_to_structured);
    const rbcdNames = list(computer.rbcd_principal_names);
    const rbcdSids = list(computer.rbcd_principals);
    const rbcd = rbcdNames.length ? rbcdNames : rbcdSids;
    const overlay = document.createElement("div");
    overlay.className = "user-detail-overlay";
    overlay.innerHTML = `
        <aside class="user-detail-panel" role="dialog" aria-modal="true" aria-label="Computer details">
            <div class="user-detail-header">
                <div class="user-detail-avatar${disabled ? " is-disabled" : ""}">${esc(initials(computer.computer_name || computer.display_name))}</div>
                <div class="user-detail-heading">
                    <h2>${esc(computer.computer_name || computer.display_name || "Unknown")}</h2>
                    <span class="user-detail-dn">${esc(computer.dn || "")}</span>
                </div>
                <button class="user-detail-close" type="button" aria-label="Close">&times;</button>
            </div>
            <div class="user-detail-status-row">
                ${disabled ? badge("Disabled", "muted") : badge("Enabled", "ok")}
                ${isDc ? badge("Domain Controller", "admin-potential") : badge(role, "muted")}
                ${highAdmin ? badge("Tier-0 Admin", "admin-high") : ""}
                ${!highAdmin && computer.potential_admin ? badge("Potential Admin", "admin-potential") : ""}
                ${computer.is_stale ? badge("Stale", "muted") : ""}
            </div>
            <div class="user-detail-body">
                <section class="user-detail-section"><div class="user-detail-section-title">Computer Overview</div><div class="user-detail-grid">${overview.map(([label, html]) => kv(label, html)).join("")}</div></section>
                ${computer.description ? `<section class="user-detail-section"><div class="user-detail-section-title">Description</div><p>${esc(computer.description)}</p></section>` : ""}
                ${computer.admin_description ? `<section class="user-detail-section user-admin-description"><div class="user-detail-section-title">Admin Description</div><p>${esc(computer.admin_description)}</p>${computer.admin_evidence ? `<div class="user-detail-evidence"><span>Evidence</span><strong>${esc(computer.admin_evidence)}</strong></div>` : ""}</section>` : ""}
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Security Flags</div>
                    <div class="domain-flag-list">
                        ${detailFlag("Absolute Admin", !!computer.absolute_admin)}
                        ${detailFlag("Nested Admin", !!computer.nested_admin)}
                        ${detailFlag("Potential Admin", !!computer.potential_admin, "warn")}
                        ${detailFlag("Potential Privileged", !!computer.potential_privileged, "warn")}
                        ${detailFlag("Unconstrained Delegation", !!computer.unconstrained_delegation)}
                        ${detailFlag("Constrained Delegation", !!computer.constrained_delegation, "warn")}
                        ${detailFlag("Protocol Transition", !!computer.protocol_transition_delegation, "warn")}
                        ${detailFlag("Trusted For Delegation", !!computer.trusted_for_delegation, "warn")}
                        ${detailFlag("RBCD Enabled", !!computer.rbcd_enabled)}
                        ${detailFlag("Kerberoastable", !!computer.kerberoastable, "info")}
                        ${detailFlag("AS-REP Roastable", !!computer.asrep, "info")}
                        ${detailFlag("Shadow Credential", !!computer.has_shadow_credential)}
                        ${detailFlag("Has SPN", !!computer.has_spn, "info")}
                        ${detailFlag("LAPS", !!computer.has_laps || !!computer.haslaps, "ok")}
                        ${detailFlag("ACL Protected", !!computer.isaclprotected, "info")}
                        ${detailFlag("Stale", !!computer.is_stale, "warn")}
                        ${detailFlag("SMB Port Open", !!computer.smb_port_open, "info")}
                        ${detailFlag("SMB Signing Required", !!computer.smb_signing_required, "ok")}
                    </div>
                </section>
                <section class="user-detail-section"><div class="user-detail-section-title">Timeline</div><div class="user-detail-grid">${timeline.map(([label, html]) => kv(label, html)).join("")}</div></section>
                <section class="user-detail-section"><div class="user-detail-section-title">Service Principal Names</div><div class="domain-chip-list">${chips(list(computer.spn), "No SPNs reported")}</div></section>
                <section class="user-detail-section"><div class="user-detail-section-title">Delegation Targets</div><div class="domain-chip-list">${chips(delegateStructured.length ? delegateStructured : delegateTo, "No delegation targets")}</div></section>
                <section class="user-detail-section"><div class="user-detail-section-title">RBCD Principals</div><div class="domain-chip-list">${chips(rbcd, "No RBCD principals")}</div></section>
                <section class="user-detail-section"><div class="user-detail-section-title">Risk Factors</div><div class="domain-chip-list">${chips(list(computer.risk_factors), "No risk factors reported")}</div></section>
                <section class="user-detail-section"><div class="user-detail-section-title">Risk Controls</div><div class="domain-chip-list">${chips(list(computer.risk_controls), "No risk controls reported")}</div></section>
                <section class="user-detail-section"><div class="user-detail-section-title">SID History</div><div class="domain-chip-list">${chips(list(computer.sid_history), "No SID history")}</div></section>
                <section class="user-detail-section"><div class="user-detail-section-title">LAPS Attributes</div><div class="domain-chip-list">${chips(list(computer.laps_attributes), "No LAPS attributes")}</div></section>
            </div>
        </aside>`;
    overlay.addEventListener("mousedown", event => {
        if (event.target === overlay) closeUserDetailPanel();
    });
    overlay.querySelector(".user-detail-close").addEventListener("click", closeUserDetailPanel);
    document.body.appendChild(overlay);
    document.addEventListener("keydown", handleUserDetailKeydown);
}

(function initComputersViewAnimations() {
    function pulseCount(root) {
        const el = root.querySelector(".domain-count");
        if (!el) return;
        const current = el.textContent;
        if (el.dataset.dcLast === current) return;
        el.dataset.dcLast = current;
        el.classList.remove("dc-count-pulse");
        void el.offsetWidth;
        el.classList.add("dc-count-pulse");
    }

    function staggerRows(root) {
        const rows = root.querySelectorAll(".domain-table-body tr");
        rows.forEach((row, index) => {
            row.style.setProperty("--row-index", String(Math.min(index, 24)));
            row.classList.add("dc-row-in");
        });
    }

    function markFilterReady(root) {
        const filter = root.querySelector(".user-filter");
        if (filter) filter.classList.add("dc-filter-ready");
    }

    function enhance(root) {
        pulseCount(root);
        staggerRows(root);
        markFilterReady(root);
    }

    function attach(root) {
        if (root.dataset.dcWatching) return;
        root.dataset.dcWatching = "1";
        enhance(root);
        loadStats(root);
        const body = root.querySelector(".domain-table-body");
        const count = root.querySelector(".domain-count");
        [body, count].filter(Boolean).forEach(target => {
            new MutationObserver(() => enhance(root)).observe(target, { childList: true, characterData: true, subtree: true });
        });
    }

    const STAT_ICONS = {
        crown: '<path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5L3 8z"/>',
        nested: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z"/><path d="M9 12l2 2 4-4"/>',
        potential: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z"/><path d="M12 8v5M12 16v.01"/>',
        bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z"/>',
        target: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r=".8"/>',
        arrow: '<path d="M4 12h14M13 6l6 6-6 6"/>',
        clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>'
    };

    const STAT_CARDS = [
        { label: "Domain Controllers", tone: "purple", icon: "crown", summaryKeys: ["domain_controller_count", "domain_controllers_count"] },
        { label: "Absolute Admins", tone: "red", icon: "crown", summaryKeys: ["absolute_admin_counts", "absolute_admin_count"] },
        { label: "Nested Admins", tone: "orange", icon: "nested", summaryKeys: ["nested_admins_count", "nested_admin_count"] },
        { label: "Potential Admins", tone: "amber", icon: "potential", summaryKeys: ["potential_admins_count", "potential_admin_count"] },
        { label: "Unconstrained Delegation", tone: "red", icon: "bolt", summaryKeys: ["unconstrained_delegation_count", "unconstrained_delegation_counts"] }
    ];

    function fmtInt(value) {
        return Number(value).toLocaleString("en-US");
    }

    function fmtPct(count, total) {
        if (!total) return "0%";
        const pct = count / total * 100;
        if (count > 0 && pct < 0.1) return "<0.1%";
        return (pct < 10 ? pct.toFixed(1) : Math.round(pct)) + "%";
    }

    function countUp(el, target) {
        const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        if (reduce || target < 2) {
            el.textContent = fmtInt(target);
            return;
        }
        const start = performance.now();
        const duration = 800;
        function tick(now) {
            const progress = Math.min(1, (now - start) / duration);
            const eased = 1 - Math.pow(1 - progress, 3);
            el.textContent = fmtInt(Math.round(target * eased));
            if (progress < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
    }

    function skeletonHtml() {
        return STAT_CARDS.map(() => '<div class="dc-stat dc-skel"><span></span><span></span><span></span></div>').join("");
    }

    async function fetchAllComputers() {
        const size = (typeof DOMAIN_PAGE_SIZES !== "undefined" && DOMAIN_PAGE_SIZES.computers) || 500;
        const result = await Api.getDomainResults("computers", { page: 1, page_size: size });
        if (!result || !result.ok) throw new Error(result && result.error || "Unable to load computer summary");
        return result.summary && typeof result.summary === "object" ? result.summary : null;
    }

    function renderSplit(root, summary) {
        const el = root.querySelector(".dc-split");
        if (!el) return;
        const total = Number(summary && summary.total_computers) || 0;
        const enabled = Number(summary && summary.enabled_computers) || 0;
        const disabled = Number(summary && summary.disabled_computers) || 0;
        const dcCount = Number(summary && (summary.domain_controller_count || summary.domain_controllers_count)) || 0;
        const enabledPct = total ? enabled / total * 100 : 0;
        el.innerHTML = `
            <div class="dc-split-bar"><span style="--w:${enabledPct.toFixed(2)}%"></span></div>
            <div class="dc-split-legend">
                <span class="dc-leg dc-leg-ok"><i></i>Enabled <strong>${fmtInt(enabled)}</strong></span>
                <span class="dc-leg dc-leg-off"><i></i>Disabled <strong>${fmtInt(disabled)}</strong></span>
                <span class="dc-leg dc-leg-red"><i></i>Domain Controllers <strong>${fmtInt(dcCount)}</strong></span>
            </div>`;
        requestAnimationFrame(() => el.classList.add("dc-in"));
    }

    function renderStats(root, summary) {
        const el = root.querySelector(".dc-stats");
        if (!el) return;
        const total = Number(summary && summary.total_computers) || 0;
        el.innerHTML = STAT_CARDS.map((card, index) => {
            const metaCount = summary && card.summaryKeys
                ? Number(card.summaryKeys.map(key => summary[key]).find(value => value !== undefined))
                : NaN;
            const count = Number.isFinite(metaCount) ? metaCount : 0;
            const pct = total ? count / total * 100 : 0;
            return `
            <div class="dc-stat dc-tone-${card.tone}${count === 0 ? " dc-zero" : ""}" style="--i:${index};--pct:${Math.min(100, pct).toFixed(2)}%">
                <div class="dc-stat-head">
                    <span class="dc-stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${STAT_ICONS[card.icon]}</svg></span>
                    <span class="dc-stat-label">${card.label}</span>
                </div>
                <div class="dc-stat-value" data-target="${count}">0</div>
                <div class="dc-stat-foot"><span>${fmtPct(count, total)} of computers</span></div>
                <div class="dc-stat-bar"><span></span></div>
            </div>`;
        }).join("");
        requestAnimationFrame(() => {
            el.classList.add("dc-in");
            el.querySelectorAll(".dc-stat-value").forEach(v => countUp(v, Number(v.dataset.target) || 0));
        });
    }

    async function loadStats(root) {
        const el = root.querySelector(".dc-stats");
        if (!el) return;
        if (typeof Api === "undefined" || typeof Api.getDomainResults !== "function") {
            el.remove();
            return;
        }
        el.innerHTML = skeletonHtml();
        try {
            const summary = await fetchAllComputers();
            if (!summary) {
                el.remove();
                return;
            }
            renderSplit(root, summary);
            renderStats(root, summary);
        } catch (error) {
            el.remove();
        }
    }

    function findRoot() {
        return document.querySelector('.domain-result-view[data-domain-kind="computers"]');
    }

    const existing = findRoot();
    if (existing) {
        attach(existing);
    } else {
        const bodyObserver = new MutationObserver(() => {
            const root = findRoot();
            if (root) {
                attach(root);
                bodyObserver.disconnect();
            }
        });
        bodyObserver.observe(document.body, { childList: true, subtree: true });
    }
})();