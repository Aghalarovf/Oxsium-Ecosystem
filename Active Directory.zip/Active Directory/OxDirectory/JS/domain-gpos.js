SCHEMAS.gpos = {
    columns: [
        {
            label: "Policy",
            render: d => `<strong>${esc(d.display_name || d.name || "Unknown")}</strong><small>${esc(d.guid || "")}</small>`
        },
        {
            label: "Links",
            render: d => `
                <div class="gpo-links-summary">
                    <strong>${fmtNumber(d.linked_count)} ${Number(d.linked_count) === 1 ? "Object" : "Objects"}</strong>
                    <button type="button" class="domain-members-button">
                        <span>View links</span>
                        <svg class="domain-members-arrow" viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 18l6-6-6-6"/></svg>
                    </button>
                </div>`
        },
        {
            label: "Status",
            render: d => d.enforced ? badge("Enforced", "info") : badge("Not Enforced", "muted")
        }
    ],
    rowClass: d => d.highvalue ? "gpo-highvalue" : "",
    clickable: true,
    sort: { field: "linked_count", dir: "desc" }
};

const GPOS_MODULE_FILTER_CONFIG = {
    subtitle: "Narrow down GPOs by any attribute, flag, date or counter",
    presets: [],
    textFields: [
        { key: "name", label: "Name", get: g => g.name },
        { key: "display_name", label: "Display Name", get: g => g.display_name },
        { key: "guid", label: "GUID", get: g => g.guid },
        { key: "domain", label: "Domain", get: g => g.domain },
        { key: "domainsid", label: "Domain SID", get: g => g.domainsid },
        { key: "path", label: "SYSVOL Path", get: g => g.path },
        { key: "owner_name", label: "Owner", get: g => g.owner_name }
    ],
    triFields: [
        { key: "tier0", label: "Tier-0", tone: "danger", get: g => !!g.tier0 },
        { key: "highvalue", label: "High Value", tone: "danger", get: g => !!g.highvalue },
        { key: "controlled_by_non_admin", label: "Controlled By Non-Admin", tone: "danger", get: g => !!g.controlled_by_non_admin },
        { key: "enforced", label: "Enforced", tone: "info", get: g => !!g.enforced },
        { key: "link_disabled", label: "Link Disabled", tone: "warn", get: g => !!g.link_disabled },
        { key: "inheritance_blocked", label: "Inheritance Blocked", tone: "warn", get: g => !!g.inheritance_blocked },
        { key: "isaclprotected", label: "ACL Protected", tone: "info", get: g => !!g.isaclprotected },
        { key: "is_critical_system_object", label: "Critical System Object", tone: "info", get: g => !!g.is_critical_system_object }
    ],
    dateFields: [
        { key: "created", label: "Created", get: g => ufTime(g.created) },
        { key: "modified", label: "Modified", get: g => ufTime(g.modified) }
    ],
    numFields: [
        { key: "linked_count", label: "Linked Objects", get: g => ufNum(g.linked_count) },
        { key: "version", label: "Version", get: g => ufNum(g.version) }
    ],
    sortFields: [
        { key: "display_name", label: "Policy Name", type: "text", get: g => String(g.display_name || g.name || "").toLowerCase() },
        { key: "linked_count", label: "Linked Objects", type: "num", get: g => ufNum(g.linked_count) },
        { key: "created", label: "Created", type: "num", get: g => ufTime(g.created) }
    ],
    tabs: [
        { key: "identity", label: "Identity", icon: "user" },
        { key: "status", label: "Links", icon: "status" },
        { key: "security", label: "Security", icon: "shield" },
        { key: "activity", label: "Activity", icon: "clock" }
    ],
    layout: {
        identity: [
            { title: "Policy", kind: "text", keys: ["name", "display_name", "guid"] },
            { title: "Ownership", kind: "text", keys: ["domain", "domainsid", "owner_name", "path"] }
        ],
        status: [
            { title: "Link Status", kind: "tri", keys: ["enforced", "link_disabled", "inheritance_blocked"] }
        ],
        security: [
            { title: "Security", kind: "tri", keys: ["tier0", "highvalue", "controlled_by_non_admin", "isaclprotected", "is_critical_system_object"] }
        ],
        activity: [
            { title: "Timeline", kind: "date", keys: ["created", "modified"] },
            { title: "Counters", kind: "num", keys: ["linked_count", "version"] }
        ]
    },
    knownKeys: ["name", "display_name", "guid", "domain", "domainsid", "path", "owner_name", "tier0", "highvalue", "controlled_by_non_admin", "enforced", "link_disabled", "inheritance_blocked", "isaclprotected", "is_critical_system_object", "linked_count", "version", "created", "modified"]
};

FULL_FILTER_CONFIGS.gpos = GPOS_MODULE_FILTER_CONFIG;

function gpoLinkType(dn) {
    const first = String(dn || "").split(",")[0].trim().toUpperCase();
    if (first.startsWith("OU=")) return "OU";
    if (first.startsWith("DC=")) return "Domain";
    if (first.startsWith("CN=")) return "Site";
    return "Object";
}

function openGpoLinksPanel(gpo) {
    closeUserDetailPanel();
    const links = Array.isArray(gpo.linked_containers) ? gpo.linked_containers : [];
    const overlay = document.createElement("div");
    overlay.className = "user-detail-overlay";
    overlay.innerHTML = `
        <aside class="user-detail-panel" role="dialog" aria-modal="true" aria-label="GPO links">
            <div class="user-detail-header">
                <div class="user-detail-avatar">${esc(initials(gpo.display_name || gpo.name))}</div>
                <div class="user-detail-heading"><h2>${esc(gpo.display_name || gpo.name || "Unknown GPO")}</h2><span class="user-detail-dn">${esc(gpo.guid || "")}</span></div>
                <button class="user-detail-close" type="button" aria-label="Close">&times;</button>
            </div>
            <div class="user-detail-status-row">${badge(`${links.length} Object${links.length === 1 ? "" : "s"}`, "info")}</div>
            <div class="user-detail-body">
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Linked Objects</div>
                    <div class="group-member-list">
                        ${links.length ? links.map(link => `<div class="group-member"><strong>${esc(ouName(link.dn) || "Unknown")}</strong><span>${esc(gpoLinkType(link.dn))}</span><small>${esc(link.dn || "")}</small></div>`).join("") : '<span class="domain-muted">No linked objects reported</span>'}
                    </div>
                </section>
            </div>
        </aside>`;
    overlay.addEventListener("mousedown", event => {
        if (event.target === overlay) closeUserDetailPanel();
    });
    overlay.querySelector(".user-detail-close").addEventListener("click", closeUserDetailPanel);
    document.body.appendChild(overlay);
    document.addEventListener("keydown", handleUserDetailKeydown);
}

function openGpoDetailPanel(gpo) {
    closeUserDetailPanel();
    const kv = (label, html) => `<div class="user-detail-kv"><span>${esc(label)}</span><strong>${html}</strong></div>`;
    const text = value => value === null || value === undefined || value === "" ? '<span class="domain-muted">-</span>' : esc(String(value));
    const overview = [
        ["Name", text(gpo.name)], ["Display Name", text(gpo.display_name)], ["GUID", text(gpo.guid)],
        ["Domain", text(gpo.domain)], ["Path", text(gpo.path)], ["Owner", text(gpo.owner_name)],
        ["Linked Objects", fmtNumber(gpo.linked_count)], ["Version", text(gpo.version)]
    ];
    const overlay = document.createElement("div");
    overlay.className = "user-detail-overlay";
    overlay.innerHTML = `
        <aside class="user-detail-panel" role="dialog" aria-modal="true" aria-label="GPO details">
            <div class="user-detail-header">
                <div class="user-detail-avatar">${esc(initials(gpo.display_name || gpo.name))}</div>
                <div class="user-detail-heading"><h2>${esc(gpo.display_name || gpo.name || "Unknown GPO")}</h2><span class="user-detail-dn">${esc(gpo.guid || "")}</span></div>
                <button class="user-detail-close" type="button" aria-label="Close">&times;</button>
            </div>
            <div class="user-detail-status-row">
                ${gpo.tier0 ? badge("Tier-0", "admin-high") : ""}
                ${gpo.highvalue ? badge("High Value", "danger") : ""}
                ${gpo.enforced ? badge("Enforced", "info") : badge("Not Enforced", "muted")}
            </div>
            <div class="user-detail-body">
                <section class="user-detail-section"><div class="user-detail-section-title">GPO Overview</div><div class="user-detail-grid">${overview.map(([label, html]) => kv(label, html)).join("")}</div></section>
                ${gpo.description ? `<section class="user-detail-section"><div class="user-detail-section-title">Description</div><p>${esc(gpo.description)}</p></section>` : ""}
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Security Flags</div>
                    <div class="domain-flag-list">
                        ${detailFlag("Tier-0", !!gpo.tier0)}
                        ${detailFlag("High Value", !!gpo.highvalue)}
                        ${detailFlag("Enforced", !!gpo.enforced, "info")}
                        ${detailFlag("Link Disabled", !!gpo.link_disabled, "warn")}
                        ${detailFlag("Inheritance Blocked", !!gpo.inheritance_blocked, "warn")}
                        ${detailFlag("ACL Protected", !!gpo.isaclprotected, "info")}
                    </div>
                </section>
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Links</div>
                    <button type="button" class="domain-members-button gpo-detail-links-button"><span>View links</span></button>
                </section>
            </div>
        </aside>`;
    overlay.addEventListener("mousedown", event => {
        if (event.target === overlay) closeUserDetailPanel();
    });
    overlay.querySelector(".user-detail-close").addEventListener("click", closeUserDetailPanel);
    overlay.querySelector(".gpo-detail-links-button").addEventListener("click", () => openGpoLinksPanel(gpo));
    document.body.appendChild(overlay);
    document.addEventListener("keydown", handleUserDetailKeydown);
}

(function initGposViewAnimations() {
    function pulseCount(root) {
        const el = root.querySelector(".domain-count");
        if (!el) return;
        const current = el.textContent;
        if (el.dataset.gpLast === current) return;
        el.dataset.gpLast = current;
        el.classList.remove("gp-count-pulse");
        void el.offsetWidth;
        el.classList.add("gp-count-pulse");
    }

    function staggerRows(root) {
        const rows = root.querySelectorAll(".domain-table-body tr");
        rows.forEach((row, index) => {
            row.style.setProperty("--row-index", String(Math.min(index, 24)));
            row.classList.add("gp-row-in");
        });
    }

    function markFilterReady(root) {
        const filter = root.querySelector(".user-filter");
        if (filter) filter.classList.add("gp-filter-ready");
    }

    function enhance(root) {
        pulseCount(root);
        staggerRows(root);
        markFilterReady(root);
    }

    function attach(root) {
        if (root.dataset.gpWatching) return;
        root.dataset.gpWatching = "1";
        enhance(root);
        loadStats(root);
        const body = root.querySelector(".domain-table-body");
        const count = root.querySelector(".domain-count");
        [body, count].filter(Boolean).forEach(target => {
            new MutationObserver(() => enhance(root)).observe(target, { childList: true, characterData: true, subtree: true });
        });
    }

    const STAT_ICONS = {
        crown: '<path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5L3 8z"/>',
        alert: '<path d="M12 3l10 18H2L12 3z"/><path d="M12 10v5M12 18v.01"/>',
        lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',
        link: '<path d="M9 15l6-6"/><path d="M11 6l1-1a4 4 0 015.5 5.5l-1 1"/><path d="M13 18l-1 1a4 4 0 01-5.5-5.5l1-1"/>'
    };

    const STAT_CARDS = [
        { label: "Tier-0 GPOs", tone: "red", icon: "crown", summaryKeys: ["tier0_count", "tier0_gpo_count"] },
        { label: "High Value GPOs", tone: "red", icon: "crown", summaryKeys: ["highvalue_count", "highvalue_gpo_count"] },
        { label: "Controlled By Non-Admin", tone: "orange", icon: "alert", summaryKeys: ["controlled_by_non_admin_count"] },
        { label: "Link Disabled", tone: "amber", icon: "alert", summaryKeys: ["link_disabled_count"] }
    ];

    function fmtInt(value) {
        return Number(value).toLocaleString("en-US");
    }

    function fmtPct(count, total) {
        if (!total) return "0%";
        const pct = count / total * 100;
        if (count > 0 && pct < 0.1) return "<0.1%";
        return (pct < 10 ? pct.toFixed(1) : Math.round(pct)) + "%";
    }

    function countUp(el, target) {
        const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        if (reduce || target < 2) {
            el.textContent = fmtInt(target);
            return;
        }
        const start = performance.now();
        const duration = 800;
        function tick(now) {
            const progress = Math.min(1, (now - start) / duration);
            const eased = 1 - Math.pow(1 - progress, 3);
            el.textContent = fmtInt(Math.round(target * eased));
            if (progress < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
    }

    function skeletonHtml() {
        return STAT_CARDS.map(() => '<div class="gp-stat gp-skel"><span></span><span></span><span></span></div>').join("");
    }

    async function fetchAllGpos() {
        const size = (typeof DOMAIN_PAGE_SIZES !== "undefined" && DOMAIN_PAGE_SIZES.gpos) || 500;
        const result = await Api.getDomainResults("gpos", { page: 1, page_size: size });
        if (!result || !result.ok) throw new Error(result && result.error || "Unable to load GPO summary");
        return result.summary && typeof result.summary === "object" ? result.summary : null;
    }

    function renderSplit(root, summary) {
        const el = root.querySelector(".gp-split");
        if (!el) return;
        const total = Number(summary && summary.total_gpos) || 0;
        const enforced = Number(summary && summary.enforced_count) || 0;
        const notEnforced = Math.max(total - enforced, 0);
        const tier0 = Number(summary && (summary.tier0_count || summary.tier0_gpo_count)) || 0;
        const enforcedPct = total ? enforced / total * 100 : 0;
        el.innerHTML = `
            <div class="gp-split-bar"><span style="--w:${enforcedPct.toFixed(2)}%"></span></div>
            <div class="gp-split-legend">
                <span class="gp-leg gp-leg-ok"><i></i>Enforced <strong>${fmtInt(enforced)}</strong></span>
                <span class="gp-leg gp-leg-off"><i></i>Not Enforced <strong>${fmtInt(notEnforced)}</strong></span>
                <span class="gp-leg gp-leg-red"><i></i>Tier-0 <strong>${fmtInt(tier0)}</strong></span>
            </div>`;
        requestAnimationFrame(() => el.classList.add("gp-in"));
    }

    function renderStats(root, summary) {
        const el = root.querySelector(".gp-stats");
        if (!el) return;
        const total = Number(summary && summary.total_gpos) || 0;
        el.innerHTML = STAT_CARDS.map((card, index) => {
            const metaCount = summary && card.summaryKeys
                ? Number(card.summaryKeys.map(key => summary[key]).find(value => value !== undefined))
                : NaN;
            const count = Number.isFinite(metaCount) ? metaCount : 0;
            const pct = total ? count / total * 100 : 0;
            return `
            <div class="gp-stat gp-tone-${card.tone}${count === 0 ? " gp-zero" : ""}" style="--i:${index};--pct:${Math.min(100, pct).toFixed(2)}%">
                <div class="gp-stat-head">
                    <span class="gp-stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${STAT_ICONS[card.icon]}</svg></span>
                    <span class="gp-stat-label">${card.label}</span>
                </div>
                <div class="gp-stat-value" data-target="${count}">0</div>
                <div class="gp-stat-foot"><span>${fmtPct(count, total)} of GPOs</span></div>
                <div class="gp-stat-bar"><span></span></div>
            </div>`;
        }).join("");
        requestAnimationFrame(() => {
            el.classList.add("gp-in");
            el.querySelectorAll(".gp-stat-value").forEach(v => countUp(v, Number(v.dataset.target) || 0));
        });
    }

    async function loadStats(root) {
        const el = root.querySelector(".gp-stats");
        if (!el) return;
        if (typeof Api === "undefined" || typeof Api.getDomainResults !== "function") {
            el.remove();
            return;
        }
        el.innerHTML = skeletonHtml();
        try {
            const summary = await fetchAllGpos();
            if (!summary) {
                el.remove();
                return;
            }
            renderSplit(root, summary);
            renderStats(root, summary);
        } catch (error) {
            el.remove();
        }
    }

    function findRoot() {
        return document.querySelector('.domain-result-view[data-domain-kind="gpos"]');
    }

    const existing = findRoot();
    if (existing) {
        attach(existing);
    } else {
        const bodyObserver = new MutationObserver(() => {
            const root = findRoot();
            if (root) {
                attach(root);
                bodyObserver.disconnect();
            }
        });
        bodyObserver.observe(document.body, { childList: true, subtree: true });
    }
})();