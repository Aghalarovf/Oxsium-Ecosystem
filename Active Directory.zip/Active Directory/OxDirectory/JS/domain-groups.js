SCHEMAS.groups = {
    columns: [
        {
            label: "Group",
            render: d => `<strong>${esc(d.group_name || "Unknown")}</strong><small>${esc(d.group_sid || "")}</small>`
        },
        {
            label: "Members",
            render: d => `
                <div class="domain-members-cell">
                    <strong>${fmtNumber(d.member_count)} ${Number(d.member_count) === 1 ? "member" : "members"}</strong>
                    <button type="button" class="domain-members-button">
                        <svg class="domain-members-icon" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M21 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                        <span>View members</span>
                        <svg class="domain-members-arrow" viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 18l6-6-6-6"/></svg>
                    </button>
                </div>`
        },
        {
            label: "Privileged",
            render: d => d.is_privileged ? badge("Yes", "danger") : badge("No", "muted")
        }
    ],
    rowClass: d => d.is_privileged ? "flagged" : "",
    clickable: true,
    sort: { field: "member_count", dir: "desc" }
};

const GROUPS_FILTER_CONFIG = {
    subtitle: "Narrow down groups by any attribute, flag, date or membership",
    presets: [],
    textFields: [
        { key: "group_name", label: "Group Name", placeholder: "e.g. Domain Admins", get: g => g.group_name },
        { key: "group_dn", label: "Distinguished Name", placeholder: "e.g. CN=Domain Admins", get: g => g.group_dn },
        { key: "description", label: "Description", placeholder: "e.g. built-in group", get: g => g.description },
        { key: "info", label: "Notes", placeholder: "e.g. info field", get: g => g.info },
        { key: "managed_by", label: "Managed By", placeholder: "e.g. CN=IT Admins", get: g => g.managed_by },
        { key: "admin_description", label: "Admin Description", placeholder: "e.g. Tier-0 evidence", get: g => g.admin_description },
        { key: "admin_evidence", label: "Admin Evidence", placeholder: "e.g. nested membership", get: g => g.admin_evidence },
        { key: "group_sid", label: "Group SID", placeholder: "e.g. S-1-5-21", get: g => g.group_sid },
        { key: "domainsid", label: "Domain SID", placeholder: "e.g. S-1-5-21", get: g => g.domainsid }
    ],
    triFields: [
        { key: "is_privileged", label: "Privileged", tone: "danger", get: g => !!g.is_privileged },
        { key: "absolute_admin", label: "Absolute Admin", tone: "danger", get: g => !!g.absolute_admin },
        { key: "nested_admin", label: "Nested Admin", tone: "danger", get: g => !!g.nested_admin },
        { key: "potential_admin", label: "Potential Admin", tone: "warn", get: g => !!g.potential_admin },
        { key: "admin_count", label: "Admin Count", tone: "warn", get: g => !!g.admin_count },
        { key: "is_protected", label: "Protected", tone: "info", get: g => !!g.is_protected },
        { key: "isaclprotected", label: "ACL Protected", tone: "info", get: g => !!g.isaclprotected },
        { key: "is_critical_system_object", label: "Critical System Object", tone: "info", get: g => !!g.is_critical_system_object },
        { key: "security_enabled", label: "Security Enabled", tone: "ok", get: g => !!g.security_enabled },
        { key: "is_nested", label: "Nested Group", tone: "info", get: g => !!g.is_nested },
        { key: "is_empty", label: "Empty", tone: "info", get: g => !!g.is_empty },
        { key: "has_description", label: "Has Description", tone: "info", get: g => ufHasText(g.description) },
        { key: "has_managed_by", label: "Has Managed By", tone: "info", get: g => ufHasText(g.managed_by) }
    ],
    dateFields: [
        { key: "when_created", label: "Created", get: g => ufTime(g.when_created) },
        { key: "when_changed", label: "Last Changed", get: g => ufTime(g.when_changed) }
    ],
    numFields: [
        { key: "member_count", label: "Member Count", get: g => ufNum(g.member_count) },
        { key: "rid", label: "RID", get: g => ufNum(g.rid) },
        { key: "primary_group_token", label: "Primary Group Token", get: g => ufNum(g.primary_group_token) }
    ],
    sortFields: [
        { key: "group_name", label: "Group Name", type: "text", get: g => String(g.group_name || "").toLowerCase() },
        { key: "member_count", label: "Member Count", type: "num", get: g => { const n = ufNum(g.member_count); return Number.isFinite(n) ? n : null; } },
        { key: "when_created", label: "Created", type: "num", get: g => ufTime(g.when_created) },
        { key: "when_changed", label: "Last Changed", type: "num", get: g => ufTime(g.when_changed) },
        { key: "rid", label: "RID", type: "num", get: g => { const n = ufNum(g.rid); return Number.isFinite(n) ? n : null; } }
    ],
    tabs: [
        { key: "identity", label: "Identity", icon: "user" },
        { key: "security", label: "Security", icon: "shield" },
        { key: "activity", label: "Activity", icon: "clock" }
    ],
    layout: {
        identity: [
            { title: "Group Names", kind: "text", keys: ["group_name", "group_dn"] },
            { title: "Description & Notes", kind: "text", keys: ["description", "info"] },
            { title: "Administration", kind: "text", keys: ["managed_by", "admin_description", "admin_evidence"] },
            { title: "Identifiers", kind: "text", keys: ["group_sid", "domainsid"] },
            { title: "Profile Completeness", kind: "tri", keys: ["has_description", "has_managed_by"] }
        ],
        security: [
            { title: "Administrative Rights", kind: "tri", keys: ["is_privileged", "absolute_admin", "nested_admin", "potential_admin", "admin_count"] },
            { title: "Protection & Type", kind: "tri", keys: ["is_protected", "isaclprotected", "is_critical_system_object", "security_enabled", "is_nested", "is_empty"] }
        ],
        activity: [
            { title: "Timeline", kind: "date", keys: ["when_created", "when_changed"] },
            { title: "Counters", kind: "num", keys: ["member_count", "rid", "primary_group_token"] }
        ]
    },
    membership: {
        tabLabel: "Membership",
        sectionTitle: "Nested Group Membership",
        includeLabel: "Member of",
        excludeLabel: "Not member of",
        includeHint: "Press Enter or comma to add. Matches group names and distinguished names this group belongs to.",
        excludeHint: "Groups belonging to any of these groups are hidden.",
        placeholder: "Type a group name and press Enter",
        getList: g => Array.isArray(g.member_of) ? g.member_of : [],
        numField: { key: "member_count", label: "Member Count" }
    },
    knownKeys: [
        "group_name", "group_dn", "group_sid", "domainsid", "description", "info", "managed_by",
        "admin_description", "admin_evidence", "rid", "primary_group_token", "group_type", "member_count",
        "member_of", "members", "is_privileged", "absolute_admin", "nested_admin", "potential_admin",
        "admin_count", "is_protected", "isaclprotected", "is_critical_system_object", "security_enabled",
        "is_nested", "is_empty", "when_created", "when_changed"
    ]
};

FULL_FILTER_CONFIGS.groups = GROUPS_FILTER_CONFIG;

function groupTypeLabel(value) {
    const number = Number(value);
    if (value === null || value === undefined || !Number.isFinite(number)) return "";
    const flags = number >>> 0;
    const kind = (flags & 0x80000000) ? "Security" : "Distribution";
    const scope = (flags & 2) ? "Global" : (flags & 4) ? "Domain Local" : (flags & 8) ? "Universal" : "Unknown";
    return `${kind} / ${scope}${(flags & 1) ? " / Built-in" : ""}`;
}

function openGroupMembersPanel(group) {
    closeUserDetailPanel();
    const members = Array.isArray(group.members) ? group.members : [];
    const overlay = document.createElement("div");
    overlay.className = "user-detail-overlay";
    overlay.innerHTML = `
        <aside class="user-detail-panel" role="dialog" aria-modal="true" aria-label="Group members">
            <div class="user-detail-header">
                <div class="user-detail-avatar">${esc(initials(group.group_name))}</div>
                <div class="user-detail-heading">
                    <h2>${esc(group.group_name || "Unknown")}</h2>
                    <span class="user-detail-dn">${esc(group.group_dn || "")}</span>
                </div>
                <button class="user-detail-close" type="button" aria-label="Close">&times;</button>
            </div>
            <div class="user-detail-status-row">${badge(`${members.length} member${members.length === 1 ? "" : "s"}`, "info")}</div>
            <div class="user-detail-body">
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Members</div>
                    <div class="group-member-list">
                        ${members.length ? members.map(member => `
                            <div class="group-member">
                                <strong>${esc(member.member_name || shortDn(member.member_dn) || "Unknown")}</strong>
                                <span>${member.is_group ? "Group" : member.is_computer ? "Computer" : "User"}</span>
                                <small>${esc(member.member_dn || member.member_sid || "")}</small>
                            </div>`).join("") : '<span class="domain-muted">No members reported</span>'}
                    </div>
                </section>
            </div>
        </aside>`;
    overlay.addEventListener("mousedown", event => {
        if (event.target === overlay) closeUserDetailPanel();
    });
    overlay.querySelector(".user-detail-close").addEventListener("click", closeUserDetailPanel);
    document.body.appendChild(overlay);
    document.addEventListener("keydown", handleUserDetailKeydown);
}

function openGroupDetailPanel(group) {
    closeUserDetailPanel();
    const members = Array.isArray(group.members) ? group.members : [];
    const memberOf = Array.isArray(group.member_of) ? group.member_of : [];
    const userCount = members.filter(member => member.is_user).length;
    const computerCount = members.filter(member => member.is_computer).length;
    const groupCount = members.filter(member => member.is_group).length;
    const highAdmin = !!group.absolute_admin || !!group.nested_admin;
    const kv = (label, html) => `<div class="user-detail-kv"><span>${esc(label)}</span><strong>${html}</strong></div>`;
    const text = value => (value === null || value === undefined || value === "") ? '<span class="domain-muted">-</span>' : esc(String(value));
    const overview = [
        ["Group Name", text(group.group_name)],
        ["SID", text(group.group_sid)],
        ["RID", text(group.rid)],
        ["Primary Group Token", text(group.primary_group_token)],
        ["Domain SID", text(group.domainsid)],
        ["Group Type", text(groupTypeLabel(group.group_type))],
        ["Managed By", text(group.managed_by)],
        ["Members", esc(fmtNumber(group.member_count))]
    ];
    const timeline = [
        ["Created", fmtDate(group.when_created)],
        ["Changed", fmtDate(group.when_changed)]
    ];
    const overlay = document.createElement("div");
    overlay.className = "user-detail-overlay";
    overlay.innerHTML = `
        <aside class="user-detail-panel" role="dialog" aria-modal="true" aria-label="Group details">
            <div class="user-detail-header">
                <div class="user-detail-avatar">${esc(initials(group.group_name))}</div>
                <div class="user-detail-heading">
                    <h2>${esc(group.group_name || "Unknown")}</h2>
                    <span class="user-detail-dn">${esc(group.group_dn || "")}</span>
                </div>
                <button class="user-detail-close" type="button" aria-label="Close">&times;</button>
            </div>
            <div class="user-detail-status-row">
                ${group.is_privileged ? badge("Privileged", "danger") : badge("Not Privileged", "muted")}
                ${highAdmin ? badge("Tier-0 Admin", "admin-high") : ""}
                ${!highAdmin && group.potential_admin ? badge("Potential Admin", "admin-potential") : ""}
                ${badge(`${fmtNumber(group.member_count)} member${Number(group.member_count) === 1 ? "" : "s"}`, "info")}
            </div>
            <div class="user-detail-body">
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Group Overview</div>
                    <div class="user-detail-grid">${overview.map(([label, html]) => kv(label, html)).join("")}</div>
                </section>
                ${group.description ? `<section class="user-detail-section"><div class="user-detail-section-title">Description</div><p>${esc(group.description)}</p></section>` : ""}
                ${group.info ? `<section class="user-detail-section"><div class="user-detail-section-title">Notes</div><p>${esc(group.info)}</p></section>` : ""}
                ${group.admin_description ? `
                <section class="user-detail-section user-admin-description">
                    <div class="user-detail-section-title">Admin Description</div>
                    <p>${esc(group.admin_description)}</p>
                    ${group.admin_evidence ? `<div class="user-detail-evidence"><span>Evidence</span><strong>${esc(group.admin_evidence)}</strong></div>` : ""}
                </section>` : ""}
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Security Flags</div>
                    <div class="domain-flag-list">
                        ${detailFlag("Privileged", !!group.is_privileged)}
                        ${detailFlag("Absolute Admin", !!group.absolute_admin)}
                        ${detailFlag("Nested Admin", !!group.nested_admin)}
                        ${detailFlag("Potential Admin", !!group.potential_admin, "warn")}
                        ${detailFlag("Admin Count", !!group.admin_count, "warn")}
                        ${detailFlag("Protected", !!group.is_protected, "info")}
                        ${detailFlag("ACL Protected", !!group.isaclprotected, "info")}
                        ${detailFlag("Critical System Object", !!group.is_critical_system_object, "info")}
                        ${detailFlag("Security Enabled", !!group.security_enabled, "ok")}
                        ${detailFlag("Nested Group", !!group.is_nested, "info")}
                        ${detailFlag("Empty", !!group.is_empty, "info")}
                    </div>
                </section>
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Timeline</div>
                    <div class="user-detail-grid">${timeline.map(([label, html]) => kv(label, html)).join("")}</div>
                </section>
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Member Of</div>
                    <div class="domain-chip-list">
                        ${memberOf.length ? memberOf.map(g => `<span class="domain-chip">${esc(shortDn(g))}</span>`).join("") : '<span class="domain-muted">This group is not a member of any other group</span>'}
                    </div>
                </section>
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Members</div>
                    <div class="domain-flag-list">
                        ${badge(`${fmtNumber(userCount)} user${userCount === 1 ? "" : "s"}`, "muted")}
                        ${badge(`${fmtNumber(computerCount)} computer${computerCount === 1 ? "" : "s"}`, "muted")}
                        ${badge(`${fmtNumber(groupCount)} group${groupCount === 1 ? "" : "s"}`, "muted")}
                    </div>
                    <div class="group-member-list" style="margin-top:12px">
                        ${members.length ? members.map(member => `
                            <div class="group-member">
                                <strong>${esc(member.member_name || shortDn(member.member_dn) || "Unknown")}</strong>
                                <span>${member.is_group ? "Group" : member.is_computer ? "Computer" : "User"}</span>
                                <small>${esc(member.member_dn || member.member_sid || "")}</small>
                            </div>`).join("") : '<span class="domain-muted">No members reported</span>'}
                    </div>
                </section>
            </div>
        </aside>`;
    overlay.addEventListener("mousedown", event => {
        if (event.target === overlay) closeUserDetailPanel();
    });
    overlay.querySelector(".user-detail-close").addEventListener("click", closeUserDetailPanel);
    document.body.appendChild(overlay);
    document.addEventListener("keydown", handleUserDetailKeydown);
}

(() => {
    const STAT_CARDS = [
        { label: "Privileged Groups", tone: "red", icon: "shield", key: "privileged_group_count" },
        { label: "Empty Groups", tone: "amber", icon: "users", key: "empty_group_count" },
        { label: "Nested Groups", tone: "orange", icon: "nested", key: "nested_group_count" },
        { label: "Nested Admins", tone: "orange", icon: "nested", key: "nested_admin_count" },
        { label: "Potential Admins", tone: "amber", icon: "potential", key: "potential_admin_count" }
    ];

    const STAT_ICONS = {
        shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z"/><path d="M9 12l2 2 4-4"/>',
        users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        user: '<path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/>',
        nested: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M12 3v5M21 12h-5"/>',
        lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
        crown: '<path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5L3 8z"/>',
        potential: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z"/><path d="M12 8v5M12 16v.01"/>',
        admin: '<circle cx="12" cy="12" r="9"/><path d="M12 7v10M7 12h10"/>'
    };

    function fmtInt(value) {
        return Number(value).toLocaleString("en-US");
    }

    function fmtPct(count, total) {
        if (!total) return "0%";
        const pct = count / total * 100;
        if (count > 0 && pct < 0.1) return "<0.1%";
        return (pct < 10 ? pct.toFixed(1) : Math.round(pct)) + "%";
    }

    function countUp(el, target) {
        const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        if (reduce || target < 2) {
            el.textContent = fmtInt(target);
            return;
        }
        const start = performance.now();
        const duration = 800;
        function tick(now) {
            const progress = Math.min(1, (now - start) / duration);
            const eased = 1 - Math.pow(1 - progress, 3);
            el.textContent = fmtInt(Math.round(target * eased));
            if (progress < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
    }

    async function fetchSummary() {
        if (typeof Api === "undefined" || typeof Api.getDomainResults !== "function") return null;
        const result = await Api.getDomainResults("groups", { page: 1, page_size: 1 });
        return result && result.ok && result.summary ? result.summary : null;
    }

    function render(root, summary) {
        const stats = root.querySelector(".dg-stats");
        const split = root.querySelector(".dg-split");
        if (!stats || !summary) return;
        const total = Number(summary.total_groups) || 0;
        const privileged = Number(summary.privileged_group_count) || 0;
        const empty = Number(summary.empty_group_count) || 0;
        const nested = Number(summary.nested_group_count) || 0;
        const protectedCount = Number(summary.protected_group_count) || 0;
        const security = total ? ((total - empty) / total * 100) : 0;

        if (split) {
            split.innerHTML = `
                <div class="dg-split-bar"><span style="--w:${security.toFixed(2)}%"></span></div>
                <div class="dg-split-legend">
                    <span class="dg-leg dg-leg-ok"><i></i>Populated <strong>${fmtInt(total - empty)}</strong></span>
                    <span class="dg-leg dg-leg-off"><i></i>Empty <strong>${fmtInt(empty)}</strong></span>
                    <span class="dg-leg dg-leg-red"><i></i>Privileged <strong>${fmtInt(privileged)}</strong></span>
                    <span class="dg-leg dg-leg-blue"><i></i>Protected <strong>${fmtInt(protectedCount)}</strong></span>
                    <span class="dg-leg dg-leg-orange"><i></i>Nested <strong>${fmtInt(nested)}</strong></span>
                </div>`;
            requestAnimationFrame(() => split.classList.add("dg-in"));
        }

        stats.innerHTML = STAT_CARDS.map((card, index) => {
            const count = Number(summary[card.key]) || 0;
            const pct = total ? count / total * 100 : 0;
            return `
                <div class="dg-stat dg-tone-${card.tone}${count === 0 ? " dg-zero" : ""}" style="--i:${index};--pct:${Math.min(100, pct).toFixed(2)}%">
                    <div class="dg-stat-head">
                        <span class="dg-stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${STAT_ICONS[card.icon]}</svg></span>
                        <span class="dg-stat-label">${card.label}</span>
                    </div>
                    <div class="dg-stat-value" data-target="${count}">0</div>
                    <div class="dg-stat-foot">${card.key === "member_count" || card.key === "member_users_count" ? "members" : `${fmtPct(count, total)} of groups`}</div>
                    <div class="dg-stat-bar"><span></span></div>
                </div>`;
        }).join("");
        requestAnimationFrame(() => {
            stats.classList.add("dg-in");
            stats.querySelectorAll(".dg-stat-value").forEach(v => countUp(v, Number(v.dataset.target) || 0));
        });
    }

    async function attach() {
        const root = document.querySelector('.domain-result-view[data-domain-kind="groups"]');
        if (!root || root.dataset.dgInitialized) return;
        root.dataset.dgInitialized = "1";
        const stats = root.querySelector(".dg-stats");
        if (stats) {
            stats.innerHTML = STAT_CARDS.map(() => '<div class="dg-stat dg-skel"><span></span><span></span><span></span></div>').join("");
        }
        try {
            render(root, await fetchSummary());
        } catch (error) {
            if (stats) stats.remove();
        }
    }

    const existing = document.querySelector('.domain-result-view[data-domain-kind="groups"]');
    if (existing) attach();
    else {
        const observer = new MutationObserver(() => {
            if (document.querySelector('.domain-result-view[data-domain-kind="groups"]')) {
                attach();
                observer.disconnect();
            }
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }
})();
