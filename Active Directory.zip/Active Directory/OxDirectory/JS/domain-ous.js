SCHEMAS.ous = {
    columns: [
        {
            label: "Organizational Unit",
            render: d => `<strong>${esc(d.name || "Unknown")}</strong><small class="domain-dn-trunc" title="${esc(d.dn || "")}">${esc(d.dn || "")}</small>`
        },
        {
            label: "Objects",
            render: d => `
                <div class="domain-members-cell">
                    <strong>${fmtNumber(d.object_count)} ${Number(d.object_count) === 1 ? "object" : "objects"}</strong>
                    <button type="button" class="domain-members-button">
                        <span>View objects</span>
                        <svg class="domain-members-arrow" viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 18l6-6-6-6"/></svg>
                    </button>
                </div>`
        },
        {
            label: "GPO Links",
            render: d => d.has_gpo_links ? badge("Linked", "info") : badge("None", "muted")
        }
    ],
    rowClass: d => (d.privileged_users_count || d.privileged_computers_count) ? "flagged" : "",
    clickable: true,
    sort: { field: "object_count", dir: "desc" }
};

const OUS_FILTER_CONFIG = {
    subtitle: "Narrow down organizational units by attributes",
    presets: [],
    textFields: [
        { key: "name", label: "OU Name", placeholder: "e.g. Finance", get: o => o.name },
        { key: "dn", label: "Distinguished Name", placeholder: "e.g. OU=Finance", get: o => o.dn },
        { key: "description", label: "Description", get: o => o.description },
        { key: "managed_by", label: "Managed By", get: o => o.managed_by }
    ],
    triFields: [
        { key: "tier0", label: "Tier-0", tone: "danger", get: o => !!o.tier0 },
        { key: "highvalue", label: "High Value", tone: "danger", get: o => !!o.highvalue },
        { key: "has_gpo_links", label: "GPO Linked", tone: "info", get: o => !!o.has_gpo_links },
        { key: "inheritance_blocked", label: "Inheritance Blocked", tone: "warn", get: o => !!o.inheritance_blocked },
        { key: "is_protected", label: "Protected", tone: "info", get: o => !!o.is_protected },
        { key: "isaclprotected", label: "ACL Protected", tone: "info", get: o => !!o.isaclprotected }
    ],
    dateFields: [
        { key: "created", label: "Created", get: o => ufTime(o.created) },
        { key: "modified", label: "Modified", get: o => ufTime(o.modified) }
    ],
    numFields: [
        { key: "object_count", label: "Object Count", get: o => ufNum(o.object_count) },
        { key: "privileged_users_count", label: "Privileged Users", get: o => ufNum(o.privileged_users_count) },
        { key: "privileged_computers_count", label: "Privileged Computers", get: o => ufNum(o.privileged_computers_count) }
    ],
    sortFields: [
        { key: "name", label: "OU Name", type: "text", get: o => String(o.name || "").toLowerCase() },
        { key: "object_count", label: "Object Count", type: "num", get: o => ufNum(o.object_count) }
    ],
    tabs: [
        { key: "identity", label: "Identity", icon: "user" },
        { key: "security", label: "Security", icon: "shield" },
        { key: "activity", label: "Activity", icon: "clock" }
    ],
    layout: {
        identity: [
            { title: "Identity", kind: "text", keys: ["name", "dn"] },
            { title: "Administration", kind: "text", keys: ["description", "managed_by"] }
        ],
        security: [
            { title: "Security", kind: "tri", keys: ["tier0", "highvalue", "has_gpo_links", "inheritance_blocked", "is_protected", "isaclprotected"] }
        ],
        activity: [
            { title: "Timeline", kind: "date", keys: ["created", "modified"] },
            { title: "Counters", kind: "num", keys: ["object_count", "privileged_users_count", "privileged_computers_count"] }
        ]
    },
    knownKeys: ["name", "dn", "description", "managed_by", "tier0", "highvalue", "has_gpo_links", "inheritance_blocked", "is_protected", "isaclprotected", "object_count", "privileged_users_count", "privileged_computers_count", "created", "modified"]
};

FULL_FILTER_CONFIGS.ous = OUS_FILTER_CONFIG;

function ouName(dn) {
    if (!dn) return "";
    const match = String(dn).match(/^(?:OU|CN|DC)=((?:\\.|[^,\\])+)/i);
    return match ? match[1].replace(/\\(.)/g, "$1") : String(dn);
}

function openOuObjectsPanel(ou) {
    closeUserDetailPanel();
    const overlay = document.createElement("div");
    overlay.className = "user-detail-overlay";
    overlay.innerHTML = `
        <aside class="user-detail-panel" role="dialog" aria-modal="true" aria-label="OU objects">
            <div class="user-detail-header">
                <div class="user-detail-avatar">${esc(initials(ou.name))}</div>
                <div class="user-detail-heading">
                    <h2>${esc(ou.name || "Unknown OU")}</h2>
                    <span class="user-detail-dn">${esc(ou.dn || "")}</span>
                </div>
                <button class="user-detail-close" type="button" aria-label="Close">&times;</button>
            </div>
            <div class="user-detail-status-row"></div>
            <div class="user-detail-body">
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Objects</div>
                    <div class="group-member-list ou-objects-list"><span class="domain-muted">Loading objects...</span></div>
                </section>
            </div>
        </aside>`;
    overlay.addEventListener("mousedown", event => {
        if (event.target === overlay) closeUserDetailPanel();
    });
    overlay.querySelector(".user-detail-close").addEventListener("click", closeUserDetailPanel);
    document.body.appendChild(overlay);
    document.addEventListener("keydown", handleUserDetailKeydown);
    const listEl = overlay.querySelector(".ou-objects-list");
    Api.getDomainOuObjects(ou.dn).then(result => {
        if (!overlay.isConnected) return;
        if (!result.ok) {
            listEl.innerHTML = `<span class="domain-muted">${esc(result.error || "Failed to load objects")}</span>`;
            return;
        }
        const items = Array.isArray(result.items) ? result.items : [];
        listEl.innerHTML = items.length ? items.map(item => `
            <div class="group-member">
                <strong>${esc(item.name || shortDn(item.dn) || "Unknown")}</strong>
                <span>${esc(item.type || "Object")}</span>
                <small>${esc(item.dn || "")}</small>
            </div>`).join("") : '<span class="domain-muted">No objects in this OU</span>';
    }).catch(error => {
        if (overlay.isConnected) listEl.innerHTML = `<span class="domain-muted">${esc(error.message || "Failed to load objects")}</span>`;
    });
}

function openOuDetailPanel(ou) {
    closeUserDetailPanel();
    const kv = (label, html) => `<div class="user-detail-kv"><span>${esc(label)}</span><strong>${html}</strong></div>`;
    const text = value => value === null || value === undefined || value === ""
        ? '<span class="domain-muted">-</span>' : esc(String(value));
    const overview = [
        ["Name", text(ou.name)], ["Type", text(ou.type)], ["Path", text(ou.path)],
        ["Parent DN", text(ou.parent_dn)], ["Depth", text(ou.depth)],
        ["Objects", fmtNumber(ou.object_count)], ["Managed By", text(ou.managed_by)],
        ["Object GUID", text(ou.objectguid)], ["Domain SID", text(ou.domainsid)],
        ["Privileged Users", fmtNumber(ou.privileged_users_count)],
        ["Privileged Computers", fmtNumber(ou.privileged_computers_count)]
    ];
    const overlay = document.createElement("div");
    overlay.className = "user-detail-overlay";
    overlay.innerHTML = `
        <aside class="user-detail-panel" role="dialog" aria-modal="true" aria-label="OU details">
            <div class="user-detail-header">
                <div class="user-detail-avatar">${esc(initials(ou.name))}</div>
                <div class="user-detail-heading"><h2>${esc(ou.name || "Unknown OU")}</h2><span class="user-detail-dn">${esc(ou.dn || "")}</span></div>
                <button class="user-detail-close" type="button" aria-label="Close">&times;</button>
            </div>
            <div class="user-detail-status-row">
                ${ou.tier0 ? badge("Tier-0", "admin-high") : ""}
                ${ou.highvalue ? badge("High Value", "danger") : ""}
                ${ou.has_gpo_links ? badge("GPO Linked", "info") : badge("No GPO Links", "muted")}
            </div>
            <div class="user-detail-body">
                <section class="user-detail-section"><div class="user-detail-section-title">OU Overview</div><div class="user-detail-grid">${overview.map(([label, html]) => kv(label, html)).join("")}</div></section>
                ${ou.description ? `<section class="user-detail-section"><div class="user-detail-section-title">Description</div><p>${esc(ou.description)}</p></section>` : ""}
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Security Flags</div>
                    <div class="domain-flag-list">
                        ${detailFlag("Tier-0", !!ou.tier0)}
                        ${detailFlag("High Value", !!ou.highvalue)}
                        ${detailFlag("GPO Links", !!ou.has_gpo_links, "info")}
                        ${detailFlag("Inheritance Blocked", !!ou.inheritance_blocked || !!ou.blocksinheritance, "warn")}
                        ${detailFlag("Protected", !!ou.is_protected, "info")}
                        ${detailFlag("ACL Protected", !!ou.isaclprotected, "info")}
                    </div>
                </section>
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Objects</div>
                    <button type="button" class="domain-members-button ou-detail-objects-button"><span>View objects</span></button>
                </section>
            </div>
        </aside>`;
    overlay.addEventListener("mousedown", event => {
        if (event.target === overlay) closeUserDetailPanel();
    });
    overlay.querySelector(".user-detail-close").addEventListener("click", closeUserDetailPanel);
    overlay.querySelector(".ou-detail-objects-button").addEventListener("click", () => openOuObjectsPanel(ou));
    document.body.appendChild(overlay);
    document.addEventListener("keydown", handleUserDetailKeydown);
}

(function initOusViewAnimations() {
    function pulseCount(root) {
        const el = root.querySelector(".domain-count");
        if (!el) return;
        const current = el.textContent;
        if (el.dataset.ouLast === current) return;
        el.dataset.ouLast = current;
        el.classList.remove("ou-count-pulse");
        void el.offsetWidth;
        el.classList.add("ou-count-pulse");
    }

    function staggerRows(root) {
        const rows = root.querySelectorAll(".domain-table-body tr");
        rows.forEach((row, index) => {
            row.style.setProperty("--row-index", String(Math.min(index, 24)));
            row.classList.add("ou-row-in");
        });
    }

    function markFilterReady(root) {
        const filter = root.querySelector(".entity-filter");
        if (filter) filter.classList.add("ou-filter-ready");
    }

    function enhance(root) {
        pulseCount(root);
        staggerRows(root);
        markFilterReady(root);
    }

    function attach(root) {
        if (root.dataset.ouWatching) return;
        root.dataset.ouWatching = "1";
        enhance(root);
        loadStats(root);
        const body = root.querySelector(".domain-table-body");
        const count = root.querySelector(".domain-count");
        [body, count].filter(Boolean).forEach(target => {
            new MutationObserver(() => enhance(root)).observe(target, { childList: true, characterData: true, subtree: true });
        });
    }

    const STAT_ICONS = {
        crown: '<path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5L3 8z"/>',
        nested: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z"/><path d="M9 12l2 2 4-4"/>',
        link: '<path d="M9 15l6-6"/><path d="M11 6l1-1a4 4 0 015.5 5.5l-1 1"/><path d="M13 18l-1 1a4 4 0 01-5.5-5.5l1-1"/>',
        alert: '<path d="M12 3l10 18H2L12 3z"/><path d="M12 10v5M12 18v.01"/>',
        lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>'
    };

    const STAT_CARDS = [
        { label: "High Value OUs", tone: "red", icon: "crown", summaryKeys: ["highvalue_count", "highvalue_ou_count"] },
        { label: "GPO Linked", tone: "blue", icon: "link", summaryKeys: ["gpo_linked_count", "has_gpo_links_count"] },
        { label: "Inheritance Blocked", tone: "amber", icon: "alert", summaryKeys: ["inheritance_blocked_count", "blocksinheritance_count"] },
        { label: "OUs With Privileged Computers", tone: "orange", icon: "nested", summaryKeys: ["privileged_computers_ou_count", "ous_with_privileged_computers_count"] }
    ];

    function fmtInt(value) {
        return Number(value).toLocaleString("en-US");
    }

    function fmtPct(count, total) {
        if (!total) return "0%";
        const pct = count / total * 100;
        if (count > 0 && pct < 0.1) return "<0.1%";
        return (pct < 10 ? pct.toFixed(1) : Math.round(pct)) + "%";
    }

    function countUp(el, target) {
        const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        if (reduce || target < 2) {
            el.textContent = fmtInt(target);
            return;
        }
        const start = performance.now();
        const duration = 800;
        function tick(now) {
            const progress = Math.min(1, (now - start) / duration);
            const eased = 1 - Math.pow(1 - progress, 3);
            el.textContent = fmtInt(Math.round(target * eased));
            if (progress < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
    }

    function skeletonHtml() {
        return STAT_CARDS.map(() => '<div class="ou-stat ou-skel"><span></span><span></span><span></span></div>').join("");
    }

    async function fetchAllOus() {
        const size = (typeof DOMAIN_PAGE_SIZES !== "undefined" && DOMAIN_PAGE_SIZES.ous) || 500;
        const result = await Api.getDomainResults("ous", { page: 1, page_size: size });
        if (!result || !result.ok) throw new Error(result && result.error || "Unable to load OU summary");
        return result.summary && typeof result.summary === "object" ? result.summary : null;
    }

    function renderSplit(root, summary) {
        const el = root.querySelector(".ou-split");
        if (!el) return;
        const total = Number(summary && summary.total_ous) || 0;
        const linked = Number(summary && (summary.gpo_linked_count || summary.has_gpo_links_count)) || 0;
        const unlinked = Math.max(total - linked, 0);
        const tier0 = Number(summary && (summary.tier0_count || summary.tier0_ou_count)) || 0;
        const linkedPct = total ? linked / total * 100 : 0;
        el.innerHTML = `
            <div class="ou-split-bar"><span style="--w:${linkedPct.toFixed(2)}%"></span></div>
            <div class="ou-split-legend">
                <span class="ou-leg ou-leg-ok"><i></i>GPO Linked <strong>${fmtInt(linked)}</strong></span>
                <span class="ou-leg ou-leg-off"><i></i>No GPO Links <strong>${fmtInt(unlinked)}</strong></span>
                <span class="ou-leg ou-leg-red"><i></i>Tier-0 <strong>${fmtInt(tier0)}</strong></span>
            </div>`;
        requestAnimationFrame(() => el.classList.add("ou-in"));
    }

    function renderStats(root, summary) {
        const el = root.querySelector(".ou-stats");
        if (!el) return;
        const total = Number(summary && summary.total_ous) || 0;
        el.innerHTML = STAT_CARDS.map((card, index) => {
            const metaCount = summary && card.summaryKeys
                ? Number(card.summaryKeys.map(key => summary[key]).find(value => value !== undefined))
                : NaN;
            const count = Number.isFinite(metaCount) ? metaCount : 0;
            const pct = total ? count / total * 100 : 0;
            return `
            <div class="ou-stat ou-tone-${card.tone}${count === 0 ? " ou-zero" : ""}" style="--i:${index};--pct:${Math.min(100, pct).toFixed(2)}%">
                <div class="ou-stat-head">
                    <span class="ou-stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${STAT_ICONS[card.icon]}</svg></span>
                    <span class="ou-stat-label">${card.label}</span>
                </div>
                <div class="ou-stat-value" data-target="${count}">0</div>
                <div class="ou-stat-foot"><span>${fmtPct(count, total)} of OUs</span></div>
                <div class="ou-stat-bar"><span></span></div>
            </div>`;
        }).join("");
        requestAnimationFrame(() => {
            el.classList.add("ou-in");
            el.querySelectorAll(".ou-stat-value").forEach(v => countUp(v, Number(v.dataset.target) || 0));
        });
    }

    async function loadStats(root) {
        const el = root.querySelector(".ou-stats");
        if (!el) return;
        if (typeof Api === "undefined" || typeof Api.getDomainResults !== "function") {
            el.remove();
            return;
        }
        el.innerHTML = skeletonHtml();
        try {
            const summary = await fetchAllOus();
            if (!summary) {
                el.remove();
                return;
            }
            renderSplit(root, summary);
            renderStats(root, summary);
        } catch (error) {
            el.remove();
        }
    }

    function findRoot() {
        return document.querySelector('.domain-result-view[data-domain-kind="ous"]');
    }

    const existing = findRoot();
    if (existing) {
        attach(existing);
    } else {
        const bodyObserver = new MutationObserver(() => {
            const root = findRoot();
            if (root) {
                attach(root);
                bodyObserver.disconnect();
            }
        });
        bodyObserver.observe(document.body, { childList: true, subtree: true });
    }
})();