function esc(value) {
    return Util.esc(value);
}

function renderValue(value) {
    if (value === null || value === undefined || value === "") return '<span class="domain-muted">-</span>';
    if (Array.isArray(value)) {
        if (!value.length) return '<span class="domain-muted">-</span>';
        return value.map(renderValue).join(", ");
    }
    if (typeof value === "object") {
        return Object.entries(value).map((([key, item]) => `<span><b>${esc(key)}:</b> ${renderValue(item)}</span>`)).join("<br>");
    }
    return esc(String(value));
}

function badge(text, tone = "muted") {
    return `<span class="domain-badge domain-badge-${tone}">${esc(text)}</span>`;
}

const DOMAIN_PAGE_SIZES = {
    aces: 200
};

const DETAIL_PANELS = {};

const SCHEMAS = {};

const FULL_FILTER_CONFIGS = {};

let UF_COUNTER = 0;

function flagRow(flags) {
    const active = flags.filter((flag => flag.active));
    if (!active.length) return '<span class="domain-muted">None</span>';
    return `<div class="domain-flag-list">${active.map((flag => badge(flag.label, flag.tone))).join("")}</div>`;
}

function fmtDate(value) {
    if (!value) return '<span class="domain-muted">-</span>';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return esc(String(value));
    return esc(date.toLocaleString("en-US", {
        year: "numeric",
        month: "short",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit"
    }));
}

function fmtNumber(value) {
    const number = Number(value);
    return Number.isFinite(number) ? number.toLocaleString("en-US") : esc(String(value ?? "0"));
}

const FALLBACK_COLUMNS = [ {
    label: "Record",
    render: data => {
        const entries = Object.entries(data || {});
        const half = Math.ceil(entries.length / 2);
        return entries.slice(0, half).map((([key, value]) => `<strong>${esc(key)}:</strong> ${renderValue(value)}`)).join("<br>") || '<span class="domain-muted">-</span>';
    }
}, {
    label: "Details",
    render: data => {
        const entries = Object.entries(data || {});
        const half = Math.ceil(entries.length / 2);
        return entries.slice(half).map((([key, value]) => `<span><b>${esc(key)}:</b> ${renderValue(value)}</span>`)).join("<br>") || '<span class="domain-muted">-</span>';
    }
} ];

const RIGHTS_MAX_LENGTH = 35;

function rightsText(rights) {
    return Array.isArray(rights) ? rights.join(", ") : String(rights ?? "");
}

function rightsChip(rights) {
    const full = rightsText(rights);
    if (!full) return '<span class="domain-muted">-</span>';
    const shown = full.length > RIGHTS_MAX_LENGTH ? full.slice(0, RIGHTS_MAX_LENGTH) + "..." : full;
    return `<span class="right-chip right-chip-single" title="${esc(full)}">${esc(shown)}</span>`;
}

const ESC_RISK_SCORES = {
    ESC1: 9.5,
    ESC2: 8,
    ESC3: 8.5,
    ESC4: 9.3,
    ESC5: 9,
    ESC6: 8.5,
    ESC7: 9,
    ESC8: 9,
    ESC9: 7.5,
    ESC10: 7,
    ESC11: 8,
    ESC12: 5.5,
    ESC13: 7,
    ESC14: 6.5,
    ESC15: 6.8
};

function certificateFindingScore(finding) {
    const rule = String(finding && finding.rule || "").toUpperCase();
    return ESC_RISK_SCORES[rule] || 0;
}

function certificateSeverity(score) {
    if (score > 9.5) return {
        label: "Critical",
        tone: "cert-critical"
    };
    if (score >= 8) return {
        label: "High",
        tone: "cert-high"
    };
    if (score >= 6) return {
        label: "Medium",
        tone: "cert-medium"
    };
    if (score >= 4) return {
        label: "Low-Medium",
        tone: "cert-low-medium"
    };
    return {
        label: "Informational",
        tone: "muted"
    };
}

function certificateFindingRisk(finding) {
    return String(finding && finding.rule || "").toUpperCase() === "ESC1" ? {
        label: "Critical",
        tone: "cert-critical"
    } : certificateSeverity(certificateFindingScore(finding));
}

function certificateRisk(record) {
    const findings = Array.isArray(record.esc_findings) ? record.esc_findings : [];
    if (findings.some((finding => String(finding && finding.rule || "").toUpperCase() === "ESC1"))) {
        return {
            label: "Critical",
            tone: "cert-critical"
        };
    }
    const score = findings.reduce(((highest, finding) => Math.max(highest, certificateFindingScore(finding))), 0);
    return certificateSeverity(score);
}

function ufTime(value) {
    if (value === null || value === undefined || value === "") return null;
    const time = new Date(value).getTime();
    return Number.isFinite(time) && time > 0 ? time : null;
}

function ufNum(value) {
    if (value === null || value === undefined || value === "" || typeof value === "boolean") return NaN;
    return Number(value);
}

function ufHasText(value) {
    return String(value ?? "").trim() !== "";
}

function ufTextActive(rule) {
    return rule.op === "empty" || rule.op === "filled" || (Array.isArray(rule.values) ? rule.values.length > 0 : rule.value.trim() !== "");
}

function ufTextValues(rule) {
    return Array.isArray(rule.values) ? rule.values : rule.value.trim() ? [ rule.value.trim() ] : [];
}

function ufTextMatch(op, raw, needle) {
    const hay = String(raw ?? "").toLowerCase();
    const term = needle.toLowerCase();
    if (op === "empty") return hay.trim() === "";
    if (op === "filled") return hay.trim() !== "";
    if (op === "equals") return hay === term;
    if (op === "starts") return hay.startsWith(term);
    if (op === "ends") return hay.endsWith(term);
    if (op === "excludes") return !hay.includes(term);
    return hay.includes(term);
}

const UF_TEXT_OPS = [ [ "contains", "Contains" ], [ "excludes", "Excludes" ], [ "equals", "Equals" ], [ "starts", "Starts with" ], [ "ends", "Ends with" ], [ "empty", "Is empty" ], [ "filled", "Is filled" ] ];

function ufDateActive(rule) {
    return !!(rule.from || rule.to || rule.within !== "" || rule.older !== "");
}

function ufDateMatch(time, rule) {
    const day = 864e5;
    const now = Date.now();
    if (rule.older !== "" && Number.isFinite(Number(rule.older)) && time !== null && time > now - Number(rule.older) * day) return false;
    if (time === null) return !(rule.from || rule.to || rule.within !== "");
    if (rule.from && time < new Date(rule.from + "T00:00:00").getTime()) return false;
    if (rule.to && time > new Date(rule.to + "T23:59:59.999").getTime()) return false;
    if (rule.within !== "" && Number.isFinite(Number(rule.within)) && time < now - Number(rule.within) * day) return false;
    return true;
}

function ufNumActive(rule) {
    return rule.min !== "" || rule.max !== "";
}

const UF_ICON_PATHS = {
    sliders: '<path d="M4 6h10"/><path d="M18 6h2"/><circle cx="16" cy="6" r="2"/><path d="M4 12h2"/><path d="M10 12h10"/><circle cx="8" cy="12" r="2"/><path d="M4 18h10"/><path d="M18 18h2"/><circle cx="16" cy="18" r="2"/>',
    close: '<path d="M18 6 6 18"/><path d="M6 6l12 12"/>',
    chevron: '<path d="M6 9l6 6 6-6"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/>',
    funnel: '<path d="M3 4h18l-7 8v6l-4 2v-8z"/>',
    plus: '<path d="M12 5v14"/><path d="M5 12h14"/>',
    reset: '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/>',
    bolt: '<path d="M13 2 4 14h6l-1 8 9-12h-6z"/>',
    sort: '<path d="M7 7l5-5 5 5"/><path d="M7 17l5 5 5-5"/>',
    trash: '<path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>',
    users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>'
};

function ufIcon(name, size = 14) {
    const path = UF_ICON_PATHS[name] || UF_ICON_PATHS.sliders;
    return `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg>`;
}

function ufNumMatch(value, rule) {
    if (!Number.isFinite(value)) return false;
    if (rule.min !== "" && value < Number(rule.min)) return false;
    if (rule.max !== "" && value > Number(rule.max)) return false;
    return true;
}

function ufRuleValue(user, path) {
    return path.split(".").reduce(((node, key) => node === null || node === undefined ? undefined : node[key]), user);
}

function ufRuleText(value) {
    if (value === null || value === undefined) return "";
    if (Array.isArray(value)) return value.map(ufRuleText).join(", ");
    if (typeof value === "object") return JSON.stringify(value);
    return String(value);
}

function ufIsEmpty(value) {
    return value === null || value === undefined || value === "" || Array.isArray(value) && !value.length;
}

function ufIsTrue(value) {
    if (value === true || value === 1) return true;
    return typeof value === "string" && value.trim().toLowerCase() === "true";
}

function ufRuleReady(rule) {
    return rule.field.trim() !== "" && (UF_VALUELESS_OPS.includes(rule.op) || rule.value.trim() !== "");
}

function ufCompare(raw, needle, test) {
    const a = ufNum(raw);
    const b = ufNum(needle);
    if (Number.isFinite(a) && Number.isFinite(b)) return test(a, b);
    const ta = ufTime(raw);
    const tb = ufTime(needle);
    if (ta !== null && tb !== null) return test(ta, tb);
    return false;
}

function ufRuleMatch(user, rule) {
    const raw = ufRuleValue(user, rule.field.trim());
    const text = ufRuleText(raw).toLowerCase();
    const term = rule.value.trim().toLowerCase();
    switch (rule.op) {
      case "empty":
        return ufIsEmpty(raw);

      case "filled":
        return !ufIsEmpty(raw);

      case "true":
        return ufIsTrue(raw);

      case "false":
        return !ufIsTrue(raw);

      case "equals":
        return text === term;

      case "not_equals":
        return text !== term;

      case "starts":
        return text.startsWith(term);

      case "ends":
        return text.endsWith(term);

      case "not_contains":
        return !text.includes(term);

      case "gt":
        return ufCompare(raw, rule.value, ((a, b) => a > b));

      case "gte":
        return ufCompare(raw, rule.value, ((a, b) => a >= b));

      case "lt":
        return ufCompare(raw, rule.value, ((a, b) => a < b));

      case "lte":
        return ufCompare(raw, rule.value, ((a, b) => a <= b));

      case "regex":
        try {
            return new RegExp(rule.value.trim(), "i").test(ufRuleText(raw));
        } catch (error) {
            return false;
        }

      default:
        return text.includes(term);
    }
}

function ufCanonicalSortFields(config) {
    return [ {
        key: "",
        label: "Default order"
    }, ...config.sortFields || [] ];
}

function ufBuildTabs(config) {
    return [ ...config.tabs, ...config.membership ? [ {
        key: "membership",
        label: config.membership.tabLabel || "Membership",
        icon: "users"
    } ] : [], {
        key: "advanced",
        label: "Advanced",
        icon: "sliders"
    } ];
}

function ufBuildTabOf(config) {
    const tabOf = {};
    Object.entries(config.layout || {}).forEach((([tab, sections]) => {
        sections.forEach((section => section.keys.forEach((key => {
            tabOf[`${section.kind}:${key}`] = tab;
        }))));
    }));
    if (config.membership) {
        tabOf[`num:${config.membership.numField.key}`] = "membership";
        tabOf.membership = "membership";
    }
    tabOf.rule = "advanced";
    return tabOf;
}

function ufInitialFullState(config) {
    const text = {};
    config.textFields.forEach((field => {
        text[field.key] = config.multiTextFields && config.multiTextFields.includes(field.key) ? {
            op: "contains",
            values: []
        } : {
            op: "contains",
            value: ""
        };
    }));
    const tri = {};
    config.triFields.forEach((field => {
        tri[field.key] = "any";
    }));
    const date = {};
    config.dateFields.forEach((field => {
        date[field.key] = {
            from: "",
            to: "",
            within: "",
            older: ""
        };
    }));
    const num = {};
    config.numFields.forEach((field => {
        num[field.key] = {
            min: "",
            max: ""
        };
    }));
    const state = {
        text: text,
        tri: tri,
        date: date,
        num: num,
        rules: [],
        sort: {
            field: "",
            dir: "asc"
        }
    };
    if (config.membership) state.membership = {
        include: [],
        exclude: [],
        mode: "any"
    };
    return state;
}

function createAttributeFilter(root, config, onChange) {
    if (!root || !config) return null;
    const uid = `uf${++UF_COUNTER}`;
    const textMap = Object.fromEntries(config.textFields.map((field => [ field.key, field ])));
    const triMap = Object.fromEntries(config.triFields.map((field => [ field.key, field ])));
    const dateMap = Object.fromEntries(config.dateFields.map((field => [ field.key, field ])));
    const numMap = Object.fromEntries(config.numFields.map((field => [ field.key, field ])));
    const presets = config.presets || [];
    const sortFields = ufCanonicalSortFields(config);
    const tabs = ufBuildTabs(config);
    const tabOf = ufBuildTabOf(config);
    const keys = new Set(config.knownKeys || []);
    let state = ufInitialFullState(config);
    let activePresetId = null;
    let activeTab = tabs[0].key;
    let items = [];
    let timer = null;
    root.classList.add("user-filter");
    root.innerHTML = `\n        <div class="uf-bar">\n            <button type="button" class="uf-toggle" data-uf="toggle" aria-expanded="false" aria-controls="${uid}-body">\n                <span class="uf-icon">${ufIcon("funnel", 18)}</span>\n                <span class="uf-titles">\n                    <strong>Filters</strong>\n                    <small>${esc(config.subtitle || "Narrow down records by any attribute, flag, date or group")}</small>\n                </span>\n                <span class="uf-badge" hidden></span>\n                <span class="uf-chevron">${ufIcon("chevron", 18)}</span>\n            </button>\n                ${config.hideBarReset ? "" : `<button type="button" class="uf-btn uf-btn-bar" data-uf="reset" hidden>${ufIcon("reset", 13)}<span>Reset</span></button>`}\n        </div>\n        <div class="uf-active" hidden>\n            <div class="uf-active-list"></div>\n        </div>\n        <div class="uf-collapse">\n            <div class="uf-collapse-inner" id="${uid}-body" inert>\n                <div class="uf-content">\n                    ${presets.length ? `<div class="uf-presets">\n                        <span class="uf-presets-label">${ufIcon("bolt", 13)}Quick filters</span>\n                        ${presets.map((preset => `<button type="button" class="uf-preset" data-uf="preset" data-id="${preset.id}">${esc(preset.label)}</button>`)).join("")}\n                    </div>` : ""}\n                    <div class="uf-tabs" role="tablist">\n                        ${tabs.map((tab => `\n                            <button type="button" class="uf-tab" role="tab" data-uf="tab" data-tab="${tab.key}">\n                                ${ufIcon(tab.icon, 14)}<span>${esc(tab.label)}</span><em class="uf-tab-count" hidden></em>\n                            </button>`)).join("")}\n                    </div>\n                    <div class="uf-panels"></div>\n                    <div class="uf-footer">\n                        <div class="uf-sort">\n                            <span class="uf-sort-label">${ufIcon("sort", 14)}Sort by</span>\n                            <select class="uf-select" data-uf="sort-field" aria-label="Sort field">\n                                ${sortFields.map((field => `<option value="${field.key}">${esc(field.label)}</option>`)).join("")}\n                            </select>\n                            <button type="button" class="uf-btn" data-uf="sort-dir">Ascending</button>\n                        </div>\n                        <div class="uf-result"></div>\n                        <button type="button" class="uf-btn uf-btn-danger" data-uf="reset">${ufIcon("trash", 13)}<span>Reset all</span></button>\n                    </div>\n                </div>\n            </div>\n        </div>\n        <datalist id="${uid}-keys"></datalist>`;
    const inner = root.querySelector(".uf-collapse-inner");
    const panels = root.querySelector(".uf-panels");
    const badgeEl = root.querySelector(".uf-badge");
    const activeWrap = root.querySelector(".uf-active");
    const activeList = root.querySelector(".uf-active-list");
    const resultEl = root.querySelector(".uf-result");
    const sortField = root.querySelector('[data-uf="sort-field"]');
    const sortDir = root.querySelector('[data-uf="sort-dir"]');
    const datalist = root.querySelector(`#${uid}-keys`);
    const resetButtons = root.querySelectorAll('[data-uf="reset"]');
    function optionList(list, selected) {
        return list.map((([value, label]) => `<option value="${value}"${value === selected ? " selected" : ""}>${esc(label)}</option>`)).join("");
    }
    function textFieldHtml(key) {
        const field = textMap[key];
        const rule = state.text[key];
        const multi = config.multiTextFields && config.multiTextFields.includes(key);
        const valueless = rule.op === "empty" || rule.op === "filled";
        const values = ufTextValues(rule);
        return `\n            <div class="uf-field${ufTextActive(rule) ? " is-active" : ""}">\n                <label class="uf-label" for="${uid}-text-${key}">${esc(field.label)}</label>\n                <div class="uf-combo">\n                    <select class="uf-select" data-uf="text-op" data-key="${key}" aria-label="${esc(field.label)} operator">${optionList(UF_TEXT_OPS, rule.op)}</select>\n                    <input class="uf-input" id="${uid}-text-${key}" type="text" data-uf="text-val" data-key="${key}" placeholder="${esc(valueless ? "Not required" : field.placeholder || "")}" value="${esc(multi ? "" : rule.value)}" autocomplete="off" spellcheck="false"${valueless ? " disabled" : ""}>\n                    ${multi ? `<button type="button" class="uf-btn uf-text-add" data-uf="text-add" data-key="${key}" aria-label="Add ${esc(field.label)} value">+</button>` : ""}\n                </div>\n                ${multi && values.length ? `<div class="uf-text-chips">${values.map(((value, index) => `<span class="uf-chip">${esc(value)}<button type="button" data-uf="text-remove" data-key="${key}" data-index="${index}" aria-label="Remove ${esc(value)}">${ufIcon("close", 11)}</button></span>`)).join("")}</div>` : ""}\n            </div>`;
    }
    function triFieldHtml(key) {
        const field = triMap[key];
        const value = state.tri[key];
        return `\n            <div class="uf-tri uf-tone-${field.tone || "info"}" data-state="${value}">\n                <span class="uf-tri-name"><i class="uf-dot"></i>${esc(field.label)}</span>\n                <div class="uf-seg" role="group" aria-label="${esc(field.label)}">\n                    ${[ [ "any", "Any" ], [ "yes", "Yes" ], [ "no", "No" ] ].map((([val, label]) => `\n                        <button type="button" class="uf-seg-btn${value === val ? " active" : ""}" data-uf="tri" data-key="${key}" data-val="${val}" aria-pressed="${value === val}">${label}</button>`)).join("")}\n                </div>\n            </div>`;
    }
    function dateFieldHtml(key) {
        const field = dateMap[key];
        const rule = state.date[key];
        const mini = (part, label, type, placeholder) => `\n            <label class="uf-mini"><span>${label}</span>\n                <input class="uf-input" type="${type}" data-uf="date" data-key="${key}" data-part="${part}" value="${esc(rule[part])}"${placeholder ? ` placeholder="${placeholder}" min="0"` : ""}>\n            </label>`;
        return `\n            <div class="uf-card${ufDateActive(rule) ? " is-active" : ""}">\n                <div class="uf-card-title">${ufIcon("clock", 14)}${esc(field.label)}</div>\n                <div class="uf-mini-grid">\n                    ${mini("from", "From", "date")}\n                    ${mini("to", "To", "date")}\n                    ${mini("within", "Within last (days)", "number", "e.g. 30")}\n                    ${mini("older", "Older than (days)", "number", "e.g. 90")}\n                </div>\n            </div>`;
    }
    function numFieldHtml(key) {
        const field = numMap[key];
        const rule = state.num[key];
        const mini = (part, label, placeholder) => `\n            <label class="uf-mini"><span>${label}</span>\n                <input class="uf-input" type="number" min="0" data-uf="num" data-key="${key}" data-part="${part}" value="${esc(rule[part])}" placeholder="${placeholder}">\n            </label>`;
        return `\n            <div class="uf-card${ufNumActive(rule) ? " is-active" : ""}">\n                <div class="uf-card-title">${ufIcon("sliders", 14)}${esc(field.label)}</div>\n                <div class="uf-mini-grid uf-mini-grid-2">\n                    ${mini("min", "Minimum", "0")}\n                    ${mini("max", "Maximum", "no limit")}\n                </div>\n            </div>`;
    }
    function sectionHtml(section) {
        const render = {
            text: textFieldHtml,
            tri: triFieldHtml,
            date: dateFieldHtml,
            num: numFieldHtml
        }[section.kind];
        return `\n            <div class="uf-section">\n                <div class="uf-section-title"><span>${esc(section.title)}</span></div>\n                <div class="uf-grid uf-grid-${section.kind}">${section.keys.map(render).join("")}</div>\n            </div>`;
    }
    function chipsHtml(list) {
        const values = state.membership[list];
        return values.map(((term, index) => `\n            <span class="uf-chip">${esc(term)}<button type="button" data-uf="chip-remove" data-list="${list}" data-index="${index}" aria-label="Remove ${esc(term)}">${ufIcon("close", 11)}</button></span>`)).join("");
    }
    function chipBoxHtml(list, title, hint, placeholder) {
        return `\n            <div class="uf-card uf-chip-card${state.membership[list].length ? " is-active" : ""}" data-list-card="${list}">\n                <div class="uf-card-head">\n                    <div class="uf-card-title">${ufIcon("users", 14)}${esc(title)}</div>\n                    ${list === "include" ? `\n                    <div class="uf-seg uf-seg-mode" data-state="${state.membership.mode}" role="group" aria-label="Match mode">\n                        <button type="button" class="uf-seg-btn${state.membership.mode === "any" ? " active" : ""}" data-uf="group-mode" data-val="any">Any of</button>\n                        <button type="button" class="uf-seg-btn${state.membership.mode === "all" ? " active" : ""}" data-uf="group-mode" data-val="all">All of</button>\n                    </div>` : ""}\n                </div>\n                <div class="uf-chip-box">\n                    <div class="uf-chip-host" data-list="${list}">${chipsHtml(list)}</div>\n                    <input class="uf-chip-input" type="text" data-uf="chip-input" data-list="${list}" placeholder="${esc(placeholder)}" autocomplete="off" spellcheck="false">\n                </div>\n                <small class="uf-hint">${esc(hint)}</small>\n            </div>`;
    }
    function membershipPanelHtml() {
        if (!config.membership) return "";
        const m = config.membership;
        return `\n            <div class="uf-section">\n                <div class="uf-section-title"><span>${esc(m.sectionTitle || "Membership")}</span></div>\n                <div class="uf-grid uf-grid-groups">\n                    ${chipBoxHtml("include", m.includeLabel || "Member of", m.includeHint || "Press Enter or comma to add.", m.placeholder || "Type a value and press Enter")}\n                    ${chipBoxHtml("exclude", m.excludeLabel || "Not member of", m.excludeHint || "Records matching any of these are hidden.", m.placeholder || "Type a value and press Enter")}\n                </div>\n            </div>\n            <div class="uf-section">\n                <div class="uf-section-title"><span>Membership Size</span></div>\n                <div class="uf-grid uf-grid-num">${numFieldHtml(m.numField.key)}</div>\n            </div>`;
    }
    function ruleHtml(rule, index) {
        const valueless = UF_VALUELESS_OPS.includes(rule.op);
        return `\n            <div class="uf-rule${ufRuleReady(rule) ? " is-active" : ""}" data-index="${index}">\n                <input class="uf-input" type="text" list="${uid}-keys" data-uf="rule-field" data-index="${index}" placeholder="Attribute name" value="${esc(rule.field)}" autocomplete="off" spellcheck="false" aria-label="Attribute">\n                <select class="uf-select" data-uf="rule-op" data-index="${index}" aria-label="Operator">${optionList(UF_RULE_OPS, rule.op)}</select>\n                <input class="uf-input" type="text" data-uf="rule-value" data-index="${index}" placeholder="${valueless ? "Not required" : "Value"}" value="${esc(rule.value)}" autocomplete="off" spellcheck="false" aria-label="Value"${valueless ? " disabled" : ""}>\n                <button type="button" class="uf-icon-btn" data-uf="rule-remove" data-index="${index}" aria-label="Remove rule">${ufIcon("close", 14)}</button>\n            </div>`;
    }
    function rulesHtml() {
        return state.rules.length ? state.rules.map(ruleHtml).join("") : `<div class="uf-empty">${ufIcon("sliders", 22)}<strong>No custom rules yet</strong><span>Add a rule to filter on any attribute returned for this record, including nested paths such as owner.name.</span></div>`;
    }
    function advancedPanelHtml() {
        return `\n            <div class="uf-section">\n                <div class="uf-section-title"><span>Custom Attribute Rules</span>\n                    <button type="button" class="uf-btn uf-btn-accent" data-uf="rule-add">${ufIcon("plus", 13)}<span>Add rule</span></button>\n                </div>\n                <div class="uf-rules">${rulesHtml()}</div>\n                <small class="uf-hint">All rules must match. Attribute names are suggested from the loaded records.</small>\n            </div>`;
    }
    function renderPanels() {
        const html = tabs.map((tab => {
            let content = "";
            if (tab.key === "membership") content = membershipPanelHtml(); else if (tab.key === "advanced") content = advancedPanelHtml(); else content = (config.layout[tab.key] || []).map(sectionHtml).join("");
            return `<div class="uf-panel" role="tabpanel" data-panel="${tab.key}"${tab.key === activeTab ? "" : " hidden"}>${content}</div>`;
        })).join("");
        panels.innerHTML = html;
    }
    function refreshKeys() {
        datalist.innerHTML = Array.from(keys).sort().map((key => `<option value="${esc(key)}"></option>`)).join("");
    }
    function collect() {
        const list = [];
        if (activePresetId) {
            const preset = presets.find((entry => entry.id === activePresetId));
            if (preset) {
                list.push({
                    tab: "",
                    label: preset.label,
                    tone: "danger",
                    clear: () => {
                        if (typeof preset.clear === "function") preset.clear(state);
                        activePresetId = null;
                    }
                });
            }
        }
        config.textFields.forEach((field => {
            const rule = state.text[field.key];
            if (!ufTextActive(rule)) return;
            const op = UF_TEXT_OPS.find((entry => entry[0] === rule.op))[1].toLowerCase();
            const valueless = rule.op === "empty" || rule.op === "filled";
            const values = ufTextValues(rule);
            list.push({
                tab: tabOf[`text:${field.key}`],
                label: `${field.label} ${op}${valueless ? "" : ` "${values.join('" and "')}"`}`,
                clear: () => {
                    rule.op = "contains";
                    if (Array.isArray(rule.values)) rule.values = [];
                    rule.value = "";
                }
            });
        }));
        config.triFields.forEach((field => {
            const value = state.tri[field.key];
            if (value === "any") return;
            list.push({
                tab: tabOf[`tri:${field.key}`],
                label: `${field.label}: ${value === "yes" ? "Yes" : "No"}`,
                tone: field.tone,
                clear: () => {
                    state.tri[field.key] = "any";
                }
            });
        }));
        config.dateFields.forEach((field => {
            const rule = state.date[field.key];
            if (!ufDateActive(rule)) return;
            const parts = [];
            if (rule.from) parts.push(`from ${rule.from}`);
            if (rule.to) parts.push(`to ${rule.to}`);
            if (rule.within !== "") parts.push(`within last ${rule.within} days`);
            if (rule.older !== "") parts.push(`older than ${rule.older} days`);
            list.push({
                tab: tabOf[`date:${field.key}`],
                label: `${field.label}: ${parts.join(", ")}`,
                clear: () => {
                    rule.from = "";
                    rule.to = "";
                    rule.within = "";
                    rule.older = "";
                }
            });
        }));
        config.numFields.forEach((field => {
            const rule = state.num[field.key];
            if (!ufNumActive(rule)) return;
            const parts = [];
            if (rule.min !== "") parts.push(`min ${rule.min}`);
            if (rule.max !== "") parts.push(`max ${rule.max}`);
            list.push({
                tab: tabOf[`num:${field.key}`],
                label: `${field.label}: ${parts.join(", ")}`,
                clear: () => {
                    rule.min = "";
                    rule.max = "";
                }
            });
        }));
        if (config.membership) {
            if (state.membership.include.length) {
                list.push({
                    tab: "membership",
                    label: `${config.membership.includeLabel || "Member of"} ${state.membership.mode === "all" ? "all" : "any"}: ${state.membership.include.join(", ")}`,
                    clear: () => {
                        state.membership.include = [];
                    }
                });
            }
            if (state.membership.exclude.length) {
                list.push({
                    tab: "membership",
                    label: `${config.membership.excludeLabel || "Not member of"}: ${state.membership.exclude.join(", ")}`,
                    clear: () => {
                        state.membership.exclude = [];
                    }
                });
            }
        }
        state.rules.forEach((rule => {
            if (!ufRuleReady(rule)) return;
            const op = UF_RULE_OPS.find((entry => entry[0] === rule.op))[1].toLowerCase();
            list.push({
                tab: "advanced",
                label: `${rule.field.trim()} ${op}${UF_VALUELESS_OPS.includes(rule.op) ? "" : ` "${rule.value.trim()}"`}`,
                clear: () => {
                    state.rules = state.rules.filter((entry => entry !== rule));
                }
            });
        }));
        return list;
    }
    function refreshMeta() {
        items = collect();
        const total = items.length;
        badgeEl.hidden = !total;
        badgeEl.textContent = `${total} active`;
        activeWrap.hidden = !total;
        activeList.innerHTML = items.map(((item, index) => `\n            <span class="uf-active-chip${item.tone ? ` uf-tone-${item.tone}` : ""}"><span>${esc(item.label)}</span><button type="button" data-uf="item-clear" data-index="${index}" aria-label="Remove filter">${ufIcon("close", 11)}</button></span>`)).join("") + (total ? `<button type="button" class="uf-clear-all" data-uf="reset">Clear all</button>` : "");
        resetButtons.forEach((button => {
            button.hidden = button.classList.contains("uf-btn-bar") && !total && !state.sort.field;
        }));
        root.querySelectorAll(".uf-tab").forEach((button => {
            const tab = button.dataset.tab;
            const count = items.filter((item => item.tab === tab)).length;
            const counter = button.querySelector(".uf-tab-count");
            counter.hidden = !count;
            counter.textContent = String(count);
            button.classList.toggle("active", tab === activeTab);
            button.setAttribute("aria-selected", String(tab === activeTab));
        }));
        sortField.value = state.sort.field;
        sortDir.textContent = state.sort.dir === "asc" ? "Ascending" : "Descending";
        sortDir.disabled = !state.sort.field;
        root.classList.toggle("has-filters", total > 0);
    }
    function commit(immediate) {
        refreshMeta();
        clearTimeout(timer);
        if (immediate) onChange(); else timer = setTimeout(onChange, 280);
    }
    function addChip(list, input) {
        const value = input.value.replace(/,/g, "").trim();
        input.value = "";
        if (!value) return;
        const existing = state.membership[list];
        if (existing.some((term => term.toLowerCase() === value.toLowerCase()))) return;
        existing.push(value);
        root.querySelector(`.uf-chip-host[data-list="${list}"]`).innerHTML = chipsHtml(list);
        root.querySelector(`[data-list-card="${list}"]`).classList.add("is-active");
        commit(true);
    }
    function setOpen(open) {
        root.classList.toggle("open", open);
        inner.inert = !open;
        root.querySelector(".uf-toggle").setAttribute("aria-expanded", String(open));
    }
    function resetAll() {
        state = ufInitialFullState(config);
        activePresetId = null;
        renderPanels();
        commit(true);
    }
    root.addEventListener("click", (event => {
        const target = event.target.closest("[data-uf]");
        if (!target) return;
        const action = target.dataset.uf;
        const key = target.dataset.key;
        if (action === "toggle") {
            setOpen(!root.classList.contains("open"));
        } else if (action === "reset") {
            resetAll();
        } else if (action === "tab") {
            activeTab = target.dataset.tab;
            panels.querySelectorAll(".uf-panel").forEach((panel => {
                panel.hidden = panel.dataset.panel !== activeTab;
            }));
            refreshMeta();
        } else if (action === "preset") {
            const preset = presets.find((entry => entry.id === target.dataset.id));
            if (!preset) return;
            if (!config.multiPreset) state = ufInitialFullState(config);
            preset.apply(state);
            activePresetId = preset.id;
            renderPanels();
            commit(true);
        } else if (action === "tri") {
            state.tri[key] = target.dataset.val;
            const card = target.closest(".uf-tri");
            card.dataset.state = target.dataset.val;
            card.querySelectorAll(".uf-seg-btn").forEach((button => {
                const on = button === target;
                button.classList.toggle("active", on);
                button.setAttribute("aria-pressed", String(on));
            }));
            commit(true);
        } else if (action === "group-mode") {
            state.membership.mode = target.dataset.val;
            const seg = target.closest(".uf-seg");
            seg.dataset.state = target.dataset.val;
            seg.querySelectorAll(".uf-seg-btn").forEach((button => button.classList.toggle("active", button === target)));
            commit(state.membership.include.length > 1);
        } else if (action === "chip-remove") {
            const list = target.dataset.list;
            state.membership[list].splice(Number(target.dataset.index), 1);
            root.querySelector(`.uf-chip-host[data-list="${list}"]`).innerHTML = chipsHtml(list);
            root.querySelector(`[data-list-card="${list}"]`).classList.toggle("is-active", state.membership[list].length > 0);
            commit(true);
        } else if (action === "item-clear") {
            const item = items[Number(target.dataset.index)];
            if (!item) return;
            item.clear();
            renderPanels();
            commit(true);
        } else if (action === "text-add") {
            const rule = state.text[key];
            const input = target.closest(".uf-field").querySelector('[data-uf="text-val"]');
            const value = input.value.trim();
            if (!value || rule.op === "empty" || rule.op === "filled") return;
            if (!Array.isArray(rule.values)) rule.values = [];
            if (!rule.values.some((entry => entry.toLowerCase() === value.toLowerCase()))) {
                rule.values.push(value);
            }
            rule.value = "";
            renderPanels();
            commit(true);
        } else if (action === "text-remove") {
            const rule = state.text[key];
            if (Array.isArray(rule.values)) rule.values.splice(Number(target.dataset.index), 1);
            renderPanels();
            commit(true);
        } else if (action === "rule-add") {
            state.rules.push({
                field: "",
                op: "contains",
                value: ""
            });
            panels.querySelector(".uf-rules").innerHTML = rulesHtml();
            const fields = panels.querySelectorAll('[data-uf="rule-field"]');
            if (fields.length) fields[fields.length - 1].focus();
            refreshMeta();
        } else if (action === "rule-remove") {
            const [removed] = state.rules.splice(Number(target.dataset.index), 1);
            panels.querySelector(".uf-rules").innerHTML = rulesHtml();
            commit(removed ? ufRuleReady(removed) : false);
        } else if (action === "sort-dir") {
            state.sort.dir = state.sort.dir === "asc" ? "desc" : "asc";
            commit(true);
        }
    }));
    root.addEventListener("input", (event => {
        const target = event.target;
        const action = target.dataset && target.dataset.uf;
        if (!action) return;
        const key = target.dataset.key;
        if (action === "text-val") {
            if (!Array.isArray(state.text[key].values)) state.text[key].value = target.value;
            target.closest(".uf-field").classList.toggle("is-active", ufTextActive(state.text[key]));
        } else if (action === "date") {
            state.date[key][target.dataset.part] = target.value;
            target.closest(".uf-card").classList.toggle("is-active", ufDateActive(state.date[key]));
        } else if (action === "num") {
            state.num[key][target.dataset.part] = target.value;
            target.closest(".uf-card").classList.toggle("is-active", ufNumActive(state.num[key]));
        } else if (action === "rule-field" || action === "rule-value") {
            const rule = state.rules[Number(target.dataset.index)];
            rule[action === "rule-field" ? "field" : "value"] = target.value;
            target.closest(".uf-rule").classList.toggle("is-active", ufRuleReady(rule));
        } else {
            return;
        }
        commit(false);
    }));
    root.addEventListener("change", (event => {
        const target = event.target;
        const action = target.dataset && target.dataset.uf;
        if (action === "text-op") {
            const rule = state.text[target.dataset.key];
            rule.op = target.value;
            if (rule.op === "empty" || rule.op === "filled") {
                if (Array.isArray(rule.values)) rule.values = [];
                rule.value = "";
            }
            const input = target.parentElement.querySelector("input");
            const valueless = rule.op === "empty" || rule.op === "filled";
            input.disabled = valueless;
            input.placeholder = valueless ? "Not required" : textMap[target.dataset.key].placeholder || "";
            target.closest(".uf-field").classList.toggle("is-active", ufTextActive(rule));
            if (config.multiTextFields && config.multiTextFields.includes(target.dataset.key)) renderPanels();
            commit(true);
        } else if (action === "rule-op") {
            const rule = state.rules[Number(target.dataset.index)];
            rule.op = target.value;
            const input = target.closest(".uf-rule").querySelector('[data-uf="rule-value"]');
            const valueless = UF_VALUELESS_OPS.includes(rule.op);
            input.disabled = valueless;
            input.placeholder = valueless ? "Not required" : "Value";
            target.closest(".uf-rule").classList.toggle("is-active", ufRuleReady(rule));
            commit(true);
        } else if (action === "sort-field") {
            state.sort.field = target.value;
            commit(true);
        }
    }));
    root.addEventListener("keydown", (event => {
        const target = event.target;
        if (target.dataset && target.dataset.uf === "text-val" && target.closest(".uf-field").querySelector('[data-uf="text-add"]') && event.key === "Enter") {
            event.preventDefault();
            target.closest(".uf-field").querySelector('[data-uf="text-add"]').click();
            return;
        }
        if (!target.dataset || target.dataset.uf !== "chip-input") return;
        const list = target.dataset.list;
        if (event.key === "Enter" || event.key === ",") {
            event.preventDefault();
            addChip(list, target);
        } else if (event.key === "Backspace" && !target.value && state.membership[list].length) {
            state.membership[list].pop();
            root.querySelector(`.uf-chip-host[data-list="${list}"]`).innerHTML = chipsHtml(list);
            root.querySelector(`[data-list-card="${list}"]`).classList.toggle("is-active", state.membership[list].length > 0);
            commit(true);
        }
    }));
    root.addEventListener("focusout", (event => {
        const target = event.target;
        if (target.dataset && target.dataset.uf === "chip-input" && target.value.trim()) addChip(target.dataset.list, target);
    }));
    function matches(entity) {
        for (const field of config.textFields) {
            const rule = state.text[field.key];
            if (ufTextActive(rule) && !ufTextValues(rule).every((value => ufTextMatch(rule.op, field.get(entity), value)))) return false;
        }
        for (const field of config.triFields) {
            const value = state.tri[field.key];
            if (value === "any") continue;
            if (!!field.get(entity) !== (value === "yes")) return false;
        }
        for (const field of config.dateFields) {
            const rule = state.date[field.key];
            if (ufDateActive(rule) && !ufDateMatch(field.get(entity), rule)) return false;
        }
        for (const field of config.numFields) {
            const rule = state.num[field.key];
            if (ufNumActive(rule) && !ufNumMatch(field.get(entity), rule)) return false;
        }
        if (config.membership) {
            const include = state.membership.include;
            const exclude = state.membership.exclude;
            if (include.length || exclude.length) {
                const memberships = (config.membership.getList(entity) || []).map((item => String(item).toLowerCase()));
                const hit = term => memberships.some((item => item.includes(term.toLowerCase())));
                if (include.length && !(state.membership.mode === "all" ? include.every(hit) : include.some(hit))) return false;
                if (exclude.some(hit)) return false;
            }
        }
        for (const rule of state.rules) {
            if (ufRuleReady(rule) && !ufRuleMatch(entity, rule)) return false;
        }
        return true;
    }
    function apply(records) {
        return items.length ? records.filter(matches) : records.slice();
    }
    function sort(records) {
        const field = sortFields.find((entry => entry.key === state.sort.field));
        if (!field || !field.key) return records;
        const factor = state.sort.dir === "asc" ? 1 : -1;
        return records.map(((record, index) => ({
            record: record,
            index: index,
            value: field.get(record)
        }))).sort(((a, b) => {
            const aEmpty = a.value === null || a.value === undefined || a.value === "";
            const bEmpty = b.value === null || b.value === undefined || b.value === "";
            if (aEmpty && bEmpty) return a.index - b.index;
            if (aEmpty) return 1;
            if (bEmpty) return -1;
            if (a.value === b.value) return a.index - b.index;
            if (field.type === "text") return a.value.localeCompare(b.value) * factor;
            return (a.value - b.value) * factor;
        })).map((entry => entry.record));
    }
    function registerKeys(records) {
        const before = keys.size;
        records.slice(0, 300).forEach((record => {
            if (record && typeof record === "object") Object.keys(record).forEach((key => keys.add(key)));
        }));
        if (keys.size !== before) refreshKeys();
    }
    function setCounts(shown, total) {
        resultEl.innerHTML = shown === null || shown === undefined ? "" : `<strong>${fmtNumber(shown)}</strong> of <strong>${fmtNumber(total)}</strong> records match`;
    }
    renderPanels();
    refreshKeys();
    refreshMeta();
    return {
        serverSide: !!config.serverSide,
        getServerFilters: () => state,
        needsClientMode: () => !config.serverSide && (items.length > 0 || !!state.sort.field),
        apply: apply,
        sort: sort,
        registerKeys: registerKeys,
        setCounts: setCounts
    };
}

function createAceExceptionPanel(onChange) {
    const panel = document.createElement("div");
    panel.className = "uf-section ace-exception-panel";
    panel.innerHTML = `\n        <div class="uf-section-title ace-exception-header">\n            <span>Exceptions</span>\n            <div class="ace-exception-actions">\n                <button type="button" class="uf-btn ace-exception-optimize">Optimization</button>\n                <button type="button" class="uf-btn uf-btn-accent ace-exception-add" aria-label="Add exception">+ Add</button>\n            </div>\n        </div>\n        <div class="ace-exception-form" hidden>\n            <input class="uf-input" type="text" placeholder="principal_name" aria-label="Principal name exception">\n            <button type="button" class="uf-btn ace-exception-save">Add</button>\n        </div>\n        <div class="ace-exception-list"><span class="domain-muted">Loading...</span></div>`;
    const form = panel.querySelector(".ace-exception-form");
    const input = form.querySelector("input");
    const list = panel.querySelector(".ace-exception-list");
    let values = [];
    const render = () => {
        list.innerHTML = values.length ? values.map((value => `<span class="ace-exception-chip"><span>${esc(value.principal_name || value.principal_sid)}${value.principal_sid ? ` (${esc(value.principal_sid)})` : ""}</span><button type="button" data-exception="${esc(value.principal_name)}" aria-label="Remove exception">&times;</button></span>`)).join("") : '<span class="domain-muted">No exceptions</span>';
    };
    const refresh = async () => {
        try {
            const result = await Api.getAceExceptions();
            if (!result.ok) throw new Error(result.error || "Could not load exceptions");
            values = Array.isArray(result.exceptions) ? result.exceptions : [];
            render();
        } catch (error) {
            list.innerHTML = `<span class="domain-muted">${esc(error.message || "Could not load exceptions")}</span>`;
        }
    };
    const save = async () => {
        const value = input.value.trim();
        if (!value) return;
        const result = await Api.addAceException(value);
        if (!result.ok) throw new Error(result.error || "Could not save exception");
        values = result.exceptions || values;
        input.value = "";
        render();
        onChange();
    };
    panel.querySelector(".ace-exception-add").addEventListener("click", (() => {
        form.hidden = !form.hidden;
        if (!form.hidden) input.focus();
    }));
    panel.querySelector(".ace-exception-optimize").addEventListener("click", (async event => {
        const button = event.currentTarget;
        button.disabled = true;
        try {
            const result = await Api.optimizeAceExceptions();
            if (!result.ok) throw new Error(result.error || "Could not optimize exceptions");
            values = result.exceptions || values;
            render();
            onChange();
            if (result.unresolved && result.unresolved.length) {
                list.insertAdjacentHTML("beforeend", `<span class="domain-muted">Not found: ${esc(result.unresolved.join(", "))}</span>`);
            }
        } catch (error) {
            list.innerHTML = `<span class="domain-muted">${esc(error.message || "Could not optimize exceptions")}</span>`;
        } finally {
            button.disabled = false;
        }
    }));
    panel.querySelector(".ace-exception-save").addEventListener("click", (() => {
        save().catch((error => {
            list.innerHTML = `<span class="domain-muted">${esc(error.message)}</span>`;
        }));
    }));
    input.addEventListener("keydown", (event => {
        if (event.key !== "Enter") return;
        event.preventDefault();
        panel.querySelector(".ace-exception-save").click();
    }));
    list.addEventListener("click", (event => {
        const button = event.target.closest("[data-exception]");
        if (!button) return;
        Api.deleteAceException(button.dataset.exception).then((result => {
            if (!result.ok) throw new Error(result.error || "Could not delete exception");
            values = result.exceptions || [];
            render();
            onChange();
        })).catch((error => {
            list.innerHTML = `<span class="domain-muted">${esc(error.message)}</span>`;
        }));
    }));
    refresh();
    return {
        element: panel,
        setVisible: visible => {
            panel.hidden = !visible;
        },
        getValues: () => values,
        addValue: async value => {
            input.value = String(value || "").trim();
            if (!input.value) throw new Error("This ACE has no principal name");
            await save();
        }
    };
}

window.initDomainResults = function() {
    const view = document.querySelector(".domain-result-view");
    if (!view || view.dataset.initialized) return;
    view.dataset.initialized = "true";
    const kind = view.dataset.domainKind;
    if (kind === "domain") {
        initDomainSummary(view);
        return;
    }
    if (kind === "certificates") {
        initCertSummary(view);
    }
    const schema = SCHEMAS[kind];
    const columns = schema ? schema.columns : FALLBACK_COLUMNS;
    const head = view.querySelector(".domain-table-head");
    const body = view.querySelector(".domain-table-body");
    const search = view.querySelector(".domain-search");
    const dangerous = view.querySelector(".ace-dangerous-filter");
    const count = view.querySelector(".domain-count");
    let page = 1;
    const pageSize = DOMAIN_PAGE_SIZES[kind] || 50;
    let requestToken = 0;
    if (head) head.innerHTML = columns.map((column => `<th>${esc(column.label)}</th>`)).join("");
    const fullConfig = FULL_FILTER_CONFIGS[kind];
    const filterRoot = view.querySelector(".user-filter") || view.querySelector(".entity-filter");
    let filterLoadTimer = null;
    const userFilter = fullConfig ? createAttributeFilter(filterRoot, fullConfig, (() => {
        page = 1;
        scheduleLoad(true);
    })) : null;
    const entityFilter = null;
    const dataFilter = userFilter || entityFilter;
    const exceptionPanel = kind === "aces" ? createAceExceptionPanel((() => {
        page = 1;
        scheduleLoad(true, true);
    })) : null;
    if (exceptionPanel && filterRoot) {
        const content = filterRoot.querySelector(".uf-content");
        const presets = filterRoot.querySelector(".uf-presets");
        const tabs = filterRoot.querySelector(".uf-tabs");
        if (content) {
            if (presets) presets.insertAdjacentElement("afterend", exceptionPanel.element); else if (tabs) content.insertBefore(exceptionPanel.element, tabs); else content.insertBefore(exceptionPanel.element, content.firstChild);
        }
    }
    let allRecords = null;
    let allRecordsQuery = null;
    const queryHistory = new Map;
    const QUERY_LIMIT = 3;
    const QUERY_WINDOW_MS = 60 * 1e3;
    function setPagerDisabled(disabled) {
        view.querySelectorAll(".domain-prev, .domain-next").forEach((button => {
            button.disabled = disabled;
        }));
    }
    function paintError(message) {
        body.innerHTML = `<tr><td colspan="${columns.length}">${esc(message)}</td></tr>`;
        if (count) count.textContent = "";
        if (dataFilter) dataFilter.setCounts(null);
        setPagerDisabled(false);
    }
    function paintRecords(records, meta) {
        body.innerHTML = records.map(((record, index) => {
            const rowClass = schema && schema.rowClass ? schema.rowClass(record) : "";
            const clickable = schema && schema.clickable ? " domain-row-clickable" : "";
            return `<tr class="${rowClass}${clickable}" data-row-index="${index}">${columns.map((column => `<td>${column.render(record)}</td>`)).join("")}</tr>`;
        })).join("") || `<tr><td colspan="${columns.length}">No records found</td></tr>`;
        if (schema && schema.clickable) {
            body.querySelectorAll("tr[data-row-index]").forEach((row => {
                row.addEventListener("click", (() => {
                    const record = records[Number(row.dataset.rowIndex)];
                    if (kind === "groups") openGroupDetailPanel(record); else if (kind === "computers") openComputerDetailPanel(record); else if (kind === "ous") openOuDetailPanel(record); else if (kind === "gpos") openGpoDetailPanel(record); else if (kind === "trusts") openTrustDetailPanel(record); else if (kind === "aces") openAceDetailPanel(record); else if (kind === "certificates") openCertificateDetailPanel(record); else if (DETAIL_PANELS[kind]) DETAIL_PANELS[kind](record);
                }));
            }));
        }
        if (kind === "aces") {
            body.querySelectorAll("tr[data-row-index]").forEach((row => {
                row.addEventListener("contextmenu", (event => {
                    event.preventDefault();
                    event.stopPropagation();
                    const record = records[Number(row.dataset.rowIndex)];
                    const menu = document.createElement("div");
                    menu.className = "ace-context-menu";
                    menu.innerHTML = `\n                        <button type="button" data-action="copy-target">Copy Target Name</button>\n                        <button type="button" data-action="copy-principal">Copy Principal Name</button>\n                        <button type="button" data-action="add-exception">Add Exception</button>`;
                    menu.style.left = `${Math.min(event.clientX, window.innerWidth - 220)}px`;
                    menu.style.top = `${Math.min(event.clientY, window.innerHeight - 140)}px`;
                    document.body.appendChild(menu);
                    const close = () => {
                        menu.remove();
                        document.removeEventListener("click", close);
                        document.removeEventListener("contextmenu", close);
                    };
                    document.addEventListener("click", close);
                    setTimeout((() => {
                        if (menu.isConnected) document.addEventListener("contextmenu", close);
                    }), 0);
                    menu.addEventListener("click", (async menuEvent => {
                        menuEvent.stopPropagation();
                        const action = menuEvent.target.closest("[data-action]")?.dataset.action;
                        if (!action) return;
                        if (action === "copy-target" || action === "copy-principal") {
                            const value = action === "copy-target" ? record.target_name : record.principal_name;
                            if (!value) {
                                alert(`This ACE has no ${action === "copy-target" ? "target" : "principal"} name.`);
                                return;
                            }
                            try {
                                await copyText(String(value));
                                close();
                            } catch (error) {
                                alert(`Could not copy value: ${error.message || error}`);
                            }
                            return;
                        }
                        if (action === "add-exception") {
                            try {
                                await exceptionPanel.addValue(record.principal_name);
                                close();
                            } catch (error) {
                                alert(error.message || "Could not add exception");
                            }
                        }
                    }));
                }));
            }));
        }
        if (kind === "groups" || kind === "ous" || kind === "gpos") {
            body.querySelectorAll("tr[data-row-index]").forEach((row => {
                const button = row.querySelector(".domain-members-button");
                if (!button) return;
                const record = records[Number(row.dataset.rowIndex)];
                button.addEventListener("click", (event => {
                    event.stopPropagation();
                    if (kind === "groups") openGroupMembersPanel(record); else if (kind === "gpos") openGpoLinksPanel(record); else openOuObjectsPanel(record);
                }));
            }));
        }
        view.querySelector(".domain-page").textContent = `Page ${meta.page} of ${meta.pages || 1}`;
        view.querySelector(".domain-prev").disabled = meta.page <= 1;
        view.querySelector(".domain-next").disabled = meta.has_more === false ? true : meta.page >= meta.pages;
        if (count) {
            count.textContent = meta.overall !== undefined && meta.overall !== meta.total ? `${fmtNumber(meta.total)} of ${fmtNumber(meta.overall)} records` : `${fmtNumber(meta.total)} records`;
        }
    }
    async function fetchEveryRecord(query) {
        const records = [];
        let current = 1;
        let pages = 1;
        do {
            const result = kind === "aces" ? await Api.getDomainAces({
                page: current,
                page_size: 200,
                q: query
            }) : await Api.getDomainResults(kind, {
                page: current,
                page_size: 200,
                q: query
            });
            if (!result.ok) return {
                ok: false,
                error: result.error
            };
            result.items.forEach((item => records.push(kind === "aces" ? item : item.data)));
            pages = result.pages || 1;
            current += 1;
        } while (current <= pages);
        return {
            ok: true,
            records: records
        };
    }
    async function load() {
        const token = ++requestToken;
        const query = search ? search.value.trim() : "";
        const filterState = dataFilter && dataFilter.getServerFilters ? dataFilter.getServerFilters() : null;
        const queryKey = JSON.stringify({
            kind: kind,
            page: page,
            query: query,
            filterState: filterState,
            dangerous: !!(dangerous && dangerous.checked)
        });
        const now = Date.now();
        const history = (queryHistory.get(queryKey) || []).filter((timestamp => now - timestamp < QUERY_WINDOW_MS));
        if (history.length >= QUERY_LIMIT) {
            const waitFor = QUERY_WINDOW_MS - (now - history[0]);
            clearTimeout(filterLoadTimer);
            filterLoadTimer = setTimeout((() => {
                filterLoadTimer = null;
                load();
            }), waitFor);
            return;
        }
        history.push(now);
        queryHistory.set(queryKey, history);
        body.innerHTML = `<tr><td colspan="${columns.length}">\n            <div class="domain-data-loading" role="status" aria-live="polite">\n                <div class="domain-data-spinner" aria-hidden="true"></div>\n                <span>Loading records</span>\n                <div class="domain-data-dots" aria-hidden="true"><span></span><span></span><span></span></div>\n            </div>\n        </td></tr>`;
        setPagerDisabled(true);
        if (dataFilter && dataFilter.needsClientMode()) {
            if (!allRecords || allRecordsQuery !== query) {
                let loaded;
                try {
                    loaded = await fetchEveryRecord(query);
                } catch (error) {
                    if (token !== requestToken) return;
                    paintError(error.message || "Unable to load records");
                    return;
                }
                if (token !== requestToken) return;
                if (!loaded.ok) {
                    paintError(loaded.error);
                    return;
                }
                allRecords = loaded.records;
                allRecordsQuery = query;
                if (dataFilter.registerKeys) dataFilter.registerKeys(allRecords);
                if (entityFilter) {
                    entityFilter.setAvailableKeys(allRecords.reduce(((keys, record) => {
                        const visit = (value, prefix = "") => {
                            if (!value || typeof value !== "object" || Array.isArray(value)) return;
                            Object.entries(value).forEach((([key, item]) => {
                                const path = prefix ? `${prefix}.${key}` : key;
                                keys.add(path);
                                visit(item, path);
                            }));
                        };
                        visit(record);
                        return keys;
                    }), new Set));
                }
            }
            const filtered = dataFilter.sort ? dataFilter.sort(dataFilter.apply(allRecords)) : dataFilter.apply(allRecords);
            const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
            if (page > pages) page = pages;
            paintRecords(filtered.slice((page - 1) * pageSize, page * pageSize), {
                page: page,
                pages: pages,
                total: filtered.length,
                overall: allRecords.length
            });
            dataFilter.setCounts(filtered.length, allRecords.length);
            return;
        }
        const params = {
            page: page,
            page_size: pageSize,
            q: query
        };
        if (dataFilter && dataFilter.serverSide) {
            params.filters = JSON.stringify(dataFilter.getServerFilters());
        }
        let result;
        try {
            if (kind === "aces") {
                params.dangerous = dangerous && dangerous.checked ? "1" : "0";
                result = await Api.getDomainAces(params);
            } else {
                if (schema && schema.sort) {
                    params.sort = schema.sort.field;
                    params.dir = schema.sort.dir;
                }
                result = await Api.getDomainResults(kind, params);
            }
        } catch (error) {
            if (token !== requestToken) return;
            paintError(error.message || "Unable to load records");
            return;
        }
        if (token !== requestToken) return;
        if (!result.ok) {
            paintError(result.error);
            return;
        }
        const records = result.items.map((item => kind === "aces" ? item : item.data));
        if (dataFilter) {
            if (dataFilter.registerKeys) dataFilter.registerKeys(records);
            dataFilter.setCounts(null);
        }
        paintRecords(records, {
            page: result.page,
            pages: result.pages,
            total: result.total,
            has_more: result.has_more
        });
    }
    function scheduleLoad(invalidateRecords = false, immediate = false) {
        if (invalidateRecords) {
            allRecords = null;
            allRecordsQuery = null;
        }
        clearTimeout(filterLoadTimer);
        if (immediate) {
            filterLoadTimer = null;
            load();
            return;
        }
        filterLoadTimer = setTimeout((() => {
            filterLoadTimer = null;
            load();
        }), 3e3);
    }
    if (search) search.addEventListener("input", (() => {
        page = 1;
        scheduleLoad(true);
    }));
    if (search) search.addEventListener("keydown", (event => {
        if (event.key !== "Enter") return;
        event.preventDefault();
        page = 1;
        scheduleLoad(true, true);
    }));
    if (filterRoot) filterRoot.addEventListener("keydown", (event => {
        if (event.key !== "Enter" || event.target.tagName !== "INPUT") return;
        event.preventDefault();
        page = 1;
        scheduleLoad(true, true);
    }));
    if (dangerous) dangerous.addEventListener("change", (() => {
        page = 1;
        scheduleLoad(true);
    }));
    view.querySelector(".domain-prev").addEventListener("click", (() => {
        page -= 1;
        load();
    }));
    view.querySelector(".domain-next").addEventListener("click", (() => {
        page += 1;
        load();
    }));
    load();
};

function initials(name) {
    const clean = String(name || "").trim();
    if (!clean) return "?";
    const parts = clean.split(/[\s._-]+/).filter(Boolean);
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[1][0]).toUpperCase();
}

function shortDn(dn) {
    if (!dn) return "";
    const match = String(dn).match(/^CN=([^,]+)/i);
    return match ? match[1] : String(dn);
}

function detailFlag(label, active, tone = "danger") {
    return badge(label, active ? tone : "muted");
}

function closeUserDetailPanel() {
    const overlay = document.querySelector(".user-detail-overlay");
    if (!overlay) return;
    overlay.classList.add("closing");
    setTimeout((() => overlay.remove()), 180);
    document.removeEventListener("keydown", handleUserDetailKeydown);
}

function handleUserDetailKeydown(event) {
    if (event.key === "Escape") closeUserDetailPanel();
}

function openGroupDetailPanel(group) {
    closeUserDetailPanel();
    const members = Array.isArray(group.members) ? group.members : [];
    const memberOf = Array.isArray(group.member_of) ? group.member_of : [];
    const userCount = members.filter((member => member.is_user)).length;
    const computerCount = members.filter((member => member.is_computer)).length;
    const groupCount = members.filter((member => member.is_group)).length;
    const highAdmin = !!group.absolute_admin || !!group.nested_admin;
    const kv = (label, html) => `\n        <div class="user-detail-kv">\n            <span>${esc(label)}</span>\n            <strong>${html}</strong>\n        </div>`;
    const text = value => value === null || value === undefined || value === "" ? '<span class="domain-muted">-</span>' : esc(String(value));
    const overview = [ [ "Group Name", text(group.group_name) ], [ "SID", text(group.group_sid) ], [ "RID", text(group.rid) ], [ "Primary Group Token", text(group.primary_group_token) ], [ "Domain SID", text(group.domainsid) ], [ "Group Type", text(groupTypeLabel(group.group_type)) ], [ "Managed By", text(group.managed_by) ], [ "Members", esc(fmtNumber(group.member_count)) ] ];
    const timeline = [ [ "Created", fmtDate(group.when_created) ], [ "Changed", fmtDate(group.when_changed) ] ];
    const overlay = document.createElement("div");
    overlay.className = "user-detail-overlay";
    overlay.innerHTML = `\n        <aside class="user-detail-panel" role="dialog" aria-modal="true" aria-label="Group details">\n            <div class="user-detail-header">\n                <div class="user-detail-avatar">${esc(initials(group.group_name))}</div>\n                <div class="user-detail-heading">\n                    <h2>${esc(group.group_name || "Unknown group")}</h2>\n                    <span class="user-detail-dn">${esc(group.group_dn || "")}</span>\n                </div>\n                <button class="user-detail-close" type="button" aria-label="Close">&times;</button>\n            </div>\n            <div class="user-detail-status-row">\n                ${group.is_privileged ? badge("Privileged", "danger") : badge("Not Privileged", "muted")}\n                ${highAdmin ? badge("Tier-0 Admin", "admin-high") : ""}\n                ${!highAdmin && group.potential_admin ? badge("Potential Admin", "admin-potential") : ""}\n                ${badge(`${fmtNumber(group.member_count)} member${Number(group.member_count) === 1 ? "" : "s"}`, "info")}\n            </div>\n            <div class="user-detail-body">\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Group Overview</div>\n                    <div class="user-detail-grid">\n                        ${overview.map((([label, html]) => kv(label, html))).join("")}\n                    </div>\n                </section>\n                ${group.description ? `\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Description</div>\n                    <p>${esc(group.description)}</p>\n                </section>` : ""}\n                ${group.info ? `\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Notes</div>\n                    <p>${esc(group.info)}</p>\n                </section>` : ""}\n                ${group.admin_description ? `\n                <section class="user-detail-section user-admin-description">\n                    <div class="user-detail-section-title">Admin Description</div>\n                    <p>${esc(group.admin_description)}</p>\n                    ${group.admin_evidence ? `<div class="user-detail-evidence"><span>Evidence</span><strong>${esc(group.admin_evidence)}</strong></div>` : ""}\n                </section>` : ""}\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Security Flags</div>\n                    <div class="domain-flag-list">\n                        ${detailFlag("Privileged", !!group.is_privileged)}\n                        ${detailFlag("Absolute Admin", !!group.absolute_admin)}\n                        ${detailFlag("Nested Admin", !!group.nested_admin)}\n                        ${detailFlag("Potential Admin", !!group.potential_admin, "warn")}\n                        ${detailFlag("Admin Count", !!group.admin_count, "warn")}\n                        ${detailFlag("Protected", !!group.is_protected, "info")}\n                        ${detailFlag("ACL Protected", !!group.isaclprotected, "info")}\n                        ${detailFlag("Critical System Object", !!group.is_critical_system_object, "info")}\n                        ${detailFlag("Security Enabled", !!group.security_enabled, "ok")}\n                        ${detailFlag("Nested Group", !!group.is_nested, "info")}\n                        ${detailFlag("Empty", !!group.is_empty, "info")}\n                    </div>\n                </section>\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Timeline</div>\n                    <div class="user-detail-grid">\n                        ${timeline.map((([label, html]) => kv(label, html))).join("")}\n                    </div>\n                </section>\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Member Of</div>\n                    <div class="domain-chip-list">\n                        ${memberOf.length ? memberOf.map((g => `<span class="domain-chip">${esc(shortDn(g))}</span>`)).join("") : '<span class="domain-muted">This group is not a member of any other group</span>'}\n                    </div>\n                </section>\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Members</div>\n                    <div class="domain-flag-list">\n                        ${badge(`${fmtNumber(userCount)} user${userCount === 1 ? "" : "s"}`, "muted")}\n                        ${badge(`${fmtNumber(computerCount)} computer${computerCount === 1 ? "" : "s"}`, "muted")}\n                        ${badge(`${fmtNumber(groupCount)} group${groupCount === 1 ? "" : "s"}`, "muted")}\n                    </div>\n                    <div class="group-member-list" style="margin-top:12px">\n                        ${members.length ? members.map((member => `\n                            <div class="group-member">\n                                <strong>${esc(member.member_name || shortDn(member.member_dn) || "Unknown")}</strong>\n                                <span>${member.is_group ? "Group" : member.is_computer ? "Computer" : "User"}</span>\n                                <small>${esc(member.member_dn || member.member_sid || "")}</small>\n                            </div>`)).join("") : '<span class="domain-muted">No members reported</span>'}\n                    </div>\n                </section>\n            </div>\n        </aside>`;
    overlay.addEventListener("mousedown", (event => {
        if (event.target === overlay) closeUserDetailPanel();
    }));
    overlay.querySelector(".user-detail-close").addEventListener("click", closeUserDetailPanel);
    document.body.appendChild(overlay);
    document.addEventListener("keydown", handleUserDetailKeydown);
}

function certificateLabel(key) {
    return String(key).replace(/([a-z])([A-Z])/g, "$1 $2").replace(/[-_]+/g, " ").replace(/\b\w/g, (char => char.toUpperCase()));
}

function openCertificateDetailPanel(certificate) {
    closeUserDetailPanel();
    const raw = certificate.raw && typeof certificate.raw === "object" ? certificate.raw : {};
    const acl = Array.isArray(certificate.acl) ? certificate.acl : [];
    const findings = Array.isArray(certificate.esc_findings) ? certificate.esc_findings : [];
    const hygieneFindings = Array.isArray(certificate.hygiene_findings) ? certificate.hygiene_findings : [];
    const kv = (label, html) => `\n        <div class="user-detail-kv">\n            <span>${esc(label)}</span>\n            <strong>${html}</strong>\n        </div>`;
    const text = value => value === null || value === undefined || value === "" ? '<span class="domain-muted">-</span>' : renderValue(value);
    const rawEntries = Object.entries(raw);
    const overview = [ [ "Name", text(certificate.name || raw.cn) ], [ "Display Name", text(raw.displayName) ], [ "Record Type", text(certificate.record_type) ], [ "Distinguished Name", text(certificate.dn || raw.distinguishedName) ], [ "Object GUID", text(raw.objectGUID) ], [ "Template OID", text(raw["msPKI-Cert-Template-OID"]) ], [ "Finding Count", fmtNumber(certificate.finding_count) ], [ "ACL Entries", fmtNumber(acl.length) ] ];
    const findingItems = findings.map((item => {
        const values = item && typeof item === "object" ? Object.entries(item) : [ [ "Finding", item ] ];
        const score = certificateFindingScore(item);
        const risk = certificateFindingRisk(item);
        return `<div class="group-member">\n            <strong>${esc(item && typeof item === "object" ? item.rule || item.name || "ESC finding" : "ESC finding")} ${badge(`${score.toFixed(1)} · ${risk.label}`, risk.tone)}</strong>\n            <small>${values.map((([key, value]) => `${esc(certificateLabel(key))}: ${renderValue(value)}`)).join(" · ")}</small>\n        </div>`;
    })).join("");
    const aclItems = acl.map((entry => `\n        <div class="group-member">\n            <strong>${esc(entry.principal_name || entry.principal_sid || "Unknown principal")}</strong>\n            <span>${esc(entry.principal_scope || "Unknown scope")}</span>\n            <small>${renderValue(entry.rights)}${entry.dangerous_ace ? " · Dangerous ACE" : ""}</small>\n        </div>`)).join("");
    const overlay = document.createElement("div");
    overlay.className = "user-detail-overlay";
    overlay.innerHTML = `\n        <aside class="user-detail-panel" role="dialog" aria-modal="true" aria-label="Certificate details">\n            <div class="user-detail-header">\n                <div class="user-detail-avatar">${esc(initials(certificate.name || raw.cn))}</div>\n                <div class="user-detail-heading">\n                    <h2>${esc(certificate.name || raw.cn || "Unknown certificate")}</h2>\n                    <span class="user-detail-dn">${esc(certificate.dn || raw.distinguishedName || "")}</span>\n                </div>\n                <button class="user-detail-close" type="button" aria-label="Close">&times;</button>\n            </div>\n            <div class="user-detail-status-row">\n                ${badge(certificate.record_type || "Certificate", "info")}\n                ${badge(certificateRisk(certificate).label, certificateRisk(certificate).tone)}\n                ${findings.length ? badge(`${findings.length} ESC finding${findings.length === 1 ? "" : "s"}`, "danger") : badge("No ESC findings", "ok")}\n            </div>\n            <div class="user-detail-body">\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Certificate Overview</div>\n                    <div class="user-detail-grid">\n                        ${overview.map((([label, html]) => kv(label, html))).join("")}\n                    </div>\n                </section>\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Security Findings</div>\n                    <div class="group-member-list">\n                        ${findingItems || '<span class="domain-muted">No ESC findings reported</span>'}\n                    </div>\n                </section>\n                ${hygieneFindings.length ? `\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Hygiene Findings</div>\n                    <div class="domain-chip-list">${hygieneFindings.map((item => `<span class="domain-chip">${esc(typeof item === "object" ? JSON.stringify(item) : String(item))}</span>`)).join("")}</div>\n                </section>` : ""}\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Template Attributes</div>\n                    <div class="user-detail-grid">\n                        ${rawEntries.map((([key, value]) => kv(certificateLabel(key), renderValue(value)))).join("")}\n                    </div>\n                </section>\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Access Control</div>\n                    <div class="group-member-list">\n                        ${aclItems || '<span class="domain-muted">No ACL entries reported</span>'}\n                    </div>\n                </section>\n            </div>\n        </aside>`;
    overlay.addEventListener("mousedown", (event => {
        if (event.target === overlay) closeUserDetailPanel();
    }));
    overlay.querySelector(".user-detail-close").addEventListener("click", closeUserDetailPanel);
    document.body.appendChild(overlay);
    document.addEventListener("keydown", handleUserDetailKeydown);
}

function openComputerDetailPanelLegacy(computer) {
    closeUserDetailPanel();
    const disabled = !!computer.disabled;
    const isDc = !!computer.is_domain_controller;
    const highAdmin = !!computer.absolute_admin || !!computer.nested_admin;
    const role = isDc ? "Domain Controller" : computer.is_server ? "Server" : computer.is_workstation ? "Workstation" : "Unknown";
    const list = value => Array.isArray(value) ? value : [];
    const chipText = item => item !== null && typeof item === "object" ? JSON.stringify(item) : String(item);
    const chips = (items, empty) => items.length ? items.map((item => `<span class="domain-chip">${esc(chipText(item))}</span>`)).join("") : `<span class="domain-muted">${esc(empty)}</span>`;
    const kv = (label, html) => `\n        <div class="user-detail-kv">\n            <span>${esc(label)}</span>\n            <strong>${html}</strong>\n        </div>`;
    const text = value => value === null || value === undefined || value === "" ? '<span class="domain-muted">-</span>' : esc(String(value));
    const yesNo = value => value === null || value === undefined ? text(value) : value ? "Yes" : "No";
    const overview = [ [ "Computer Name", text(computer.computer_name) ], [ "DNS Name", text(computer.dns_name) ], [ "Display Name", text(computer.display_name) ], [ "SID", text(computer.sid) ], [ "Role", text(role) ], [ "Operating System", text(computer.os) ], [ "OS Version", text(computer.os_version) ], [ "Service Pack", text(computer.os_service_pack) ], [ "Location", text(computer.location) ], [ "Primary Group ID", text(computer.primary_group_id) ], [ "Domain", text(computer.domain_name) ], [ "Domain SID", text(computer.domainsid) ], [ "IPv4 Addresses", text(list(computer.ipv4_addresses).join(", ")) ], [ "IPv6 Addresses", text(list(computer.ipv6_addresses).join(", ")) ], [ "SMB Version", text(computer.smb_version) ], [ "Risk Score", text(computer.risk_score) ] ];
    const timeline = [ [ "Created", fmtDate(computer.when_created) ], [ "Changed", fmtDate(computer.when_changed) ], [ "Last Logon", fmtDate(computer.last_logon) ], [ "Password Last Set", fmtDate(computer.pwd_last_set) ], [ "LAPS Expiration", fmtDate(computer.laps_expiration) ] ];
    const delegateTo = list(computer.allowed_to_delegate_to);
    const delegateStructured = list(computer.allowed_to_delegate_to_structured);
    const rbcdNames = list(computer.rbcd_principal_names);
    const rbcdSids = list(computer.rbcd_principals);
    const rbcd = rbcdNames.length ? rbcdNames : rbcdSids;
    const overlay = document.createElement("div");
    overlay.className = "user-detail-overlay";
    overlay.innerHTML = `\n        <aside class="user-detail-panel" role="dialog" aria-modal="true" aria-label="Computer details">\n            <div class="user-detail-header">\n                <div class="user-detail-avatar${disabled ? " is-disabled" : ""}">${esc(initials(computer.computer_name || computer.display_name))}</div>\n                <div class="user-detail-heading">\n                    <h2>${esc(computer.computer_name || computer.display_name || "Unknown")}</h2>\n                    <span class="user-detail-dn">${esc(computer.dn || "")}</span>\n                </div>\n                <button class="user-detail-close" type="button" aria-label="Close">&times;</button>\n            </div>\n            <div class="user-detail-status-row">\n                ${disabled ? badge("Disabled", "muted") : badge("Enabled", "ok")}\n                ${isDc ? badge("Domain Controller", "admin-potential") : badge(role, "muted")}\n                ${highAdmin ? badge("Tier-0 Admin", "admin-high") : ""}\n                ${!highAdmin && computer.potential_admin ? badge("Potential Admin", "admin-potential") : ""}\n                ${computer.is_stale ? badge("Stale", "muted") : ""}\n            </div>\n            <div class="user-detail-body">\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Computer Overview</div>\n                    <div class="user-detail-grid">\n                        ${overview.map((([label, html]) => kv(label, html))).join("")}\n                    </div>\n                </section>\n                ${computer.description ? `\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Description</div>\n                    <p>${esc(computer.description)}</p>\n                </section>` : ""}\n                ${computer.admin_description ? `\n                <section class="user-detail-section user-admin-description">\n                    <div class="user-detail-section-title">Admin Description</div>\n                    <p>${esc(computer.admin_description)}</p>\n                    ${computer.admin_evidence ? `<div class="user-detail-evidence"><span>Evidence</span><strong>${esc(computer.admin_evidence)}</strong></div>` : ""}\n                </section>` : ""}\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Security Flags</div>\n                    <div class="domain-flag-list">\n                        ${detailFlag("Absolute Admin", !!computer.absolute_admin)}\n                        ${detailFlag("Nested Admin", !!computer.nested_admin)}\n                        ${detailFlag("Potential Admin", !!computer.potential_admin, "warn")}\n                        ${detailFlag("Potential Privileged", !!computer.potential_privileged, "warn")}\n                        ${detailFlag("Unconstrained Delegation", !!computer.unconstrained_delegation)}\n                        ${detailFlag("Constrained Delegation", !!computer.constrained_delegation, "warn")}\n                        ${detailFlag("Protocol Transition", !!computer.protocol_transition_delegation, "warn")}\n                        ${detailFlag("Trusted For Delegation", !!computer.trusted_for_delegation, "warn")}\n                        ${detailFlag("RBCD Enabled", !!computer.rbcd_enabled)}\n                        ${detailFlag("Kerberoastable", !!computer.kerberoastable, "info")}\n                        ${detailFlag("AS-REP Roastable", !!computer.asrep, "info")}\n                        ${detailFlag("Shadow Credential", !!computer.has_shadow_credential)}\n                        ${detailFlag("Has SPN", !!computer.has_spn, "info")}\n                        ${detailFlag("LAPS", !!computer.has_laps || !!computer.haslaps, "ok")}\n                        ${detailFlag("ACL Protected", !!computer.isaclprotected, "info")}\n                        ${detailFlag("Stale", !!computer.is_stale, "warn")}\n                        ${detailFlag("SMB Port Open", !!computer.smb_port_open, "info")}\n                        ${detailFlag("SMB Signing Required", !!computer.smb_signing_required, "ok")}\n                    </div>\n                </section>\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Timeline</div>\n                    <div class="user-detail-grid">\n                        ${timeline.map((([label, html]) => kv(label, html))).join("")}\n                    </div>\n                </section>\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Service Principal Names</div>\n                    <div class="domain-chip-list">${chips(list(computer.spn), "No SPNs reported")}</div>\n                </section>\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Delegation Targets</div>\n                    <div class="domain-chip-list">${chips(delegateStructured.length ? delegateStructured : delegateTo, "No delegation targets")}</div>\n                </section>\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">RBCD Principals</div>\n                    <div class="domain-chip-list">${chips(rbcd, "No RBCD principals")}</div>\n                </section>\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Risk Factors</div>\n                    <div class="domain-chip-list">${chips(list(computer.risk_factors), "No risk factors reported")}</div>\n                </section>\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">Risk Controls</div>\n                    <div class="domain-chip-list">${chips(list(computer.risk_controls), "No risk controls reported")}</div>\n                </section>\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">SID History</div>\n                    <div class="domain-chip-list">${chips(list(computer.sid_history), "No SID history")}</div>\n                </section>\n                <section class="user-detail-section">\n                    <div class="user-detail-section-title">LAPS Attributes</div>\n                    <div class="domain-chip-list">${chips(list(computer.laps_attributes), "No LAPS attributes")}</div>\n                </section>\n            </div>\n        </aside>`;
    overlay.addEventListener("mousedown", (event => {
        if (event.target === overlay) closeUserDetailPanel();
    }));
    overlay.querySelector(".user-detail-close").addEventListener("click", closeUserDetailPanel);
    document.body.appendChild(overlay);
    document.addEventListener("keydown", handleUserDetailKeydown);
}

function initCertSummary(view) {
    const root = view.querySelector("#cert-summary");
    if (!root) return;
    const ICONS = {
        server: '<rect x="3" y="4" width="18" height="7" rx="2"/><rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 7.5h.01M7 16.5h.01"/>',
        key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9"/><path d="M16 7l3 3"/>',
        shield: '<path d="M12 3l8 3v6c0 4.5-3.2 8-8 9-4.8-1-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
        link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>'
    };
    function icon(name) {
        return `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name]}</svg>`;
    }
    function value(data, fallback = "Not available") {
        if (data === null || data === undefined || data === "") return fallback;
        return esc(String(data));
    }
    function rawValue(record, key, fallback = "Not available") {
        return value(record && record.raw ? record.raw[key] : undefined, fallback);
    }
    function recordLabel(record) {
        return value(record.name || record.raw && (record.raw.cn || record.raw.displayName));
    }
    function templateCount(service) {
        const templates = service.raw ? service.raw.certificateTemplates : null;
        if (Array.isArray(templates)) return templates.length;
        return templates ? 1 : 0;
    }
    function escChips(record) {
        const findings = Array.isArray(record.esc_findings) ? record.esc_findings : [];
        if (!findings.length) return '<span class="domain-state domain-state-good">No findings</span>';
        return `<div class="domain-flag-list">${findings.map((item => badge(item.rule, "danger"))).join("")}</div>`;
    }
    function oidLabel(item) {
        const name = recordLabel(item);
        const link = rawValue(item, "msDS-OIDToGroupLink", "");
        return link ? `${name} → ${link}` : name;
    }
    function render(records) {
        const templates = records.filter((record => record.record_type === "template"));
        const services = records.filter((record => record.record_type === "enrollment_service"));
        const authorities = records.filter((record => record.record_type === "certification_authority"));
        const ntauth = records.filter((record => record.record_type === "ntauth"));
        const oids = records.filter((record => record.record_type === "oid"));
        const users = records.filter((record => record.record_type === "user_mapping"));
        const primaryCa = services[0] || authorities[0] || {};
        const findingCounts = {};
        let totalFindings = 0;
        let highRisk = 0;
        records.forEach((record => {
            const findings = Array.isArray(record.esc_findings) ? record.esc_findings : [];
            totalFindings += findings.length;
            if (certificateRisk(record).label === "High" || certificateRisk(record).label === "Critical") highRisk += 1;
            findings.forEach((finding => {
                findingCounts[finding.rule] = (findingCounts[finding.rule] || 0) + 1;
            }));
        }));
        const vulnerableTemplates = templates.filter((template => Number(template.finding_count) > 0)).length;
        const severity = totalFindings === 0 ? "info" : highRisk > 0 ? "critical" : "medium";
        const score = Math.min(100, totalFindings * 8);
        const escRules = Object.keys(findingCounts).sort();
        const stats = [ {
            tone: "blue",
            icon: "server",
            label: "Certification Authorities",
            main: String(services.length + authorities.length),
            sub: `${ntauth.length} trusted in NTAuth`
        }, {
            tone: "amber",
            icon: "key",
            label: "Certificate Templates",
            main: String(templates.length),
            sub: `${vulnerableTemplates} with ESC findings`
        }, {
            tone: totalFindings ? "red" : "green",
            icon: "shield",
            label: "ESC Findings",
            main: String(totalFindings),
            sub: `${highRisk} high risk`
        }, {
            tone: "blue",
            icon: "link",
            label: "Issuance Policy OIDs",
            main: String(oids.length),
            sub: `${users.length} weak cert mappings`
        } ];
        root.innerHTML = `\n            <div class="domain-hero domain-hero-${esc(severity)}">\n                <div class="domain-hero-main">\n                    <div class="domain-eyebrow">CERTIFICATE SERVICES OVERVIEW</div>\n                    <h1>${recordLabel(primaryCa) !== "Not available" ? recordLabel(primaryCa) : "No Enterprise CA found"}</h1>\n                    <div class="domain-hero-tags">\n                        <span class="domain-hero-tag">${icon("server")}${rawValue(primaryCa, "dNSHostName")}</span>\n                        <span class="domain-hero-tag domain-hero-tag-mono">${rawValue(primaryCa, "cACertificateDN")}</span>\n                    </div>\n                </div>\n                <div class="domain-risk domain-risk-${esc(severity)}" style="--risk-pct:${score}">\n                    <div class="domain-risk-ring"><strong>${totalFindings}</strong></div>\n                    <span>ESC findings</span>\n                    <small>${esc(severity)}</small>\n                </div>\n            </div>\n            <div class="domain-stat-grid">\n                ${stats.map(((stat, index) => `\n                <div class="domain-stat domain-stat-${stat.tone}" style="--stat-index:${index}">\n                    <div class="domain-stat-icon">${icon(stat.icon)}</div>\n                    <div class="domain-stat-body">\n                        <span>${stat.label}</span>\n                        <strong>${stat.main}</strong>\n                        <small>${stat.sub}</small>\n                    </div>\n                </div>`)).join("")}\n            </div>\n            <div class="domain-summary-grid">\n                <section class="domain-panel domain-panel-wide domain-panel-blue">\n                    <div class="domain-panel-title">Certification Authorities</div>\n                    ${services.length || authorities.length ? `<div class="domain-controller-list">${services.concat(authorities).map((service => `\n                        <div class="domain-controller">\n                            <div class="domain-controller-icon">CA</div>\n                            <div>\n                                <strong>${recordLabel(service)}</strong>\n                                <span>${rawValue(service, "dNSHostName")}</span>\n                                <span>${templateCount(service)} templates published</span>\n                            </div>\n                            <small>${escChips(service)}</small>\n                        </div>`)).join("")}</div>` : '<div class="domain-muted">No Certification Authorities reported</div>'}\n                </section>\n                <section class="domain-panel domain-panel-amber">\n                    <div class="domain-panel-title">ESC Finding Breakdown</div>\n                    <div class="domain-kv-list">${escRules.length ? escRules.map((rule => `\n                        <div class="domain-kv"><span>${esc(rule)}</span><strong>${badge(String(findingCounts[rule]), "danger")}</strong></div>`)).join("") : '<div class="domain-muted">No ESC findings detected</div>'}</div>\n                </section>\n                <section class="domain-panel domain-panel-green">\n                    <div class="domain-panel-title">NTAuth Store</div>\n                    <div class="domain-chip-list">${ntauth.length ? ntauth.map((item => `<span class="domain-chip">${recordLabel(item)}</span>`)).join("") : '<span class="domain-muted">No NTAuth-trusted certificates reported</span>'}</div>\n                </section>\n                <section class="domain-panel domain-panel-purple domain-panel-issuance-oids">\n                    <div class="domain-panel-title">Issuance Policy OIDs</div>\n                    <div class="domain-chip-list">${oids.length ? oids.map((item => `<span class="domain-chip">${oidLabel(item)}</span>`)).join("") : '<span class="domain-muted">No issuance policy OIDs reported</span>'}</div>\n                </section>\n            </div>`;
    }
    Api.getDomainResults("certificates", {
        page: 1,
        page_size: 500
    }).then((result => {
        if (!result.ok) {
            root.innerHTML = `<div class="domain-muted">${esc(result.error || "Failed to load certificate services overview")}</div>`;
            return;
        }
        render((result.items || []).map((item => item.data)));
    })).catch((error => {
        root.innerHTML = `<div class="domain-muted">${esc(error.message || "Failed to load certificate services overview")}</div>`;
    }));
}