function trustTypeLabel(trust) {
    const map = { uplevel: "Uplevel", downlevel: "Downlevel", mit: "MIT Kerberos", dce: "DCE" };
    if (trust.forest) return "Forest";
    const raw = String(trust.trust_type || "").toLowerCase();
    return map[raw] || trustLabel(raw) || "Unknown";
}

function trustDirectionBadge(trust) {
    const direction = String(trust.direction || "").toLowerCase();
    const arrows = { bidirectional: "\u21C4", inbound: "\u2192", outbound: "\u2190" };
    const labels = { bidirectional: "Bidirectional", inbound: "Inbound", outbound: "Outbound" };
    if (!labels[direction]) return badge(trustLabel(direction) || "Unknown", "muted");
    return `<div class="domain-flag-list">${badge(`${arrows[direction]} ${labels[direction]}`, direction === "bidirectional" ? "warn" : "info")}</div>`;
}

SCHEMAS.trusts = {
    columns: [
        {
            label: "Trust",
            render: d => `<strong>${esc(d.name || d.partner || "Unknown")}</strong><small>${esc(d.flat_name || "")}${d.partner && d.partner !== d.name ? ` · ${esc(d.partner)}` : ""}</small>`
        },
        { label: "Direction", render: d => trustDirectionBadge(d) },
        {
            label: "Type",
            render: d => `<div class="domain-flag-list">${badge(trustTypeLabel(d), d.forest ? "admin-potential" : "info")}</div><small>${d.transitive ? "Transitive" : "Non-transitive"}</small>`
        },
        { label: "Security", render: d => trustSecurityBadges(d).join("") },
        { label: "Last Changed", render: d => fmtDate(d.when_changed) }
    ],
    rowClass: d => d.dangerous ? "dangerous" : (!d.sid_filtering_enabled ? "flagged" : ""),
    clickable: true
};

const TRUSTS_MODULE_FILTER_CONFIG = {
    subtitle: "Narrow down trusts by any attribute or flag",
    presets: [
        { id: "dangerous", label: "Dangerous trusts", apply: s => { s.tri.dangerous = "yes"; } },
        { id: "no-sid-filtering", label: "No SID filtering", apply: s => { s.tri.sid_filtering_enabled = "no"; } },
        { id: "bidirectional", label: "Bidirectional", apply: s => { s.text.direction.op = "equals"; s.text.direction.value = "bidirectional"; } },
        { id: "forest", label: "Forest trusts", apply: s => { s.tri.forest = "yes"; } }
    ],
    textFields: [
        { key: "name", label: "Trust Name", get: t => t.name },
        { key: "partner", label: "Partner", get: t => t.partner },
        { key: "flat_name", label: "NetBIOS Name", get: t => t.flat_name },
        { key: "direction", label: "Direction", get: t => t.direction },
        { key: "trust_type", label: "Trust Type", get: t => t.trust_type },
        { key: "sid", label: "Trusted Domain SID", get: t => t.sid },
        { key: "object_guid", label: "Object GUID", get: t => t.object_guid },
        { key: "dn", label: "Distinguished Name", get: t => t.dn }
    ],
    triFields: [
        { key: "dangerous", label: "Dangerous", tone: "danger", get: t => !!t.dangerous },
        { key: "sid_filtering_enabled", label: "SID Filtering", tone: "ok", get: t => !!t.sid_filtering_enabled },
        { key: "transitive", label: "Transitive", tone: "info", get: t => !!t.transitive },
        { key: "forest", label: "Forest Trust", tone: "info", get: t => !!t.forest },
        { key: "within_forest", label: "Within Forest", tone: "info", get: t => !!t.within_forest },
        { key: "inbound", label: "Inbound", tone: "info", get: t => !!t.inbound },
        { key: "outbound", label: "Outbound", tone: "info", get: t => !!t.outbound },
        { key: "tgt_delegation_enabled", label: "TGT Delegation", tone: "danger", get: t => !!t.tgt_delegation_enabled },
        { key: "forest_wide_auth", label: "Forest-Wide Auth", tone: "warn", get: t => !!t.forest_wide_auth },
        { key: "selective_auth", label: "Selective Auth", tone: "ok", get: t => !!t.selective_auth },
        { key: "treat_as_external", label: "Treat As External", tone: "warn", get: t => !!t.treat_as_external },
        { key: "uses_rc4_encryption", label: "Uses RC4", tone: "warn", get: t => !!t.uses_rc4_encryption },
        { key: "uses_aes_keys", label: "Uses AES Keys", tone: "ok", get: t => !!t.uses_aes_keys }
    ],
    dateFields: [
        { key: "when_created", label: "Created", get: t => ufTime(t.when_created) },
        { key: "when_changed", label: "Last Changed", get: t => ufTime(t.when_changed) }
    ],
    numFields: [
        { key: "usn_created", label: "USN Created", get: t => ufNum(t.usn_created) },
        { key: "usn_changed", label: "USN Changed", get: t => ufNum(t.usn_changed) }
    ],
    sortFields: [
        { key: "name", label: "Trust Name", type: "text", get: t => String(t.name || t.partner || "").toLowerCase() },
        { key: "partner", label: "Partner", type: "text", get: t => String(t.partner || "").toLowerCase() },
        { key: "when_changed", label: "Last Changed", type: "num", get: t => ufTime(t.when_changed) }
    ],
    tabs: [
        { key: "identity", label: "Identity", icon: "user" },
        { key: "security", label: "Security", icon: "shield" },
        { key: "activity", label: "Activity", icon: "clock" }
    ],
    layout: {
        identity: [
            { title: "Trust Names", kind: "text", keys: ["name", "partner", "flat_name"] },
            { title: "Type & Direction", kind: "text", keys: ["direction", "trust_type"] },
            { title: "Identifiers", kind: "text", keys: ["sid", "object_guid", "dn"] }
        ],
        security: [
            { title: "Risk Flags", kind: "tri", keys: ["dangerous", "tgt_delegation_enabled", "forest_wide_auth", "treat_as_external", "uses_rc4_encryption"] },
            { title: "Protections", kind: "tri", keys: ["sid_filtering_enabled", "selective_auth", "uses_aes_keys", "transitive"] }
        ],
        activity: [
            { title: "Timeline", kind: "date", keys: ["when_created", "when_changed"] },
            { title: "Update Sequence", kind: "num", keys: ["usn_created", "usn_changed"] }
        ]
    },
    knownKeys: ["name", "partner", "flat_name", "direction", "trust_type", "sid", "object_guid", "dn", "dangerous", "sid_filtering_enabled", "transitive", "forest", "within_forest", "inbound", "outbound", "tgt_delegation_enabled", "forest_wide_auth", "selective_auth", "treat_as_external", "uses_rc4_encryption", "uses_aes_keys", "when_created", "when_changed", "usn_created", "usn_changed"]
};

FULL_FILTER_CONFIGS.trusts = TRUSTS_MODULE_FILTER_CONFIG;

function trustList(value) {
    if (Array.isArray(value)) return value.filter(item => item !== null && item !== undefined && item !== "");
    if (value === null || value === undefined || value === "" || value === "-") return [];
    return String(value).split(/[,;|]/).map(item => item.trim()).filter(Boolean);
}

function trustLabel(value) {
    return String(value || "").toLowerCase().split("_").filter(Boolean)
        .map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
}

function trustSecurityBadges(trust) {
    const items = [];
    items.push(trust.sid_filtering_enabled ? badge("SID Filtering", "ok") : badge("No SID Filtering", "danger"));
    if (trust.forest_wide_auth) items.push(badge("Forest-Wide Auth", "warn"));
    if (trust.selective_auth) items.push(badge("Selective Auth", "ok"));
    if (trust.tgt_delegation_enabled) items.push(badge("TGT Delegation", "danger"));
    if (trust.uses_rc4_encryption) items.push(badge("RC4", "warn"));
    if (trust.dangerous) items.push(badge("Dangerous", "danger"));
    return items;
}

function openTrustDetailPanel(trust) {
    closeUserDetailPanel();
    const kv = (label, html) => `<div class="user-detail-kv"><span>${esc(label)}</span><strong>${html}</strong></div>`;
    const text = value => value === null || value === undefined || value === "" ? '<span class="domain-muted">-</span>' : esc(String(value));
    const overview = [
        ["Name", text(trust.name)], ["NetBIOS Name", text(trust.flat_name)],
        ["Partner", text(trust.partner)], ["Direction", text(trust.direction)],
        ["Trust Type", text(trustTypeLabel(trust))], ["Trusted Domain SID", text(trust.sid)]
    ];
    const overlay = document.createElement("div");
    overlay.className = "user-detail-overlay";
    overlay.innerHTML = `
        <aside class="user-detail-panel" role="dialog" aria-modal="true" aria-label="Trust details">
            <div class="user-detail-header">
                <div class="user-detail-avatar">${esc(initials(trust.flat_name || trust.name))}</div>
                <div class="user-detail-heading"><h2>${esc(trust.name || trust.partner || "Unknown trust")}</h2><span class="user-detail-dn">${esc(trust.dn || "")}</span></div>
                <button class="user-detail-close" type="button" aria-label="Close">&times;</button>
            </div>
            <div class="user-detail-status-row">
                ${trust.dangerous ? badge("Dangerous", "danger") : ""}
                ${badge(trust.direction || "Unknown", "info")}
                ${badge(trustTypeLabel(trust), trust.forest ? "admin-potential" : "info")}
            </div>
            <div class="user-detail-body">
                <section class="user-detail-section"><div class="user-detail-section-title">Trust Overview</div><div class="user-detail-grid">${overview.map(([label, html]) => kv(label, html)).join("")}</div></section>
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Security Flags</div>
                    <div class="domain-flag-list">
                        ${detailFlag("Dangerous", !!trust.dangerous)}
                        ${detailFlag("SID Filtering", !!trust.sid_filtering_enabled, "ok")}
                        ${detailFlag("TGT Delegation", !!trust.tgt_delegation_enabled)}
                        ${detailFlag("Forest-Wide Auth", !!trust.forest_wide_auth, "warn")}
                        ${detailFlag("Selective Auth", !!trust.selective_auth, "ok")}
                        ${detailFlag("RC4 Encryption", !!trust.uses_rc4_encryption, "warn")}
                        ${detailFlag("AES Keys", !!trust.uses_aes_keys, "ok")}
                    </div>
                </section>
            </div>
        </aside>`;
    overlay.addEventListener("mousedown", event => {
        if (event.target === overlay) closeUserDetailPanel();
    });
    overlay.querySelector(".user-detail-close").addEventListener("click", closeUserDetailPanel);
    document.body.appendChild(overlay);
    document.addEventListener("keydown", handleUserDetailKeydown);
}

(function initTrustsViewAnimations() {
    function pulseCount(root) {
        const el = root.querySelector(".domain-count");
        if (!el) return;
        const current = el.textContent;
        if (el.dataset.trLast === current) return;
        el.dataset.trLast = current;
        el.classList.remove("tr-count-pulse");
        void el.offsetWidth;
        el.classList.add("tr-count-pulse");
    }

    function staggerRows(root) {
        const rows = root.querySelectorAll(".domain-table-body tr");
        rows.forEach((row, index) => {
            row.style.setProperty("--row-index", String(Math.min(index, 24)));
            row.classList.add("tr-row-in");
        });
    }

    function markFilterReady(root) {
        const filter = root.querySelector(".user-filter");
        if (filter) filter.classList.add("tr-filter-ready");
    }

    function enhance(root) {
        pulseCount(root);
        staggerRows(root);
        markFilterReady(root);
    }

    function attach(root) {
        if (root.dataset.trWatching) return;
        root.dataset.trWatching = "1";
        enhance(root);
        loadStats(root);
        const body = root.querySelector(".domain-table-body");
        const count = root.querySelector(".domain-count");
        [body, count].filter(Boolean).forEach(target => {
            new MutationObserver(() => enhance(root)).observe(target, { childList: true, characterData: true, subtree: true });
        });
    }

    const STAT_ICONS = {
        alert: '<path d="M12 3l10 18H2L12 3z"/><path d="M12 10v5M12 18v.01"/>',
        bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z"/>',
        arrow: '<path d="M4 12h14M13 6l6 6-6 6"/>',
        shuffle: '<path d="M4 7h4l8 10h4"/><path d="M4 17h4l8-10h4"/><path d="M17 4l3 3-3 3"/><path d="M17 14l3 3-3 3"/>',
        crown: '<path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5L3 8z"/>',
        key: '<circle cx="8" cy="15" r="4"/><path d="M10.5 12.5L20 3M16 7l3 3M19 4l3 3"/>'
    };

    const STAT_CARDS = [
        { label: "No SID Filtering", tone: "red", icon: "alert", summaryKeys: ["no_sid_filtering_count", "sid_filtering_disabled_count"] },
        { label: "TGT Delegation Enabled", tone: "orange", icon: "bolt", summaryKeys: ["tgt_delegation_enabled_count", "tgt_delegation_count"] },
        { label: "Forest-Wide Auth", tone: "amber", icon: "arrow", summaryKeys: ["forest_wide_auth_count"] },
        { label: "Bidirectional", tone: "blue", icon: "shuffle", summaryKeys: ["bidirectional_count"] },
        { label: "Forest Trusts", tone: "purple", icon: "crown", summaryKeys: ["forest_count", "forest_trust_count"] }
    ];

    function fmtInt(value) {
        return Number(value).toLocaleString("en-US");
    }

    function fmtPct(count, total) {
        if (!total) return "0%";
        const pct = count / total * 100;
        if (count > 0 && pct < 0.1) return "<0.1%";
        return (pct < 10 ? pct.toFixed(1) : Math.round(pct)) + "%";
    }

    function countUp(el, target) {
        const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        if (reduce || target < 2) {
            el.textContent = fmtInt(target);
            return;
        }
        const start = performance.now();
        const duration = 800;
        function tick(now) {
            const progress = Math.min(1, (now - start) / duration);
            const eased = 1 - Math.pow(1 - progress, 3);
            el.textContent = fmtInt(Math.round(target * eased));
            if (progress < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
    }

    function skeletonHtml() {
        return STAT_CARDS.map(() => '<div class="tr-stat tr-skel"><span></span><span></span><span></span></div>').join("");
    }

    async function fetchAllTrusts() {
        const size = (typeof DOMAIN_PAGE_SIZES !== "undefined" && DOMAIN_PAGE_SIZES.trusts) || 500;
        const result = await Api.getDomainResults("trusts", { page: 1, page_size: size });
        if (!result || !result.ok) throw new Error(result && result.error || "Unable to load trust summary");
        return result.summary && typeof result.summary === "object" ? result.summary : null;
    }

    function renderSplit(root, summary) {
        const el = root.querySelector(".tr-split");
        if (!el) return;
        const total = Number(summary && summary.total_trusts) || 0;
        const filtered = Number(summary && summary.sid_filtering_enabled_count) || 0;
        const notFiltered = Math.max(total - filtered, 0);
        const dangerous = Number(summary && (summary.dangerous_count || summary.dangerous_trust_count)) || 0;
        const filteredPct = total ? filtered / total * 100 : 0;
        el.innerHTML = `
            <div class="tr-split-bar"><span style="--w:${filteredPct.toFixed(2)}%"></span></div>
            <div class="tr-split-legend">
                <span class="tr-leg tr-leg-ok"><i></i>SID Filtering <strong>${fmtInt(filtered)}</strong></span>
                <span class="tr-leg tr-leg-off"><i></i>No SID Filtering <strong>${fmtInt(notFiltered)}</strong></span>
                <span class="tr-leg tr-leg-red"><i></i>Dangerous <strong>${fmtInt(dangerous)}</strong></span>
            </div>`;
        requestAnimationFrame(() => el.classList.add("tr-in"));
    }

    function renderStats(root, summary) {
        const el = root.querySelector(".tr-stats");
        if (!el) return;
        const total = Number(summary && summary.total_trusts) || 0;
        el.innerHTML = STAT_CARDS.map((card, index) => {
            const metaCount = summary && card.summaryKeys
                ? Number(card.summaryKeys.map(key => summary[key]).find(value => value !== undefined))
                : NaN;
            const count = Number.isFinite(metaCount) ? metaCount : 0;
            const pct = total ? count / total * 100 : 0;
            return `
            <div class="tr-stat tr-tone-${card.tone}${count === 0 ? " tr-zero" : ""}" style="--i:${index};--pct:${Math.min(100, pct).toFixed(2)}%">
                <div class="tr-stat-head">
                    <span class="tr-stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${STAT_ICONS[card.icon]}</svg></span>
                    <span class="tr-stat-label">${card.label}</span>
                </div>
                <div class="tr-stat-value" data-target="${count}">0</div>
                <div class="tr-stat-foot"><span>${fmtPct(count, total)} of trusts</span></div>
                <div class="tr-stat-bar"><span></span></div>
            </div>`;
        }).join("");
        requestAnimationFrame(() => {
            el.classList.add("tr-in");
            el.querySelectorAll(".tr-stat-value").forEach(v => countUp(v, Number(v.dataset.target) || 0));
        });
    }

    async function loadStats(root) {
        const el = root.querySelector(".tr-stats");
        if (!el) return;
        if (typeof Api === "undefined" || typeof Api.getDomainResults !== "function") {
            el.remove();
            return;
        }
        el.innerHTML = skeletonHtml();
        try {
            const summary = await fetchAllTrusts();
            if (!summary) {
                el.remove();
                return;
            }
            renderSplit(root, summary);
            renderStats(root, summary);
        } catch (error) {
            el.remove();
        }
    }

    function findRoot() {
        return document.querySelector('.domain-result-view[data-domain-kind="trusts"]');
    }

    const existing = findRoot();
    if (existing) {
        attach(existing);
    } else {
        const bodyObserver = new MutationObserver(() => {
            const root = findRoot();
            if (root) {
                attach(root);
                bodyObserver.disconnect();
            }
        });
        bodyObserver.observe(document.body, { childList: true, subtree: true });
    }
})();