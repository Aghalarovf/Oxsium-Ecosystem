function isDisabledUser(user) {
    return !!user.disabled || (Number(user.uac) & 2) === 2;
}

SCHEMAS.users = {
    columns: [
        {
            label: "User",
            render: d => `<strong>${esc(d.username || d.display_name || "Unknown")}</strong><small class="domain-dn-trunc" title="${esc(d.dn || "")}">${esc(d.dn || "")}</small>`
        },
        {
            label: "Status",
            render: d => isDisabledUser(d)
                ? badge("Disabled", "muted")
                : badge("Enabled", "ok")
        },
        {
            label: "Description",
            render: d => d.description ? esc(d.description) : '<span class="domain-muted">-</span>'
        },
        { label: "Last Logon", render: d => fmtDate(d.last_logon) }
    ],
    rowClass: d => {
        const isHighAdmin = !!d.absolute_admin || !!d.nested_admin;
        const isPotentialAdmin = !!d.potential_admin;
        const isRoastable = !!d.kerberoastable || !!d.asrep;
        return [
            isDisabledUser(d) ? "user-disabled" : "",
            isHighAdmin ? "user-admin-high" : (isPotentialAdmin ? "user-admin-potential" : ""),
            isRoastable ? "user-roastable" : ""
        ].filter(Boolean).join(" ");
    },
    clickable: true
};

const USERS_PRESETS = [
    { id: "all-admins", label: "All Admins", apply: s => {
        s.tri.all_admin = "yes";
    }, clear: s => { s.tri.all_admin = "any"; } },
    { id: "disabled-privileged", label: "Disabled privileged", apply: s => { s.tri.enabled = "no"; s.tri.tier0 = "yes"; } },
    { id: "roastable", label: "Roastable accounts", apply: s => { s.tri.enabled = "yes"; s.tri.roastable = "yes"; } },
    { id: "delegation", label: "Delegation enabled", apply: s => { s.tri.any_delegation = "yes"; } },
    { id: "pwd-never", label: "Password never expires", apply: s => { s.tri.enabled = "yes"; s.tri.pwd_never_expires = "yes"; } },
    { id: "pwd-not-required", label: "Password not required", apply: s => { s.tri.pwd_not_required = "yes"; } },
    { id: "inactive", label: "Inactive 90+ days", apply: s => { s.tri.enabled = "yes"; s.date.last_logon.older = "90"; } },
    { id: "never-logged", label: "Never logged on", apply: s => { s.tri.never_logged_on = "yes"; } },
    { id: "locked", label: "Locked out", apply: s => { s.tri.locked_out = "yes"; } },
    { id: "recent", label: "Created last 30 days", apply: s => { s.date.when_created.within = "30"; } }
];

const USERS_FILTER_CONFIG = {
    subtitle: "Narrow down users by any attribute, flag, date or group",
    presets: USERS_PRESETS,
    textFields: [
        { key: "username", label: "Username", placeholder: "e.g. jsmith", get: u => u.username },
        { key: "display_name", label: "Display Name", placeholder: "e.g. John Smith", get: u => u.display_name },
        { key: "upn", label: "User Principal Name", placeholder: "e.g. jsmith@corp.local", get: u => u.upn },
        { key: "description", label: "Description", placeholder: "e.g. service account", get: u => u.description },
        { key: "mail", label: "Email", placeholder: "e.g. @corp.local", get: u => u.mail },
        { key: "phone", label: "Phone", placeholder: "e.g. +1 555", get: u => u.phone },
        { key: "department", label: "Department", placeholder: "e.g. Finance", get: u => u.department },
        { key: "title", label: "Job Title", placeholder: "e.g. Engineer", get: u => u.title },
        { key: "dn", label: "Distinguished Name", placeholder: "e.g. OU=Finance", get: u => u.dn },
        { key: "sid", label: "SID", placeholder: "e.g. S-1-5-21", get: u => u.sid },
        { key: "primary_group_id", label: "Primary Group ID", placeholder: "e.g. 513", get: u => u.primary_group_id },
        { key: "domain_sid", label: "Domain SID", placeholder: "e.g. S-1-5-21", get: u => u.domain_sid },
        { key: "admin_description", label: "Admin Description", placeholder: "e.g. Domain Admins", get: u => u.admin_description },
        { key: "admin_evidence", label: "Admin Evidence", placeholder: "e.g. nested membership", get: u => u.admin_evidence }
    ],
    triFields: [
        { key: "enabled", label: "Account Enabled", tone: "ok", get: u => !isDisabledUser(u) },
        { key: "locked_out", label: "Locked Out", tone: "danger", get: u => !!u.locked_out },
        { key: "never_logged_on", label: "Never Logged On", tone: "warn", get: u => ufTime(u.last_logon) === null },
        { key: "account_never_expires", label: "Account Never Expires", tone: "info", get: u => !!u.account_never_expires },
        { key: "pwd_never_expires", label: "Password Never Expires", tone: "warn", get: u => !!u.pwd_never_expires },
        { key: "pwd_not_required", label: "Password Not Required", tone: "danger", get: u => !!u.pwd_not_required },
        { key: "must_change_pwd", label: "Must Change Password", tone: "info", get: u => !!u.must_change_pwd },
        { key: "smartcard_required", label: "Smartcard Required", tone: "ok", get: u => !!u.smartcard_required },
        { key: "has_description", label: "Has Description", tone: "info", get: u => ufHasText(u.description) },
        { key: "has_mail", label: "Has Email", tone: "info", get: u => ufHasText(u.mail) },
        { key: "has_phone", label: "Has Phone", tone: "info", get: u => ufHasText(u.phone) },
        { key: "has_department", label: "Has Department", tone: "info", get: u => ufHasText(u.department) },
        { key: "has_title", label: "Has Job Title", tone: "info", get: u => ufHasText(u.title) },
        { key: "tier0", label: "Tier-0 Admin", tone: "danger", get: u => !!u.absolute_admin || !!u.nested_admin },
        { key: "absolute_admin", label: "Absolute Admin", tone: "danger", get: u => !!u.absolute_admin },
        { key: "nested_admin", label: "Nested Admin", tone: "danger", get: u => !!u.nested_admin },
        { key: "potential_admin", label: "Potential Admin", tone: "warn", get: u => !!u.potential_admin },
        { key: "dcsync", label: "DCSync Rights", tone: "danger", get: u => !!u.dcsync },
        { key: "has_admin_description", label: "Has Admin Description", tone: "info", get: u => ufHasText(u.admin_description) },
        { key: "roastable", label: "Roastable (Any)", tone: "info", get: u => !!u.kerberoastable || !!u.asrep },
        { key: "kerberoastable", label: "Kerberoastable", tone: "info", get: u => !!u.kerberoastable },
        { key: "asrep", label: "AS-REP Roastable", tone: "info", get: u => !!u.asrep },
        { key: "any_delegation", label: "Any Delegation", tone: "warn", get: u => !!u.unconstrained_delegation || !!u.constrained_delegation },
        { key: "unconstrained_delegation", label: "Unconstrained Delegation", tone: "danger", get: u => !!u.unconstrained_delegation },
        { key: "constrained_delegation", label: "Constrained Delegation", tone: "warn", get: u => !!u.constrained_delegation }
    ],
    dateFields: [
        { key: "when_created", label: "Created", get: u => ufTime(u.when_created) },
        { key: "when_changed", label: "Last Changed", get: u => ufTime(u.when_changed) },
        { key: "last_logon", label: "Last Logon", get: u => ufTime(u.last_logon) },
        { key: "pwd_last_set", label: "Password Last Set", get: u => ufTime(u.pwd_last_set) },
        { key: "account_expires", label: "Account Expires", get: u => u.account_never_expires ? null : ufTime(u.account_expires) }
    ],
    numFields: [
        { key: "logon_count", label: "Logon Count", get: u => ufNum(u.logon_count) },
        { key: "bad_pwd_count", label: "Bad Password Count", get: u => ufNum(u.bad_pwd_count) },
        { key: "group_count", label: "Group Memberships", get: u => Array.isArray(u.member_of) ? u.member_of.length : 0 }
    ],
    sortFields: [
        { key: "username", label: "Username", type: "text", get: u => String(u.username || u.display_name || "").toLowerCase() },
        { key: "display_name", label: "Display Name", type: "text", get: u => String(u.display_name || "").toLowerCase() },
        { key: "department", label: "Department", type: "text", get: u => String(u.department || "").toLowerCase() },
        { key: "last_logon", label: "Last Logon", type: "num", get: u => ufTime(u.last_logon) },
        { key: "pwd_last_set", label: "Password Last Set", type: "num", get: u => ufTime(u.pwd_last_set) },
        { key: "when_created", label: "Created", type: "num", get: u => ufTime(u.when_created) },
        { key: "when_changed", label: "Last Changed", type: "num", get: u => ufTime(u.when_changed) },
        { key: "logon_count", label: "Logon Count", type: "num", get: u => { const n = ufNum(u.logon_count); return Number.isFinite(n) ? n : null; } },
        { key: "bad_pwd_count", label: "Bad Password Count", type: "num", get: u => { const n = ufNum(u.bad_pwd_count); return Number.isFinite(n) ? n : null; } },
        { key: "group_count", label: "Group Memberships", type: "num", get: u => Array.isArray(u.member_of) ? u.member_of.length : 0 }
    ],
    tabs: [
        { key: "identity", label: "Identity", icon: "user" },
        { key: "status", label: "Account", icon: "status" },
        { key: "security", label: "Security", icon: "shield" },
        { key: "activity", label: "Activity", icon: "clock" }
    ],
    layout: {
        identity: [
            { title: "Account Names", kind: "text", keys: ["username", "display_name", "upn", "description"] },
            { title: "Contact", kind: "text", keys: ["mail", "phone"] },
            { title: "Organization", kind: "text", keys: ["department", "title", "dn"] },
            { title: "Directory Identifiers", kind: "text", keys: ["sid", "primary_group_id", "domain_sid"] },
            { title: "Profile Completeness", kind: "tri", keys: ["has_description", "has_mail", "has_phone", "has_department", "has_title"] }
        ],
        status: [
            { title: "Account State", kind: "tri", keys: ["enabled", "locked_out", "never_logged_on", "account_never_expires"] },
            { title: "Password Policy", kind: "tri", keys: ["pwd_never_expires", "pwd_not_required", "must_change_pwd", "smartcard_required"] }
        ],
        security: [
            { title: "Administrative Rights", kind: "tri", keys: ["tier0", "absolute_admin", "nested_admin", "potential_admin", "dcsync", "has_admin_description"] },
            { title: "Roasting Exposure", kind: "tri", keys: ["roastable", "kerberoastable", "asrep"] },
            { title: "Delegation", kind: "tri", keys: ["any_delegation", "unconstrained_delegation", "constrained_delegation"] },
            { title: "Admin Analysis", kind: "text", keys: ["admin_description", "admin_evidence"] }
        ],
        activity: [
            { title: "Timeline", kind: "date", keys: ["last_logon", "pwd_last_set", "when_created", "when_changed", "account_expires"] },
            { title: "Counters", kind: "num", keys: ["logon_count", "bad_pwd_count"] }
        ]
    },
    membership: {
        tabLabel: "Groups",
        sectionTitle: "Group Membership",
        includeLabel: "Member of",
        excludeLabel: "Not member of",
        includeHint: "Press Enter or comma to add. Matches group names and distinguished names.",
        excludeHint: "Users belonging to any of these groups are hidden.",
        placeholder: "Type a group name and press Enter",
        getList: u => Array.isArray(u.member_of) ? u.member_of : [],
        numField: { key: "group_count", label: "Group Memberships" }
    },
    knownKeys: [
        "username", "display_name", "dn", "upn", "sid", "mail", "phone", "department", "title", "description",
        "primary_group_id", "domain_sid", "admin_description", "admin_evidence", "uac", "disabled",
        "when_created", "when_changed", "last_logon", "logon_count", "pwd_last_set", "bad_pwd_count",
        "account_expires", "account_never_expires", "member_of", "absolute_admin", "nested_admin",
        "potential_admin", "kerberoastable", "asrep", "unconstrained_delegation", "constrained_delegation",
        "pwd_never_expires", "pwd_not_required", "must_change_pwd", "locked_out", "smartcard_required", "dcsync"
    ]
};

function openUserDetailPanel(user) {
    closeUserDetailPanel();
    const disabled = isDisabledUser(user);
    const highAdmin = !!user.absolute_admin || !!user.nested_admin;
    const potentialAdmin = !!user.potential_admin;
    const roastable = !!user.kerberoastable || !!user.asrep;

    const overview = [
        ["Display Name", user.display_name],
        ["UPN", user.upn],
        ["SID", user.sid],
        ["Mail", user.mail],
        ["Phone", user.phone],
        ["Department", user.department],
        ["Title", user.title],
        ["Primary Group ID", user.primary_group_id],
        ["Domain SID", user.domain_sid]
    ];

    const timeline = [
        ["Created", fmtDate(user.when_created)],
        ["Changed", fmtDate(user.when_changed)],
        ["Last Logon", fmtDate(user.last_logon)],
        ["Logon Count", fmtNumber(user.logon_count)],
        ["Password Last Set", fmtDate(user.pwd_last_set)],
        ["Bad Password Count", fmtNumber(user.bad_pwd_count)],
        ["Account Expires", user.account_never_expires ? "Never" : fmtDate(user.account_expires)]
    ];

    const groups = Array.isArray(user.member_of) ? user.member_of : [];

    const overlay = document.createElement("div");
    overlay.className = "user-detail-overlay";
    overlay.innerHTML = `
        <aside class="user-detail-panel" role="dialog" aria-modal="true" aria-label="User details">
            <div class="user-detail-header">
                <div class="user-detail-avatar${disabled ? " is-disabled" : ""}">${esc(initials(user.username || user.display_name))}</div>
                <div class="user-detail-heading">
                    <h2>${esc(user.username || user.display_name || "Unknown")}</h2>
                    <span class="user-detail-dn">${esc(user.dn || "")}</span>
                </div>
                <button class="user-detail-close" type="button" aria-label="Close">&times;</button>
            </div>
            <div class="user-detail-status-row">
                ${disabled ? badge("Disabled", "muted") : badge("Enabled", "ok")}
                ${highAdmin ? badge("Tier-0 Admin", "admin-high") : ""}
                ${!highAdmin && potentialAdmin ? badge("Potential Admin", "admin-potential") : ""}
                ${roastable ? badge("Roastable", "roastable") : ""}
                ${user.dcsync ? badge("DCSync", "danger") : ""}
            </div>
            <div class="user-detail-body">
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Account Overview</div>
                    <div class="user-detail-grid">
                        ${overview.map(([label, value]) => `
                            <div class="user-detail-kv">
                                <span>${esc(label)}</span>
                                <strong>${value ? esc(String(value)) : '<span class="domain-muted">-</span>'}</strong>
                            </div>`).join("")}
                    </div>
                </section>
                ${user.admin_description ? `
                <section class="user-detail-section user-admin-description">
                    <div class="user-detail-section-title">Admin Description</div>
                    <p>${esc(user.admin_description)}</p>
                    ${user.admin_evidence ? `<div class="user-detail-evidence"><span>Evidence</span><strong>${esc(user.admin_evidence)}</strong></div>` : ""}
                </section>` : ""}
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Security Flags</div>
                    <div class="domain-flag-list">
                        ${detailFlag("Absolute Admin", !!user.absolute_admin)}
                        ${detailFlag("Nested Admin", !!user.nested_admin)}
                        ${detailFlag("Potential Admin", !!user.potential_admin, "warn")}
                        ${detailFlag("Kerberoastable", !!user.kerberoastable, "info")}
                        ${detailFlag("AS-REP Roastable", !!user.asrep, "info")}
                        ${detailFlag("Unconstrained Delegation", !!user.unconstrained_delegation)}
                        ${detailFlag("Constrained Delegation", !!user.constrained_delegation, "warn")}
                        ${detailFlag("Pwd Never Expires", !!user.pwd_never_expires, "warn")}
                        ${detailFlag("Pwd Not Required", !!user.pwd_not_required)}
                        ${detailFlag("Must Change Pwd", !!user.must_change_pwd, "info")}
                        ${detailFlag("Locked Out", !!user.locked_out)}
                        ${detailFlag("Smartcard Required", !!user.smartcard_required, "info")}
                    </div>
                </section>
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Timeline</div>
                    <div class="user-detail-grid">
                        ${timeline.map(([label, value]) => `
                            <div class="user-detail-kv">
                                <span>${esc(label)}</span>
                                <strong>${value ? esc(String(value)) : '<span class="domain-muted">-</span>'}</strong>
                            </div>`).join("")}
                    </div>
                </section>
                <section class="user-detail-section">
                    <div class="user-detail-section-title">Group Memberships</div>
                    <div class="domain-chip-list">
                        ${groups.length ? groups.map(g => `<span class="domain-chip">${esc(shortDn(g))}</span>`).join("") : '<span class="domain-muted">No group memberships reported</span>'}
                    </div>
                </section>
            </div>
        </aside>`;

    overlay.addEventListener("mousedown", event => {
        if (event.target === overlay) closeUserDetailPanel();
    });
    overlay.querySelector(".user-detail-close").addEventListener("click", closeUserDetailPanel);
    document.body.appendChild(overlay);
    document.addEventListener("keydown", handleUserDetailKeydown);
}

USERS_FILTER_CONFIG.serverSide = true;
FULL_FILTER_CONFIGS.users = USERS_FILTER_CONFIG;
DOMAIN_PAGE_SIZES.users = 200;
DETAIL_PANELS.users = openUserDetailPanel;

(function initUsersViewAnimations() {
    function pulseCount(root) {
        const el = root.querySelector(".domain-count");
        if (!el) return;
        const current = el.textContent;
        if (el.dataset.duLast === current) return;
        el.dataset.duLast = current;
        el.classList.remove("du-count-pulse");
        void el.offsetWidth;
        el.classList.add("du-count-pulse");
    }

    function staggerRows(root) {
        const rows = root.querySelectorAll(".domain-table-body tr");
        rows.forEach((row, index) => {
            row.style.setProperty("--row-index", String(Math.min(index, 24)));
            row.classList.add("du-row-in");
        });
    }

    function markFilterReady(root) {
        const filter = root.querySelector(".user-filter");
        if (filter) filter.classList.add("du-filter-ready");
    }

    function enhance(root) {
        pulseCount(root);
        staggerRows(root);
        markFilterReady(root);
    }

    function attach(root) {
        if (root.dataset.duWatching) return;
        root.dataset.duWatching = "1";
        enhance(root);
        loadStats(root);
        const body = root.querySelector(".domain-table-body");
        const count = root.querySelector(".domain-count");
        [body, count].filter(Boolean).forEach(target => {
            new MutationObserver(() => enhance(root)).observe(target, { childList: true, characterData: true, subtree: true });
        });
    }

    const STAT_ICONS = {
        crown: '<path d="M3 8l4.5 4L12 5l4.5 7L21 8l-2 11H5L3 8z"/>',
        nested: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z"/><path d="M9 12l2 2 4-4"/>',
        potential: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z"/><path d="M12 8v5M12 16v.01"/>',
        bolt: '<path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z"/>',
        target: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r=".8"/>',
        arrow: '<path d="M4 12h14M13 6l6 6-6 6"/>',
        clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        alert: '<path d="M12 3l10 18H2L12 3z"/><path d="M12 10v5M12 18v.01"/>',
        lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>'
    };

    const STAT_CARDS = [
        { label: "Absolute Admins", tone: "red", icon: "crown", summaryKeys: ["absolute_admin_counts", "absolute_admin_count"] },
        { label: "Nested Admins", tone: "orange", icon: "nested", summaryKeys: ["nested_admins_count", "nested_admin_count"] },
        { label: "Potential Admins", tone: "amber", icon: "potential", summaryKeys: ["potential_admins_count", "potential_admin_count"] },
        { label: "Roastable Users", tone: "blue", icon: "target", summaryKey: "roastable_count" },
        { label: "Password Not Required", tone: "red", icon: "alert", summaryKey: "pwd_not_required_count" }
    ];

    function fmtInt(value) {
        return Number(value).toLocaleString("en-US");
    }

    function fmtPct(count, total) {
        if (!total) return "0%";
        const pct = count / total * 100;
        if (count > 0 && pct < 0.1) return "<0.1%";
        return (pct < 10 ? pct.toFixed(1) : Math.round(pct)) + "%";
    }

    function countUp(el, target) {
        const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
        if (reduce || target < 2) {
            el.textContent = fmtInt(target);
            return;
        }
        const start = performance.now();
        const duration = 800;
        function tick(now) {
            const progress = Math.min(1, (now - start) / duration);
            const eased = 1 - Math.pow(1 - progress, 3);
            el.textContent = fmtInt(Math.round(target * eased));
            if (progress < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
    }

    function skeletonHtml() {
        return STAT_CARDS.map(() => '<div class="du-stat du-skel"><span></span><span></span><span></span></div>').join("");
    }

    async function fetchAllUsers() {
        const size = (typeof DOMAIN_PAGE_SIZES !== "undefined" && DOMAIN_PAGE_SIZES.users) || 200;
        const [result, roastable] = await Promise.all([
            Api.getDomainResults("users", { page: 1, page_size: size }),
            Api.getDomainResults("users", { page: 1, page_size: 1, filters: JSON.stringify({ tri: { roastable: "yes" } }) }).catch(() => null)
        ]);
        if (!result || !result.ok) throw new Error(result && result.error || "Unable to load user summary");
        const summary = result.summary && typeof result.summary === "object" ? result.summary : null;
        if (!summary) return null;
        const fallback = (Number(summary.kerberoastable_count) || 0) + (Number(summary.asrep_count) || 0);
        const roastableTotal = roastable && roastable.ok ? Number(roastable.total) : fallback;
        return { ...summary, roastable_count: Number.isFinite(roastableTotal) ? roastableTotal : fallback };
    }

    function renderSplit(root, summary) {
        const el = root.querySelector(".du-split");
        if (!el) return;
        const total = Number(summary && summary.total_users) || 0;
        const enabled = Number(summary && summary.enabled_users) || 0;
        const disabled = Number(summary && summary.disabled_users) || 0;
        const tier0 = Number(summary && summary.tier0_admin_count) || 0;
        const enabledPct = total ? enabled / total * 100 : 0;
        el.innerHTML = `
            <div class="du-split-bar"><span style="--w:${enabledPct.toFixed(2)}%"></span></div>
            <div class="du-split-legend">
                <span class="du-leg du-leg-ok"><i></i>Enabled <strong>${fmtInt(enabled)}</strong></span>
                <span class="du-leg du-leg-off"><i></i>Disabled <strong>${fmtInt(disabled)}</strong></span>
                <span class="du-leg du-leg-red"><i></i>Tier-0 <strong>${fmtInt(tier0)}</strong></span>
            </div>`;
        requestAnimationFrame(() => el.classList.add("du-in"));
    }

    function renderStats(root, summary) {
        const el = root.querySelector(".du-stats");
        if (!el) return;
        const total = Number(summary && summary.total_users) || 0;
        el.innerHTML = STAT_CARDS.map((card, index) => {
            const metaCount = summary && card.summaryKeys
                ? Number(card.summaryKeys.map(key => summary[key]).find(value => value !== undefined))
                : (summary && card.summaryKey ? Number(summary[card.summaryKey]) : NaN);
            const count = Number.isFinite(metaCount) ? metaCount : 0;
            const pct = total ? count / total * 100 : 0;
            return `
            <div class="du-stat du-tone-${card.tone}${count === 0 ? " du-zero" : ""}" style="--i:${index};--pct:${Math.min(100, pct).toFixed(2)}%">
                <div class="du-stat-head">
                    <span class="du-stat-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${STAT_ICONS[card.icon]}</svg></span>
                    <span class="du-stat-label">${card.label}</span>
                </div>
                <div class="du-stat-value" data-target="${count}">0</div>
                <div class="du-stat-foot"><span>${fmtPct(count, total)} of users</span></div>
                <div class="du-stat-bar"><span></span></div>
            </div>`;
        }).join("");
        requestAnimationFrame(() => {
            el.classList.add("du-in");
            el.querySelectorAll(".du-stat-value").forEach(v => countUp(v, Number(v.dataset.target) || 0));
        });
    }

    async function loadStats(root) {
        const el = root.querySelector(".du-stats");
        if (!el) return;
        if (typeof Api === "undefined" || typeof Api.getDomainResults !== "function") {
            el.remove();
            return;
        }
        el.innerHTML = skeletonHtml();
        try {
            const summary = await fetchAllUsers();
            if (!summary) {
                el.remove();
                return;
            }
            renderSplit(root, summary);
            renderStats(root, summary);
        } catch (error) {
            el.remove();
        }
    }

    function findRoot() {
        return document.querySelector('.domain-result-view[data-domain-kind="users"]');
    }

    const existing = findRoot();
    if (existing) {
        attach(existing);
    } else {
        const bodyObserver = new MutationObserver(() => {
            const root = findRoot();
            if (root) {
                attach(root);
                bodyObserver.disconnect();
            }
        });
        bodyObserver.observe(document.body, { childList: true, subtree: true });
    }
})();