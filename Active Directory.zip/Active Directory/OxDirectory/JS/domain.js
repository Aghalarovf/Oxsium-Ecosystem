function initDomainSummary(view) {
    const root = view.querySelector("#domain-summary");

    const ICONS = {
        level: '<path d="M3 20h18"/><path d="M6 20V10"/><path d="M12 20V4"/><path d="M18 20v-7"/>',
        server: '<rect x="3" y="4" width="18" height="7" rx="2"/><rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 7.5h.01M7 16.5h.01"/>',
        quota: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        shield: '<path d="M12 3l8 3v6c0 4.5-3.2 8-8 9-4.8-1-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
        crown: '<path d="M3 8l4 4 5-7 5 7 4-4-2 11H5z"/>',
        key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9"/><path d="M16 7l3 3"/>',
        lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
        globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a14 14 0 0 1 0 18a14 14 0 0 1 0-18"/>',
        schema: '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6"/><path d="M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
        naming: '<circle cx="12" cy="5" r="2.5"/><circle cx="5" cy="19" r="2.5"/><circle cx="19" cy="19" r="2.5"/><path d="M12 7.5V12M12 12l-5.5 5M12 12l5.5 5"/>',
        clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        hash: '<path d="M5 9h14M5 15h14M10 4L8 20M16 4l-2 16"/>',
        link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
        renew: '<path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15 6.7L3 16"/><path d="M3 21v-5h5"/>',
        ticket: '<path d="M3 9a2 2 0 0 0 0 6v3h18v-3a2 2 0 0 0 0-6V6H3z"/><path d="M13 7v2M13 11v2M13 15v2"/>',
        sync: '<path d="M4 12a8 8 0 0 1 14-5.3M20 12a8 8 0 0 1-14 5.3"/><path d="M18 3v4h-4M6 21v-4h4"/>',
        reverse: '<path d="M7 7h13l-3-3M17 17H4l3 3"/>',
        search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
        copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>',
        net: '<circle cx="12" cy="12" r="3"/><path d="M12 3v6M12 15v6M3 12h6M15 12h6"/>',
        cert: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M7 9h10M7 13h5"/><path d="M15 17l1 4 2-1.5 2 1.5-1-4"/>'
    };

    function icon(name) {
        return `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name]}</svg>`;
    }

    function value(data, fallback = "Not available") {
        if (data === null || data === undefined || data === "") return fallback;
        return esc(String(data));
    }

    function stateValue(state, goodLabel, badLabel, goodWhenTrue = true) {
        const good = goodWhenTrue ? !!state : !state;
        return `<span class="domain-state domain-state-${good ? "good" : "bad"}">${esc(good ? goodLabel : badLabel)}</span>`;
    }

    function policyState(state, trueLabel, falseLabel) {
        if (state === null || state === undefined) {
            return value(state);
        }
        return stateValue(state, trueLabel, falseLabel);
    }

    function passwordPropertiesLabels(rawValue) {
        const numeric = Number(rawValue);
        if (!Number.isFinite(numeric)) return value(rawValue);

        const properties = [
            [1, "Complexity required"],
            [2, "No anonymous change"],
            [4, "No clear-text change"],
            [8, "Admin lockout"],
            [16, "Reversible encryption"],
            [32, "No password change"]
        ];
        const active = properties
            .filter(([bit]) => (numeric & bit) === bit)
            .map(([bit, label]) => `<span class="domain-chip" title="Flag value ${bit}">${esc(label)}</span>`);

        return active.length ? active.join("") : `<span class="domain-muted">No properties enabled</span>`;
    }

    function passwordPolicyPanel(policy) {
        const n = v => (v === null || v === undefined || v === "" || !Number.isFinite(Number(v))) ? null : Number(v);
        const minLen = n(policy.minPwdLength);
        const history = n(policy.pwdHistoryLength);
        const lockThr = n(policy.lockoutThreshold);
        const lockDur = n(policy.lockoutDuration_mins);
        const lockWin = n(policy.lockOutObservationWindow_mins);
        const maxAge = n(policy.maxPwdAge_days);
        const minAge = n(policy.minPwdAge_days);
        const neverExpires = !!policy.maxPwdAge_never_expires;
        const complexity = policy.complexityEnabled;
        const reversible = policy.reversibleEncryption;

        let score = 0;
        if (minLen !== null) score += minLen >= 14 ? 30 : minLen >= 12 ? 25 : minLen >= 8 ? 15 : 5;
        if (complexity) score += 20;
        if (reversible === false || reversible === 0) score += 15;
        if (lockThr !== null && lockThr > 0) score += lockThr <= 10 ? 15 : 10;
        if (history !== null) score += history >= 12 ? 10 : history >= 5 ? 6 : history > 0 ? 3 : 0;
        if (!neverExpires && maxAge !== null && maxAge > 0) score += 10;
        score = Math.min(100, score);
        const tone = score >= 80 ? "good" : score >= 55 ? "warn" : "bad";
        const verdict = score >= 80 ? "Strong" : score >= 55 ? "Moderate" : "Weak";

        const num = (v, unit) => v === null
            ? '<span class="domain-muted">-</span>'
            : `${esc(String(v))}${unit ? `<small>${esc(unit)}</small>` : ""}`;

        const tile = (label, valueHtml, toneName, hint) => `
            <div class="pwd-tile pwd-tone-${toneName}">
                <span class="pwd-tile-label">${esc(label)}</span>
                <strong class="pwd-tile-value">${valueHtml}</strong>
                ${hint ? `<small class="pwd-tile-hint">${esc(hint)}</small>` : ""}
            </div>`;

        const check = (label, desc, state, goodWhenOn) => {
            if (state === null || state === undefined) {
                return `<div class="pwd-check pwd-tone-muted"><span class="pwd-check-icon">?</span><div><strong>${esc(label)}</strong><small>${esc(desc)}</small></div><span class="domain-state domain-state-info">Unknown</span></div>`;
            }
            const on = !!state;
            const good = goodWhenOn ? on : !on;
            return `<div class="pwd-check pwd-tone-${good ? "good" : "bad"}">
                <span class="pwd-check-icon">${good ? "&#10003;" : "&#10005;"}</span>
                <div><strong>${esc(label)}</strong><small>${esc(desc)}</small></div>
                <span class="domain-state domain-state-${good ? "good" : "bad"}">${on ? "Enabled" : "Disabled"}</span>
            </div>`;
        };

        const lenTone = minLen === null ? "muted" : minLen >= 12 ? "good" : minLen >= 8 ? "warn" : "bad";
        const lenHint = minLen === null ? "" : minLen >= 12 ? "Recommended" : minLen >= 8 ? "Could be stronger" : "Too short";
        const histTone = history === null ? "muted" : history >= 12 ? "good" : history >= 5 ? "warn" : "bad";
        const lockTone = lockThr === null ? "muted" : lockThr > 0 ? "good" : "bad";
        const lockHint = lockThr === null ? "" : lockThr > 0 ? "Failed attempts allowed" : "No lockout";

        const lockoutDuration = lockDur === 0 ? "Until admin unlocks" : null;

        return `
            <div class="pwd-score pwd-tone-${tone}">
                <div class="pwd-score-head">
                    <div><span class="pwd-score-title">Policy strength</span><strong class="pwd-score-verdict">${verdict}</strong></div>
                    <div class="pwd-score-num">${score}<small>/100</small></div>
                </div>
                <div class="pwd-meter" role="img" aria-label="Policy strength ${score} out of 100"><span style="width:${score}%"></span></div>
            </div>

            <div class="pwd-group-title">Password rules</div>
            <div class="pwd-tile-grid">
                ${tile("Minimum length", num(minLen, "chars"), lenTone, lenHint)}
                ${tile("History", num(history, "passwords"), histTone, "Remembered to block reuse")}
                ${tile("Maximum age", neverExpires ? '<span class="domain-state domain-state-bad">Never expires</span>' : num(maxAge, "days"), neverExpires ? "bad" : "info", neverExpires ? "Passwords never rotate" : "Forced change interval")}
                ${tile("Minimum age", num(minAge, "days"), "info", "Wait before changing again")}
            </div>

            <div class="pwd-group-title">Requirements</div>
            <div class="pwd-check-list">
                ${check("Complexity", "Mixed case, digits & symbols required", complexity, true)}
                ${check("Reversible encryption", "Passwords stored in recoverable form", reversible, false)}
            </div>

            <div class="pwd-group-title">Account lockout</div>
            <div class="pwd-tile-grid pwd-tile-grid-3">
                ${tile("Threshold", num(lockThr, lockThr === 1 ? "attempt" : "attempts"), lockTone, lockHint)}
                ${tile("Duration", lockoutDuration ? `<span class="pwd-small-text">${lockoutDuration}</span>` : num(lockDur, "min"), "info", "Account stays locked")}
                ${tile("Reset window", num(lockWin, "min"), "info", "Counter reset after")}
            </div>

            <div class="pwd-group-title">Password properties <span class="pwd-raw">${value(policy.pwdProperties)}</span></div>
            <div class="domain-chip-list pwd-props">${passwordPropertiesLabels(policy.pwdProperties)}</div>`;
    }

    function rows(items) {
        return items.map(([label, html], index) =>
            `<div class="domain-kv" style="--row-index:${index}"><span>${esc(label)}</span><strong>${html}</strong></div>`).join("");
    }

    function panelTitle(text, iconName) {
        const iconHtml = iconName ? `<span class="domain-panel-icon">${icon(iconName)}</span>` : "";
        return `<div class="domain-panel-title">${iconHtml}${esc(text)}</div>`;
    }

    const FSMO_ROLES = {
        schema: { label: "Schema Master", scope: "Forest", icon: "schema", desc: "Approves changes to the AD schema" },
        naming: { label: "Domain Naming Master", scope: "Forest", icon: "naming", desc: "Adds and removes domains in the forest" },
        pdc: { label: "PDC Emulator", scope: "Domain", icon: "clock", desc: "Time source, password changes and lockouts" },
        rid: { label: "RID Master", scope: "Domain", icon: "hash", desc: "Hands out RID pools for new SIDs" },
        infra: { label: "Infrastructure Master", scope: "Domain", icon: "link", desc: "Resolves cross-domain object references" }
    };
    const FSMO_ORDER = ["schema", "naming", "pdc", "rid", "infra"];

    function fsmoKey(role) {
        const k = String(role || "").toLowerCase().replace(/[^a-z]/g, "");
        if (k.includes("schema")) return "schema";
        if (k.includes("naming")) return "naming";
        if (k.includes("pdc") || k.includes("primarydomain")) return "pdc";
        if (k.includes("infra")) return "infra";
        if (k.includes("rid")) return "rid";
        return null;
    }

    function fsmoHolder(raw) {
        const full = String(raw === null || raw === undefined ? "" : raw).trim();
        if (!full) return { name: "", full: "" };
        const ntds = full.match(/^CN=NTDS Settings,CN=([^,]+)/i);
        if (ntds) return { name: ntds[1], full };
        const cn = full.match(/^CN=([^,]+)/i);
        if (cn) return { name: cn[1], full };
        return { name: full.includes(".") ? full.split(".")[0] : full, full };
    }

    const FSMO_IMPACT = {
        schema: { level: "Low", tone: "info", text: "schema changes are blocked, logons keep working" },
        naming: { level: "Low", tone: "info", text: "domains cannot be added or removed" },
        pdc: { level: "High", tone: "bad", text: "password changes, lockouts and time sync suffer" },
        rid: { level: "Medium", tone: "warn", text: "new objects fail once the RID pool runs out" },
        infra: { level: "Low", tone: "info", text: "cross-domain group references go stale" }
    };
    const FSMO_SHORT = { schema: "Schema", naming: "Naming", pdc: "PDC", rid: "RID", infra: "Infra" };

    function findControllerByHolder(holderName, controllers) {
        const h = String(holderName || "").toLowerCase();
        if (!h) return null;
        return controllers.find(c => {
            const name = String(c.name || "").toLowerCase();
            const host = String(c.dns_hostname || "").toLowerCase();
            return name === h || host === h || host.split(".")[0] === h || host.startsWith(h + ".");
        }) || null;
    }

    function fsmoRows(data, controllers) {
        controllers = Array.isArray(controllers) ? controllers : [];
        const entries = Object.entries(data || {});
        if (!entries.length) return '<span class="domain-muted">None reported</span>';

        const items = entries.map(([role, holder]) => {
            const key = fsmoKey(role);
            const meta = key ? FSMO_ROLES[key] : { label: String(role), scope: "", icon: "crown", desc: "" };
            const h = fsmoHolder(holder);
            const controller = findControllerByHolder(h.name, controllers);
            if (controller && controller.name) h.name = String(controller.name);
            return { key, meta, holder: h, controller };
        }).sort((x, y) => {
            const ix = x.key ? FSMO_ORDER.indexOf(x.key) : 99;
            const iy = y.key ? FSMO_ORDER.indexOf(y.key) : 99;
            return ix - iy;
        });

        const byHolder = new Map();
        items.forEach(item => {
            const id = item.holder.name.toLowerCase();
            if (!id) return;
            if (!byHolder.has(id)) byHolder.set(id, { name: item.holder.name, roles: [] });
            byHolder.get(id).roles.push(item.key ? FSMO_SHORT[item.key] : item.meta.label);
        });
        const holders = Array.from(byHolder.values());

        const holderOf = key => {
            const item = items.find(entry => entry.key === key);
            return item && item.holder.name ? item : null;
        };
        const same = (a, b) => a.holder.name.toLowerCase() === b.holder.name.toLowerCase();
        const reported = FSMO_ORDER.filter(key => holderOf(key)).length;
        const checks = [];

        checks.push({
            label: "All roles reported",
            tone: reported === 5 ? "good" : reported === 0 ? "bad" : "warn",
            text: `${reported} of 5 roles found`
        });

        const schema = holderOf("schema"), naming = holderOf("naming");
        checks.push({
            label: "Forest roles co-located",
            tone: !schema || !naming ? "muted" : same(schema, naming) ? "good" : "warn",
            text: !schema || !naming ? "Not determined" : same(schema, naming) ? `Schema & Naming on ${schema.holder.name}` : `Split: ${schema.holder.name} / ${naming.holder.name}`
        });

        const pdc = holderOf("pdc"), rid = holderOf("rid");
        checks.push({
            label: "PDC & RID co-located",
            tone: !pdc || !rid ? "muted" : same(pdc, rid) ? "good" : "warn",
            text: !pdc || !rid ? "Not determined" : same(pdc, rid) ? `Both on ${pdc.holder.name}` : `Split: ${pdc.holder.name} / ${rid.holder.name}`
        });

        checks.push({
            label: "No single point of failure",
            tone: !holders.length ? "muted" : controllers.length === 1 ? "warn" : (holders.length === 1 && reported > 1) ? "warn" : "good",
            text: !holders.length ? "Not determined" : controllers.length === 1 ? "Only one DC in the domain" : (holders.length === 1 && reported > 1) ? `All roles on ${holders[0].name}` : `Spread across ${holders.length} DCs`
        });

        const unknownHolders = items.filter(item => item.holder.name && !item.controller);
        checks.push({
            label: "Holders are known DCs",
            tone: !controllers.length ? "muted" : unknownHolders.length ? "bad" : "good",
            text: !controllers.length ? "No DC list available" : unknownHolders.length ? `${unknownHolders.length} not in DC list` : "All holders in DC list"
        });

        const holderTones = items.filter(item => item.controller && item.controller.operating_system)
            .map(item => ({ tone: osTone(item.controller.operating_system), name: item.holder.name }));
        const badOs = holderTones.find(entry => entry.tone === "bad");
        const warnOs = holderTones.find(entry => entry.tone === "warn");
        checks.push({
            label: "Supported holder OS",
            tone: !holderTones.length ? "muted" : badOs ? "bad" : warnOs ? "warn" : "good",
            text: !holderTones.length ? "OS not reported" : badOs ? `Unsupported OS on ${badOs.name}` : warnOs ? `Aging OS on ${warnOs.name}` : "All holders on current OS"
        });

        const known = checks.filter(check => check.tone !== "muted");
        const passed = known.filter(check => check.tone === "good").length;
        const sumTone = !known.length ? "muted" : known.some(c => c.tone === "bad") ? "bad" : known.some(c => c.tone === "warn") ? "warn" : "good";
        const verdict = { muted: "Unknown", bad: "At risk", warn: "Needs review", good: "Well placed" }[sumTone];
        const marks = { good: "&#10003;", bad: "&#10005;", warn: "!", muted: "?" };

        const dist = holders.map((holder, index) => `
            <div class="fsmo-dist-seg fsmo-tone-${index % 5}" style="--w:${holder.roles.length}" title="${esc(holder.name)}: ${esc(holder.roles.join(", "))}">
                <strong>${esc(holder.name)}</strong>
                <small>${esc(holder.roles.join(" · "))}</small>
            </div>`).join("");

        const summary = `
            <div class="dx-summary dx-tone-${sumTone}">
                <div class="dx-summary-head">
                    <div><span class="dx-summary-title">Role placement</span><strong class="dx-summary-verdict">${verdict}</strong></div>
                    <div class="dx-summary-num">${holders.length}<small>${holders.length === 1 ? "DC holds" : "DCs hold"} ${items.length} roles</small></div>
                </div>
                ${dist ? `<div class="fsmo-dist">${dist}</div>` : ""}
            </div>`;

        const cards = items.map((item, index) => {
            const impact = item.key ? FSMO_IMPACT[item.key] : null;
            const ip = item.controller && item.controller.ip_address ? String(item.controller.ip_address) : "";
            return `
            <div class="fsmo-card fsmo-tone-${index % 5}" style="--row-index:${index}">
                <div class="fsmo-icon">${icon(item.meta.icon)}</div>
                <div class="fsmo-body">
                    <div class="fsmo-top">
                        <strong>${esc(item.meta.label)}</strong>
                        ${item.meta.scope ? `<em class="fsmo-scope">${esc(item.meta.scope)}</em>` : ""}
                        ${impact ? `<em class="fsmo-impact dx-tone-${impact.tone}">${esc(impact.level)} impact</em>` : ""}
                    </div>
                    ${item.meta.desc ? `<small>${esc(item.meta.desc)}</small>` : ""}
                    ${impact ? `<small class="fsmo-fail">If unavailable: ${esc(impact.text)}</small>` : ""}
                </div>
                <div class="fsmo-holder" title="${esc(item.holder.full)}">
                    <span>Held by</span>
                    <strong>${item.holder.name ? esc(item.holder.name) : '<span class="domain-muted">Unknown</span>'}</strong>
                    ${ip ? `<em>${esc(ip)}</em>` : ""}
                </div>
            </div>`;
        }).join("");

        const checkTiles = checks.map((check, index) => `
            <div class="dx-check fsmo-check dx-tone-${check.tone}" style="--row-index:${index}">
                <span class="dx-check-icon">${marks[check.tone]}</span>
                <div><strong>${esc(check.label)}</strong><small>${esc(check.text)}</small></div>
            </div>`).join("");

        return `
            <div class="fsmo-panel">
                ${summary}
                <div>
                    <div class="dx-group-title">Roles</div>
                    <div class="fsmo-list">${cards}</div>
                </div>
                <div class="fsmo-checks">
                    <div class="dx-group-title">Placement checks</div>
                    <div class="fsmo-check-grid">${checkTiles}</div>
                </div>
            </div>`;
    }

    function authSecurityPanel(ctx) {
        const unknown = v => v === null || v === undefined;
        const item = (label, desc, state, goodWhenTrue, texts, badTone = "bad") => {
            if (unknown(state)) return { label, desc, tone: "muted", text: "Not determined" };
            const on = !!state;
            const good = goodWhenTrue ? on : !on;
            return { label, desc, tone: good ? "good" : badTone, text: on ? texts[0] : texts[1] };
        };

        const groups = [
            {
                title: "LDAP",
                items: [
                    item("LDAP signing", "Rejects unsigned LDAP binds", ctx.ldap.required, true, ["Required", "Not required"]),
                    item("Channel binding (EPA)", "Ties LDAPS sessions to the TLS channel", ctx.epa.enforced, true, ["Enforced", "Not enforced"]),
                    item("Anonymous bind", "Unauthenticated directory queries", ctx.anonymous, false, ["Allowed", "Restricted"])
                ]
            },
            {
                title: "SMB",
                items: [
                    item("Null session", "Access without credentials", ctx.nullSession.allowed, false, ["Allowed", "Restricted"]),
                    item("IPC$ share", "Named-pipe share reachable anonymously", ctx.nullSession.ipc_share_accessible, false, ["Accessible", "Not accessible"])
                ]
            },
            {
                title: "Authentication",
                items: [
                    item("NTLM", "Legacy challenge-response protocol", ctx.ntlm, false, ["Supported", "Disabled"], "warn"),
                    item("Smart card", "Interactive logon needs a smart card", ctx.smartCard, true, ["Required", "Not required"], "warn")
                ]
            }
        ];

        const all = groups.flatMap(group => group.items);
        const known = all.filter(entry => entry.tone !== "muted");
        const passed = known.filter(entry => entry.tone === "good").length;
        const ratio = known.length ? passed / known.length : 0;
        const tone = !known.length ? "muted" : ratio >= 0.8 ? "good" : ratio >= 0.5 ? "warn" : "bad";
        const verdict = !known.length ? "Unknown" : ratio >= 0.8 ? "Hardened" : ratio >= 0.5 ? "Partially hardened" : "Exposed";
        const marks = { good: "&#10003;", bad: "&#10005;", warn: "!", muted: "?" };

        return `
            <div class="dx-summary dx-tone-${tone}">
                <div class="dx-summary-head">
                    <div><span class="dx-summary-title">Security posture</span><strong class="dx-summary-verdict">${verdict}</strong></div>
                    <div class="dx-summary-num">${passed}<small>/${known.length} passed</small></div>
                </div>
                <div class="dx-segments" role="img" aria-label="${passed} of ${known.length} checks passed">
                    ${all.map(entry => `<span class="dx-seg dx-tone-${entry.tone}"></span>`).join("")}
                </div>
            </div>
            ${groups.map(group => `
                <div class="dx-group-title">${esc(group.title)}</div>
                <div class="dx-check-list">
                    ${group.items.map((entry, index) => `
                    <div class="dx-check dx-tone-${entry.tone}" style="--row-index:${index}">
                        <span class="dx-check-icon">${marks[entry.tone]}</span>
                        <div><strong>${esc(entry.label)}</strong><small>${esc(entry.desc)}</small></div>
                        <span class="domain-state domain-state-${entry.tone === "good" ? "good" : entry.tone === "bad" ? "bad" : entry.tone === "warn" ? "warn" : "info"}">${esc(entry.text)}</span>
                    </div>`).join("")}
                </div>`).join("")}`;
    }

    function dnCommonName(dn) {
        const match = String(dn || "").match(/CN=((?:\\.|[^,\\])+)/i);
        return match ? match[1].replace(/\\(.)/g, "$1") : "";
    }

    function formatDay(date) {
        return date.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "2-digit" });
    }

    function caValidity(certificate) {
        const from = certificate.not_before ? new Date(certificate.not_before) : null;
        const to = certificate.not_after ? new Date(certificate.not_after) : null;
        if (!from || !to || Number.isNaN(from.getTime()) || Number.isNaN(to.getTime()) || to <= from) return "";
        const now = Date.now();
        const pct = Math.max(0, Math.min(100, ((now - from.getTime()) / (to.getTime() - from.getTime())) * 100));
        const daysLeft = Math.ceil((to.getTime() - now) / 86400000);
        const expired = daysLeft < 0 || !!certificate.expired;
        const tone = expired ? "bad" : daysLeft <= 90 ? "warn" : "good";
        const years = Math.floor(Math.abs(daysLeft) / 365);
        const rest = Math.abs(daysLeft) % 365;
        const human = years ? `${years}y ${Math.floor(rest / 30)}m` : `${Math.abs(daysLeft)} days`;
        const label = expired ? `Expired ${human} ago` : `${human} remaining`;
        return `
            <div class="ca-validity dx-tone-${tone}">
                <div class="ca-validity-head"><span>Validity</span><strong>${esc(label)}</strong></div>
                <div class="ca-validity-bar"><span style="width:${pct.toFixed(1)}%"></span></div>
                <div class="ca-validity-dates"><span>${esc(formatDay(from))}</span><span>${esc(formatDay(to))}</span></div>
            </div>`;
    }

    function enterpriseCaRows(data) {
        const discovery = data.ca_discovery || {};
        const discoveredAuthorities = Array.isArray(discovery.enterprise_cas) ? discovery.enterprise_cas : [];
        const authorities = discoveredAuthorities.length
            ? discoveredAuthorities
            : (Array.isArray(data.ca_list) ? data.ca_list : []);

        if (!authorities.length) {
            return '<div class="domain-muted">No Enterprise CA reported</div>';
        }

        const field = (label, html, wide, mono = true) => `
            <div class="ca-field${wide ? " ca-field-wide" : ""}">
                <span>${esc(label)}</span>
                <strong class="${mono ? "ca-mono" : ""}">${html}</strong>
            </div>`;

        return authorities.map((ca, index) => {
            const certificate = ca.certificate || {};
            const statusTone = (certificate.error || certificate.expired) ? "bad" : "good";
            const statusText = certificate.error ? "Certificate error" : certificate.expired ? "Expired" : "Valid";
            const subjectCn = dnCommonName(certificate.subject);
            const selfSigned = certificate.self_signed;
            const thumb = certificate.thumbprint_sha1;
            return `
                <article class="ca-card dx-tone-${statusTone}" style="--row-index:${index}">
                    <div class="ca-head">
                        <div class="ca-icon">${icon("cert")}</div>
                        <div class="ca-title">
                            <strong>${value(ca.name)}</strong>
                            <span>${value(ca.dns_hostname)}</span>
                        </div>
                        <div class="ca-badges">
                            ${selfSigned === null || selfSigned === undefined ? "" : `<span class="domain-state domain-state-info">${selfSigned ? "Root CA (self-signed)" : "Subordinate CA"}</span>`}
                            <span class="domain-state domain-state-${statusTone}">${statusText}</span>
                        </div>
                    </div>
                    ${certificate.error ? `<div class="dx-note">${esc(String(certificate.error))}</div>` : caValidity(certificate)}
                    <div class="ca-fields">
                        ${field("Subject", subjectCn ? `${esc(subjectCn)}<small>${value(certificate.subject)}</small>` : value(certificate.subject), true)}
                        ${field("Issuer", dnCommonName(certificate.issuer) ? `${esc(dnCommonName(certificate.issuer))}<small>${value(certificate.issuer)}</small>` : value(certificate.issuer), true)}
                        ${field("Serial number", value(certificate.serial_number), false)}
                        ${field("CA flags", value(ca.flags), false)}
                        ${field("SHA-1 thumbprint", thumb ? `<span title="${esc(String(thumb))}">${esc(String(thumb))}</span>` : value(thumb), true)}
                    </div>
                </article>`;
        }).join("");
    }

    const KERBEROS_STATUS_MAP = {
        configured: { label: "Explicitly configured", tone: "ok" },
        default: { label: "Active Directory default", tone: "warn" },
        unavailable: { label: "Not retrievable", tone: "danger" },
        unknown: { label: "Unknown", tone: "muted" }
    };

    function kerberosStatusBadge(status) {
        const entry = KERBEROS_STATUS_MAP[status] || KERBEROS_STATUS_MAP.unknown;
        return badge(entry.label, entry.tone);
    }

    function kerberosSourceLabel(source) {
        if (!source) return null;
        if (source === "active_directory_default") return "Active Directory built-in default";
        return source;
    }

    function kerberosTicketValidateClient(raw) {
        if (raw === null || raw === undefined) return null;
        if (typeof raw === "boolean") return raw;
        return Number(raw) === 1;
    }

    function humanMinutes(minutes) {
        if (minutes < 60) return `${minutes} min`;
        const hours = minutes / 60;
        if (hours < 24) return Number.isInteger(hours) ? `${hours} h` : `${hours.toFixed(1)} h`;
        const days = hours / 24;
        return Number.isInteger(days) ? `${days} d` : `${days.toFixed(1)} d`;
    }

    function kerberosCard(meta, raw, index) {
        const number = (raw === null || raw === undefined || raw === "" || !Number.isFinite(Number(raw))) ? null : Number(raw);
        let tone = "muted";
        let verdict = "Not available";
        if (number !== null) {
            if (number === meta.def) { tone = "info"; verdict = "Matches default"; }
            else if (number < meta.def) { tone = "good"; verdict = "Stricter than default"; }
            else { tone = "warn"; verdict = "Looser than default"; }
        }
        const sub = number !== null && meta.human ? humanMinutes(meta.human(number)) : "";
        return `
            <div class="kb-card dx-tone-${tone}" style="--row-index:${index}">
                <div class="kb-card-head">
                    <span class="kb-icon">${icon(meta.icon)}</span>
                    <span class="kb-label">${esc(meta.label)}</span>
                </div>
                <div class="kb-value">${number === null ? '<span class="domain-muted">-</span>' : `${esc(String(number))}<small>${esc(meta.unit)}</small>`}</div>
                ${sub && sub !== `${number} ${meta.unit}` ? `<div class="kb-sub">&asymp; ${esc(sub)}</div>` : ""}
                <div class="kb-verdict"><i></i>${esc(verdict)}</div>
                <div class="kb-default">Default: ${esc(String(meta.def))} ${esc(meta.unit)}</div>
            </div>`;
    }

    function kerberosPanel(policy, status) {
        const hasPolicy = policy && typeof policy === "object" && Object.keys(policy).length;
        if (!hasPolicy) {
            return `
                <div class="kb-top">${kerberosStatusBadge(status)}</div>
                <div class="domain-muted">No Kerberos policy reported</div>`;
        }

        const sourceLabel = kerberosSourceLabel(policy.source);
        const validateClient = kerberosTicketValidateClient(policy.ticket_validate_client);
        const vTone = validateClient === null ? "muted" : validateClient ? "good" : "bad";
        const vText = validateClient === null ? "Not determined" : validateClient ? "Enforced" : "Not enforced";

        const cards = [
            kerberosCard({ label: "Max ticket age", unit: "h", def: 10, icon: "ticket", human: h => h * 60 }, policy.max_ticket_age_hours, 0),
            kerberosCard({ label: "Max renew age", unit: "d", def: 7, icon: "renew", human: d => d * 1440 }, policy.max_renew_age_days, 1),
            kerberosCard({ label: "Max service age", unit: "min", def: 600, icon: "key", human: m => m }, policy.max_service_age_minutes, 2),
            kerberosCard({ label: "Max clock skew", unit: "min", def: 5, icon: "sync", human: m => m }, policy.max_clock_skew_minutes, 3),
            `<div class="kb-card dx-tone-${vTone}" style="--row-index:4">
                <div class="kb-card-head">
                    <span class="kb-icon">${icon("shield")}</span>
                    <span class="kb-label">Validate client</span>
                </div>
                <div class="kb-value kb-value-text">${esc(vText)}</div>
                <div class="kb-verdict"><i></i>${validateClient === null ? "Not available" : validateClient ? "PAC checked on every ticket" : "PAC validation skipped"}</div>
                <div class="kb-default">Default: Enforced</div>
            </div>`
        ];

        return `
            <div class="kb-top">
                ${kerberosStatusBadge(status)}
                ${sourceLabel ? `<span class="kb-source">Source: <strong>${esc(sourceLabel)}</strong></span>` : ""}
            </div>
            <div class="kb-grid">${cards.join("")}</div>
            ${policy.error ? `<div class="dx-note">${esc(policy.error)}</div>` : ""}`;
    }

    function dnsZoneKind(name) {
        const lower = name.toLowerCase();
        if (lower.endsWith(".arpa") || lower.endsWith(".arpa.")) return "reverse";
        if (lower.startsWith("_msdcs") || lower.includes("._msdcs") || lower.includes("rootdnsservers") || lower.includes("trustanchors") || lower.startsWith("..")) return "internal";
        return "forward";
    }

    function dnsZonesPanel(zones) {
        const names = (Array.isArray(zones) ? zones : [])
            .map(zone => (zone !== null && typeof zone === "object") ? (zone.name || zone.zone || zone.dn || "") : zone)
            .map(zone => String(zone === null || zone === undefined ? "" : zone).trim())
            .filter(Boolean);
        if (!names.length) return '<span class="domain-muted">None reported</span>';

        const kinds = {
            forward: { label: "Forward lookup", icon: "globe", tone: "info", items: [] },
            reverse: { label: "Reverse lookup", icon: "reverse", tone: "good", items: [] },
            internal: { label: "AD internal", icon: "schema", tone: "warn", items: [] }
        };
        names.forEach(name => kinds[dnsZoneKind(name)].items.push(name));
        const order = ["forward", "reverse", "internal"].filter(key => kinds[key].items.length);

        return `
            <div class="dns-summary">
                <div class="dns-total"><strong>${names.length}</strong><span>${names.length === 1 ? "zone" : "zones"}</span></div>
                <div class="dns-counts">
                    ${order.map(key => `<span class="dns-count dx-tone-${kinds[key].tone}"><i></i>${esc(kinds[key].label)} <strong>${kinds[key].items.length}</strong></span>`).join("")}
                </div>
            </div>
            ${names.length > 6 ? `<label class="dns-search">${icon("search")}<input type="search" class="dns-filter" placeholder="Filter zones" autocomplete="off" spellcheck="false"></label>` : ""}
            <div class="dns-list">
                ${order.map(key => `
                    <div class="dns-group" data-dns-group>
                        <div class="dx-group-title">${esc(kinds[key].label)}</div>
                        ${kinds[key].items.map((name, index) => `
                        <div class="dns-row dx-tone-${kinds[key].tone}" data-dns-zone="${esc(name.toLowerCase())}" style="--row-index:${Math.min(index, 12)}">
                            <span class="dns-icon">${icon(kinds[key].icon)}</span>
                            <strong title="${esc(name)}">${esc(name)}</strong>
                        </div>`).join("")}
                    </div>`).join("")}
                <div class="domain-muted dns-empty" hidden>No matching zones</div>
            </div>`;
    }

    const SEVERITIES = ["info", "low", "medium", "high", "critical"];

    function copyChip(text, iconName, extra) {
        return `<button type="button" class="dh-chip${extra ? " " + extra : ""}" data-copy="${esc(text)}" title="Click to copy">${iconName ? icon(iconName) : ""}<span>${esc(text)}</span><i class="dh-chip-copy">${icon("copy")}</i></button>`;
    }

    function heroHtml(data, severity, score, controllers, risk) {
        const sevIndex = Math.max(0, SEVERITIES.indexOf(severity));
        const level = Number(data.functional_level);
        const tags = [
            data.fqdn ? copyChip(String(data.fqdn), "globe") : "",
            data.domain_sid ? copyChip(String(data.domain_sid), null, "dh-chip-mono") : "",
            data.functional_level_name ? `<span class="dh-chip dh-chip-static">${icon("level")}<span>${esc(String(data.functional_level_name))}${Number.isFinite(level) ? ` &middot; Level ${level}` : ""}</span></span>` : "",
            `<span class="dh-chip dh-chip-static">${icon("server")}<span>${controllers.length} DC${controllers.length === 1 ? "" : "s"}</span></span>`,
            data.has_enterprise_ca ? `<span class="dh-chip dh-chip-static dh-chip-ok">${icon("cert")}<span>Enterprise CA</span></span>` : ""
        ].filter(Boolean).join("");

        return `
            <div class="dh-hero dh-sev-${esc(severity)}">
                <div class="dh-main">
                    <div class="dh-eyebrow"><i></i>DOMAIN OVERVIEW</div>
                    <h1>${value(data.netbios_name || data.fqdn, "Unknown domain")}</h1>
                    <div class="dh-tags">${tags}</div>
                    <div class="dh-scale" aria-label="Severity scale">
                        ${SEVERITIES.map((name, index) => `<div class="dh-scale-step${index <= sevIndex ? " on" : ""}${index === sevIndex ? " current" : ""}"><span></span><em>${name}</em></div>`).join("")}
                    </div>
                </div>
                <div class="dh-risk" title="${esc(risk && risk.findings.length ? risk.findings.slice(0, 8).map(f => f.severity.toUpperCase() + ': ' + f.title).join('\n') : 'No findings')}">
                    <div class="dh-ring" style="--risk-pct:0" role="img" aria-label="Risk score ${score} out of 100">
                        <svg viewBox="0 0 120 120" aria-hidden="true">
                            <circle class="dh-ring-track" cx="60" cy="60" r="52" pathLength="100"/>
                            <circle class="dh-ring-fill" cx="60" cy="60" r="52" pathLength="100"/>
                        </svg>
                        <div class="dh-ring-center"><strong data-count-target="${score}">0</strong><small>/ 100</small></div>
                    </div>
                    <div class="dh-risk-label">Risk score</div>
                    <span class="dh-risk-pill">${esc(severity)}</span>
                </div>
            </div>`;
    }

    function statsHtml(data, controllers) {
        const level = Number(data.functional_level);
        const quota = Number(data.machine_account_quota);
        const levelKnown = Number.isFinite(level);
        const levelTone = !levelKnown ? "muted" : level >= 7 ? "good" : level >= 5 ? "warn" : "bad";
        const levelText = !levelKnown ? "Unknown" : level >= 7 ? "Current" : level >= 5 ? "Aging" : "Legacy";
        const dcTone = controllers.length === 0 ? "muted" : controllers.length === 1 ? "warn" : "info";
        const dcText = controllers.length === 0 ? "None reported" : controllers.length === 1 ? "Single DC, no redundancy" : "Redundant";
        const quotaKnown = Number.isFinite(quota);
        const quotaTone = !quotaKnown ? "muted" : quota > 0 ? "bad" : "good";
        const quotaText = !quotaKnown ? "Unknown" : quota > 0 ? `Users can join ${quota} machine${quota === 1 ? "" : "s"}` : "Locked down";
        const smbRequired = !!data.smb_signing_required;
        const smbEnabled = !!data.smb_signing_enabled;
        const smbTone = smbRequired ? "good" : smbEnabled ? "warn" : "bad";
        const smbText = smbRequired ? "Enforced" : smbEnabled ? "Enabled, not required" : "Disabled";

        const cards = [
            {
                tone: levelTone, icon: "level", label: "Functional level",
                main: value(data.functional_level_name), count: null,
                sub: `Level ${value(data.functional_level, "-")}`, pill: levelText,
                extra: levelKnown ? `<div class="ds-meter">${Array.from({ length: 8 }, (_, index) => `<span class="${index <= level ? "on" : ""}"></span>`).join("")}</div>` : ""
            },
            {
                tone: dcTone, icon: "server", label: "Domain controllers",
                main: String(controllers.length), count: controllers.length,
                sub: data.has_enterprise_ca ? "Enterprise CA present" : "No enterprise CA", pill: dcText, extra: ""
            },
            {
                tone: quotaTone, icon: "quota", label: "Machine quota",
                main: value(data.machine_account_quota), count: quotaKnown ? quota : null,
                sub: "MachineAccountQuota", pill: quotaText, extra: ""
            },
            {
                tone: smbTone, icon: "shield", label: "SMB signing",
                main: smbRequired ? "Required" : "Not required", count: null,
                sub: smbEnabled ? "Enabled" : "Disabled", pill: smbText, extra: ""
            }
        ];

        return `
            <div class="ds-grid">
                ${cards.map((card, index) => `
                <div class="ds-card dx-tone-${card.tone}" style="--stat-index:${index}">
                    <div class="ds-head">
                        <span class="ds-icon">${icon(card.icon)}</span>
                        <span class="ds-label">${esc(card.label)}</span>
                    </div>
                    <div class="ds-value"${card.count !== null ? ` data-count-target="${card.count}"` : ""}>${card.count !== null ? "0" : card.main}</div>
                    <div class="ds-sub">${card.sub}</div>
                    ${card.extra}
                    <div class="ds-pill"><i></i>${esc(card.pill)}</div>
                </div>`).join("")}
            </div>`;
    }

    function controllerRoles(controller, fsmo) {
        const name = String(controller.name || "").toLowerCase();
        const host = String(controller.dns_hostname || "").toLowerCase();
        const short = host.split(".")[0];
        const found = [];
        Object.entries(fsmo || {}).forEach(([role, holder]) => {
            const key = fsmoKey(role);
            const holderName = fsmoHolder(holder).name.toLowerCase();
            if (!key || !holderName) return;
            if (holderName === name || holderName === short || host === holderName || host.startsWith(holderName + ".")) found.push(key);
        });
        return FSMO_ORDER.filter(key => found.includes(key));
    }

    function osTone(os) {
        const year = String(os || "").match(/20\d\d/);
        if (!year) return "muted";
        const number = Number(year[0]);
        return number >= 2016 ? "good" : number >= 2012 ? "warn" : "bad";
    }

    function controllersHtml(controllers, fsmo) {
        if (!controllers.length) return '<div class="domain-muted">No domain controllers reported</div>';
        const shortRole = { schema: "Schema", naming: "Naming", pdc: "PDC", rid: "RID", infra: "Infra" };
        return `<div class="dc-grid">${controllers.map((controller, index) => {
            const roles = controllerRoles(controller, fsmo);
            const tone = osTone(controller.operating_system);
            const host = controller.dns_hostname ? String(controller.dns_hostname) : "";
            const ip = controller.ip_address ? String(controller.ip_address) : "";
            return `
                <article class="dc-card" style="--row-index:${index}">
                    <div class="dc-head">
                        <div class="dc-icon">${icon("server")}<i></i></div>
                        <div class="dc-title">
                            <strong>${value(controller.name)}</strong>
                            ${host ? `<button type="button" class="dc-host" data-copy="${esc(host)}" title="Click to copy">${esc(host)}</button>` : '<span class="domain-muted">No DNS name</span>'}
                        </div>
                        ${roles.length ? `<span class="dc-role-count" title="FSMO roles held">${roles.length}<small>${roles.length === 1 ? "role" : "roles"}</small></span>` : ""}
                    </div>
                    <div class="dc-meta">
                        <div class="dc-meta-row"><span>IP address</span>${ip ? `<button type="button" class="dc-ip" data-copy="${esc(ip)}" title="Click to copy">${esc(ip)}</button>` : '<strong class="domain-muted">-</strong>'}</div>
                        <div class="dc-meta-row"><span>Operating system</span><strong class="dc-os dx-tone-${tone}"><i></i>${value(controller.operating_system)}</strong></div>
                    </div>
                    ${roles.length ? `<div class="dc-roles">${roles.map(key => `<span class="dc-role fsmo-tone-${FSMO_ORDER.indexOf(key)}" title="${esc(FSMO_ROLES[key].label)}">${esc(shortRole[key])}</span>`).join("")}</div>` : ""}
                </article>`;
        }).join("")}</div>`;
    }

    function animateNumber(element, target, duration, reduceMotion, onFrame) {
        if (reduceMotion) {
            element.textContent = String(target);
            if (onFrame) onFrame(target);
            return;
        }
        const start = performance.now();
        const tick = now => {
            const t = Math.min(1, (now - start) / duration);
            const eased = 1 - Math.pow(1 - t, 3);
            const current = Math.round(target * eased);
            element.textContent = String(current);
            if (onFrame) onFrame(current);
            if (t < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
    }

    const RISK_PREFER_BACKEND = false;  // false: həmişə lokal hesabla; true: data.risk_score varsa onu istifadə et
    const RISK_WEIGHTS = { critical: 25, high: 15, medium: 8, low: 3, info: 0 };
    const RISK_FLOOR = { critical: 75, high: 50, medium: 25, low: 10, info: 0 };
    const RISK_SCALE = 60;              // böyüdükcə bal daha yavaş artır

    function computeRisk(data) {
        const findings = [];
        const add = (severity, title) => findings.push({ severity, title });
        const num = v => (v === null || v === undefined || v === "" || !Number.isFinite(Number(v))) ? null : Number(v);
        const isFalse = v => v === false || v === 0;

        const policy = data.password_policy || {};
        const security = data.authentication_security || {};
        const ldap = data.ldap_signing || security.ldap_signing || {};
        const epa = data.ldap_channel_binding || security.ldap_channel_binding || {};
        const nullSession = data.null_session || {};
        const kerberos = data.kerberos_policy || {};
        const ntlm = security.ntlm_supported ?? data.ntlm_supported;

        if (isFalse(ldap.required)) add("high", "LDAP signing is not required");
        if (isFalse(epa.enforced)) add("medium", "LDAP channel binding is not enforced");
        if (data.null_anonymous_access && data.null_anonymous_access.allowed) add("high", "Anonymous LDAP bind allowed");
        if (nullSession.allowed) add("high", "SMB null session allowed");
        if (nullSession.ipc_share_accessible) add("high", "IPC$ share accessible anonymously");
        if (ntlm) add("medium", "NTLM is still supported");

        if (data.smb_signing_required === false || data.smb_signing_required === 0 || data.smb_signing_required === undefined) {
            if (data.smb_signing_enabled) add("medium", "SMB signing enabled but not required");
            else if (data.smb_signing_enabled !== undefined && data.smb_signing_enabled !== null) add("high", "SMB signing disabled");
        }

        const quota = num(data.machine_account_quota);
        if (quota !== null && quota > 0) add("high", `MachineAccountQuota = ${quota}`);

        const level = num(data.functional_level);
        if (level !== null) {
            if (level < 5) add("high", "Legacy functional level");
            else if (level < 7) add("medium", "Aging functional level");
        }

        if (Array.isArray(data.domain_controllers)) {
            if (data.domain_controllers.length === 1) add("low", "Single domain controller (no redundancy)");
            let worstOs = null;
            data.domain_controllers.forEach(dc => {
                const match = String(dc.operating_system || "").match(/20\d\d/);
                if (!match) return;
                const year = Number(match[0]);
                if (worstOs === null || year < worstOs) worstOs = year;
            });
            if (worstOs !== null && worstOs < 2012) add("high", `Unsupported DC operating system (${worstOs})`);
            else if (worstOs !== null && worstOs < 2016) add("medium", `Aging DC operating system (${worstOs})`);
        }

        const minLen = num(policy.minPwdLength);
        if (minLen !== null) {
            if (minLen < 8) add("high", "Minimum password length below 8");
            else if (minLen < 12) add("medium", "Minimum password length below 12");
        }
        if (isFalse(policy.complexityEnabled)) add("medium", "Password complexity disabled");
        if (policy.reversibleEncryption === true || policy.reversibleEncryption === 1) add("high", "Reversible password encryption enabled");
        const lockThr = num(policy.lockoutThreshold);
        if (lockThr !== null) {
            if (lockThr === 0) add("high", "No account lockout");
            else if (lockThr > 10) add("low", "Account lockout threshold above 10");
        }
        const history = num(policy.pwdHistoryLength);
        if (history !== null && history < 5) add("low", "Short password history");
        if (policy.maxPwdAge_never_expires) add("low", "Passwords never expire");

        const validate = kerberos.ticket_validate_client;
        if (validate !== null && validate !== undefined && !(typeof validate === "boolean" ? validate : Number(validate) === 1)) {
            add("medium", "Kerberos client validation not enforced");
        }
        const tgt = num(kerberos.max_ticket_age_hours);
        if (tgt !== null && tgt > 10) add("low", "Kerberos ticket lifetime above default");
        const skew = num(kerberos.max_clock_skew_minutes);
        if (skew !== null && skew > 5) add("low", "Kerberos clock skew above default");
        const svc = num(kerberos.max_service_age_minutes);
        if (svc !== null && svc > 600) add("low", "Kerberos service ticket lifetime above default");

        const discovered = data.ca_discovery && Array.isArray(data.ca_discovery.enterprise_cas) ? data.ca_discovery.enterprise_cas : [];
        const cas = discovered.length ? discovered : (Array.isArray(data.ca_list) ? data.ca_list : []);
        if (cas.some(ca => ca.certificate && ca.certificate.expired)) add("high", "Enterprise CA certificate expired");
        else if (cas.some(ca => ca.certificate && ca.certificate.error)) add("medium", "Enterprise CA certificate error");

        const total = findings.reduce((sum, f) => sum + RISK_WEIGHTS[f.severity], 0);
        let highest = "info";
        findings.forEach(f => {
            if (SEVERITIES.indexOf(f.severity) > SEVERITIES.indexOf(highest)) highest = f.severity;
        });
        let score = Math.round(100 * (1 - Math.exp(-total / RISK_SCALE)));
        score = Math.min(100, Math.max(score, RISK_FLOOR[highest]));

        findings.sort((a, b) => RISK_WEIGHTS[b.severity] - RISK_WEIGHTS[a.severity]);
        return { score, severity: highest, findings };
    }

    function resolveRisk(data) {
        const backendScore = data.risk_score;
        const hasBackend = backendScore !== null && backendScore !== undefined && backendScore !== "" && Number.isFinite(Number(backendScore));
        const computed = computeRisk(data);
        if (RISK_PREFER_BACKEND && hasBackend) {
            return {
                score: Math.max(0, Math.min(100, Number(backendScore))),
                severity: String(data.highest_severity || computed.severity).toLowerCase(),
                findings: computed.findings
            };
        }
        return computed;
    }

    function render(data) {
        const controllers = Array.isArray(data.domain_controllers) ? data.domain_controllers : [];
        const policy = data.password_policy || {};
        const security = data.authentication_security || {};
        const ldap = data.ldap_signing || security.ldap_signing || {};
        const ldapChannelBinding = data.ldap_channel_binding || security.ldap_channel_binding || {};
        const kerberosPolicy = data.kerberos_policy || {};
        const nullSession = data.null_session || {};
        const risk = resolveRisk(data);
        console.debug("[domain risk]", risk, "backend risk_score:", data.risk_score);
        const severity = risk.severity;
        const score = risk.score;
        const ntlm = security.ntlm_supported ?? data.ntlm_supported;
        const anonymous = !!(data.null_anonymous_access && data.null_anonymous_access.allowed);
        const quota = Number(data.machine_account_quota);
        const minLength = Number(policy.minPwdLength);
        const lockout = Number(policy.lockoutThreshold);

        root.innerHTML = `
            ${heroHtml(data, severity, score, controllers, risk)}
            ${statsHtml(data, controllers)}
            <div class="domain-summary-grid">
                <section class="domain-panel domain-panel-wide domain-panel-blue">
                    ${panelTitle("Domain controllers", "server")}
                    ${controllersHtml(controllers, data.fsmo)}
                </section>
                <section class="domain-panel domain-panel-wide domain-panel-blue">
                    ${panelTitle("Enterprise CA", "cert")}
                    <div class="ca-list">${enterpriseCaRows(data)}</div>
                </section>
                <section class="domain-panel domain-panel-purple domain-panel-fill">
                    ${panelTitle("FSMO roles", "crown")}
                    ${fsmoRows(data.fsmo, controllers)}
                </section>
                <section class="domain-panel domain-panel-amber">
                    ${panelTitle("Password policy", "key")}
                    <div class="pwd-policy">${passwordPolicyPanel(policy)}</div>
                </section>
                <section class="domain-panel domain-panel-green">
                    ${panelTitle("Authentication security", "shield")}
                    <div class="dx-auth">${authSecurityPanel({ ntlm, ldap, epa: ldapChannelBinding, anonymous, nullSession, smartCard: data.smart_card_required })}</div>
                </section>
                <section class="domain-panel domain-panel-teal domain-panel-fill">
                    ${panelTitle("DNS zones", "globe")}
                    <div class="dns-panel">${dnsZonesPanel(data.dns_zones)}</div>
                </section>
                <section class="domain-panel domain-panel-wide domain-panel-purple">
                    ${panelTitle("Kerberos policy", "lock")}
                    ${kerberosPanel(kerberosPolicy, data.kerberos_status)}
                </section>
            </div>`;

        const dnsFilter = root.querySelector(".dns-filter");
        if (dnsFilter) {
            dnsFilter.addEventListener("input", () => {
                const term = dnsFilter.value.trim().toLowerCase();
                let visible = 0;
                root.querySelectorAll("[data-dns-zone]").forEach(row => {
                    const show = !term || row.dataset.dnsZone.includes(term);
                    row.hidden = !show;
                    if (show) visible += 1;
                });
                root.querySelectorAll("[data-dns-group]").forEach(group => {
                    group.hidden = !group.querySelector("[data-dns-zone]:not([hidden])");
                });
                const empty = root.querySelector(".dns-empty");
                if (empty) empty.hidden = visible > 0;
            });
        }

        const reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

        root.addEventListener("click", event => {
            const target = event.target.closest("[data-copy]");
            if (!target || typeof copyText !== "function") return;
            copyText(target.dataset.copy).then(() => {
                target.classList.add("copied");
                setTimeout(() => target.classList.remove("copied"), 1200);
            }).catch(() => {});
        });

        requestAnimationFrame(() => {
            const ring = root.querySelector(".dh-ring");
            const ringNumber = root.querySelector(".dh-ring-center strong[data-count-target]");
            if (ring && ringNumber) {
                animateNumber(ringNumber, Number(ringNumber.getAttribute("data-count-target")) || 0, 900, reduceMotion, current => {
                    ring.style.setProperty("--risk-pct", current);
                });
            }
            root.querySelectorAll(".ds-value[data-count-target]").forEach(element => {
                animateNumber(element, Number(element.getAttribute("data-count-target")) || 0, 700, reduceMotion);
            });
        });
    }

    Api.getDomainResults("domain", { page: 1, page_size: 1 }).then(result => {
        if (!result.ok || !result.items.length) {
            render({});
            return;
        }
        render(result.items[0].data);
    });
}